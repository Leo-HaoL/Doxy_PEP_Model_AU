# -*- coding: utf-8 -*-
"""
A comprehensive simulation model for STI transmission dynamics and Doxy-PEP intervention strategies.

This module implements a detailed agent-based simulation model for studying the transmission
dynamics of sexually transmitted infections (STIs) including Neisseria gonorrhoeae (NG),
Chlamydia trachomatis (CT), and Treponema pallidum (TP). The model incorporates various
intervention strategies, particularly focusing on Doxycycline Post-Exposure Prophylaxis (Doxy-PEP).

Key features:
- Agent-based modeling of sexual networks
- Detailed STI transmission and progression dynamics
- Antibiotic resistance development and spread
- Screening and treatment protocols
- Doxy-PEP intervention strategies
- Partnership formation and dissolution
- Sexual behavior patterns

Created on Wed Mar 12 14:56:11 2025
@author: HaoL
"""
# %% Import necessary packages
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import sem, t
import os

# (1) Becom symptomatic proportion
NG_Sym_Proportion = 0.30 # (JAMA January 11, 2022 Volume 327, Number 2)
CT_Sym_Proportion = 0.15 # (JAMA January 11, 2022 Volume 327, Number 2)
TP_I1_Sym_Proportion = 0.25
TP_I2_Sym_Proportion = 0.60

# (2) Progress gamma/uniform params
Sym_Driven_Treat = (1, 2)
NG_t_E_to_I = (100, 0.01)
NG_t_Ia_to_U = (11, 3) # Untreated Ia NG return to uninfected status
NG_t_T_to_U = (1, 2)
CT_t_E_to_I = (10, 0.2)
CT_t_Ia_to_U = (360, 0.25) # Untreated Ia CT return to uninfected status
CT_t_T_to_U = (1, 2)
TP_t_E_to_I1 = (30, 0.1)
TP_t_I1_to_EL1 = (10, 0.5)
TP_t_EL1_to_I2 = (30, 0.2)
TP_t_I2_to_EL2 = (50, 0.4)
TP_t_EL2_to_LL = (72, 0.25)
TP_t_LL_to_I3 = (150, 0.10)
TP_t_T1_to_U = (1, 2)
TP_t_T2_to_U = (12, 0.42)
STI_t_U_to_U = 10000 # Use a time can't be reached to limit some situation

# (3) Other params
Condom_protection = 0.9 # The Lancet HIV 2016;3:e289–e296.

# Creating the doxy-PEP strategies
Doxy_PEP_Scenarios = {
    0: {'strategy_type': 'STI_diag', 'HIV': [True, False], 'PrEP': [True, False], 'Interval': 0, 'Duration': 26, 'Uptake': 0.75, 'Adherence': 0.8, 'Efficacy': {'NG': 0.45, 'CT': 0.81, 'TP': 0.77}, 'Sometime_condom': 0.5, 'Background_increase_ratio': 1, 'Cef_failure_prob_ratio': 1, 'Doxy_increase_ratio': 1, 'Always_condom_ratio': 1, 'NG_Sym_Proportion': 0.3, 'Ini_Pos_Ratio': 1},
    1: {'strategy_type': 'TP_diag', 'HIV': [True, False], 'PrEP': [True, False], 'Interval': 5200, 'Duration': 26, 'Uptake': 0.75, 'Adherence': 0.8, 'Efficacy': {'NG': 0.45, 'CT': 0.81, 'TP': 0.77}, 'Sometime_condom': 0.5, 'Background_increase_ratio': 1, 'Cef_failure_prob_ratio': 1, 'Doxy_increase_ratio': 1, 'Always_condom_ratio': 1, 'NG_Sym_Proportion': 0.3, 'Ini_Pos_Ratio': 1},
    2: {'strategy_type': 'STI_diag', 'HIV': [True, False], 'PrEP': [True, False], 'Interval': 26, 'Duration': 26, 'Uptake': 0.75, 'Adherence': 0.8, 'Efficacy': {'NG': 0.45, 'CT': 0.81, 'TP': 0.77}, 'Sometime_condom': 0.5, 'Background_increase_ratio': 1, 'Cef_failure_prob_ratio': 1, 'Doxy_increase_ratio': 1, 'Always_condom_ratio': 1, 'NG_Sym_Proportion': 0.3, 'Ini_Pos_Ratio': 1},
    3: {'strategy_type': 'STI_diag', 'HIV': [True, False], 'PrEP': [True, False], 'Interval': 52, 'Duration': 26, 'Uptake': 0.75, 'Adherence': 0.8, 'Efficacy': {'NG': 0.45, 'CT': 0.81, 'TP': 0.77}, 'Sometime_condom': 0.5, 'Background_increase_ratio': 1, 'Cef_failure_prob_ratio': 1, 'Doxy_increase_ratio': 1, 'Always_condom_ratio': 1, 'NG_Sym_Proportion': 0.3, 'Ini_Pos_Ratio': 1},
    4: {'strategy_type': 'HIV_PrEP', 'HIV': [True], 'PrEP': [True, False], 'Interval': 5200, 'Duration': 26, 'Uptake': 0.75, 'Adherence': 0.8, 'Efficacy': {'NG': 0.45, 'CT': 0.81, 'TP': 0.77}, 'Sometime_condom': 0.5, 'Background_increase_ratio': 1, 'Cef_failure_prob_ratio': 1, 'Doxy_increase_ratio': 1, 'Always_condom_ratio': 1, 'NG_Sym_Proportion': 0.3, 'Ini_Pos_Ratio': 1},
    5: {'strategy_type': 'HIV_PrEP', 'HIV': [True, False], 'PrEP': [True], 'Interval': 5200, 'Duration': 26, 'Uptake': 0.75, 'Adherence': 0.8, 'Efficacy': {'NG': 0.45, 'CT': 0.81, 'TP': 0.77}, 'Sometime_condom': 0.5, 'Background_increase_ratio': 1, 'Cef_failure_prob_ratio': 1, 'Doxy_increase_ratio': 1, 'Always_condom_ratio': 1, 'NG_Sym_Proportion': 0.3, 'Ini_Pos_Ratio': 1},
}

variations = [
    {'key': 'Duration', 'values': [13, 52]},
    {'key': 'Uptake', 'values': [0.5, 0.6, 0.9, 1.0]},
    {'key': 'Adherence', 'values': [0.6, 1.0]},
    {'key': 'Efficacy', 'values': [{'NG': 0.13, 'CT': 0.56, 'TP': 0.64},
                                     {'NG': 0.66, 'CT': 0.92, 'TP': 0.86}]},
    {'key': 'Always_condom_ratio', 'values': [0.5, 1.5]},
    {'key': 'Sometime_condom', 'values': [0.25, 0.75]},
    {'key': 'NG_Sym_Proportion', 'values': [0.15, 0.45]},
    {'key': 'Cef_failure_prob_ratio', 'values': [0.5, 1.5]},
    {'key': 'Background_increase_ratio', 'values': [0.5, 1.5]},
    {'key': 'Doxy_increase_ratio', 'values': [0.5, 1.5]},
    {'key': 'Ini_Pos_Ratio', 'values': [0.5, 1.5]},
]

new_scenarios = {}
index = len(Doxy_PEP_Scenarios)

for variation in variations:
    for value in variation['values']:
        start_idx = 0
        for i in range(start_idx, len(Doxy_PEP_Scenarios)):
            new_entry = Doxy_PEP_Scenarios[i].copy()
            new_entry[variation['key']] = value
            new_scenarios[index] = new_entry
            index += 1

Doxy_PEP_Scenarios.update(new_scenarios)
Doxy_PEP_Scenarios = pd.DataFrame.from_dict(Doxy_PEP_Scenarios, orient='index')

# %% Fun 1. Load population structure data
def load_population_data():
    """
    Load population structure data from Data_Population_Structure.xlsx
    
    Returns:
    --------
    dict: A dictionary containing DataFrames for each data category with years as columns
          starting from 2012 and extending for the number of years in the data
    """
    # Read data
    df = pd.read_excel(os.path.join(os.getcwd(), 'Data_tobe_called', 'Data_Population_Structure.xlsx'), sheet_name="Popu_Struc")
    age_ranges = [f"{i}-{i+4}" for i in range(15, 65, 5)]
    
    # Create base DataFrames
    data_categories = {
        "ASDR": "ASDR_per_1000",
        "Standard_ratio_arrive": "Standard_ratio_arrive",
        "Standard_ratio_depart": "Standard_ratio_depart"
    }
    result = {key: pd.DataFrame([df[df['Age'] == age][value].values.tolist() for age in age_ranges], index=age_ranges) 
             for key, value in data_categories.items()}
    
    # Process data
    result["ASDR"] = result["ASDR"] / 1000
    result["Standard_ratio_sex_matur"] = pd.DataFrame([df[df['Age'] == "14"]['Standard_ratio_sex_matur'].values], index=["14"])
    
    # Extend years
    for key in result:
        mean_values = result[key].mean(axis=1)
        num_years = result[key].shape[1]
        years = range(2012, 2012 + num_years + 11)
        new_cols = pd.DataFrame({year: mean_values for year in years[num_years:]}, index=result[key].index)
        result[key] = pd.concat([result[key], new_cols], axis=1)
        result[key].columns = years
    
    return result

# %% Fun 2. Update population structure
def update_population(agents, week_cycle, Popu_struc_data, Now_regular_partnerships, Now_casual_partnerships, All_casual_partnerships, Ra, Ca):
    """
    Update the population structure including aging, death, migration, and new arrivals.
    
    Parameters:
    -----------
    agents : DataFrame
        Current population data
    week_cycle : int
        Current simulation week
    Popu_struc_data : dict
        Population structure data including mortality, migration, and maturation rates
    Now_regular_partnerships : DataFrame
        Current regular partnerships
    Now_casual_partnerships : DataFrame
        Current casual partnerships
    All_casual_partnerships : DataFrame
        All casual partnerships (including historical)
    Ra : set
        Set of agents available for regular partnerships
    Ca : set
        Set of agents available for casual partnerships
        
    Returns:
    --------
    tuple
        Updated agents DataFrame and partnership DataFrames
    """
    # Increase age by 1 for all agents
    agents['age_year'] += 1
    
    # Calculate IDs to remove (age >= 65)
    ids_to_remove = set(agents[agents['age_year'] >= 65].index)
    age_groups = [(15,19), (20,24), (25,29), (30,34), (35,39), (40,44), (45,49), (50,54), (55,59), (60,64)]
    col_idx = week_cycle // 52 - 3
    
    # Calculate removals based on mortality and departure rates
    for (lower, upper), mort_rate, dep_rate in zip(age_groups, 
        Popu_struc_data["ASDR"].iloc[:, col_idx].values,
        Popu_struc_data["Standard_ratio_depart"].iloc[:, col_idx].values):
        age_mask = (agents['age_year'] >= lower) & (agents['age_year'] <= upper)
        if (num_to_remove := int(age_mask.sum() * (mort_rate + dep_rate))) > 0:
            ids_to_remove.update(np.random.choice(agents[age_mask].index, size=num_to_remove, replace=False))
    
    # Update partnership status for removed agents
    # Handle regular partnerships
    if (mask := (Now_regular_partnerships['partner1'].isin(ids_to_remove) | 
                 Now_regular_partnerships['partner2'].isin(ids_to_remove))).any():
        affected_partners = pd.Index(Now_regular_partnerships[mask][['partner1', 'partner2']].values.ravel()).difference(ids_to_remove)
        Now_regular_partnerships.drop(Now_regular_partnerships[mask].index, inplace=True)
        if len(affected_partners) > 0:
            agents.loc[affected_partners, 'Reg_now'] = False
            Ra = Ra.union(affected_partners)

    # Handle casual partnerships
    if (mask := (Now_casual_partnerships['partner1'].isin(ids_to_remove) | 
                 Now_casual_partnerships['partner2'].isin(ids_to_remove))).any():
        affected_partners = pd.Index(Now_casual_partnerships[mask][['partner1', 'partner2']].values.ravel()).difference(ids_to_remove)
        Now_casual_partnerships.drop(Now_casual_partnerships[mask].index, inplace=True)
        all_mask = (All_casual_partnerships['partner1'].isin(ids_to_remove) | 
                   All_casual_partnerships['partner2'].isin(ids_to_remove))
        All_casual_partnerships.loc[all_mask, 'end_week'] = week_cycle
        if len(affected_partners) > 0:
            agents.loc[affected_partners, 'Cas_now'] = False
            Ca = Ca.union(affected_partners)

    # Update agents DataFrame
    start_id = agents.index.max() + 1 if not agents.empty else 0
    agents = agents.drop(ids_to_remove)
    
    # Update Ra and Ca sets to only include existing agents
    Ra = Ra.intersection(agents.index)
    Ca = Ca.intersection(agents.index)
    
    # Calculate new matured and arriving agents
    maturation_rate = Popu_struc_data["Standard_ratio_sex_matur"].iloc[0, col_idx]
    num_new_matured = int(len(agents) * maturation_rate)
    arrival_rates = Popu_struc_data["Standard_ratio_arrive"].iloc[:, col_idx].values
    
    # Generate data for new arrivals
    arrival_data = []
    for (lower, upper), rate in zip(age_groups, arrival_rates):
        age_mask = (agents['age_year'] >= lower) & (agents['age_year'] <= upper)
        age_group_size = age_mask.sum()
        if (num_to_arrive := int(age_group_size * rate)) > 0:
            ages = np.random.randint(lower, upper + 1, size=num_to_arrive)
            age_hiv_prevalence = agents[age_mask]['HIV'].mean()
            age_prep_prevalence = agents[age_mask & ~agents['HIV']]['PrEP'].mean()
            hiv_status = np.random.random(num_to_arrive) < age_hiv_prevalence
            prep_status = np.zeros(num_to_arrive, dtype=bool)
            if (hiv_neg_indices := np.where(~hiv_status)[0]).size > 0:
                prep_status[hiv_neg_indices[np.random.random(len(hiv_neg_indices)) < age_prep_prevalence]] = True
            arrival_data.extend(zip(ages, hiv_status, prep_status))
    
    # Create new population DataFrame
    new_people = pd.DataFrame({
        'ID': range(start_id, start_id + num_new_matured + len(arrival_data)),
        'Enter_type': ['matured'] * num_new_matured + ['arrival'] * len(arrival_data),
        'age_year': [15] * num_new_matured + [age for age, _, _ in arrival_data],
        'HIV': [False] * num_new_matured + [hiv for _, hiv, _ in arrival_data],
        'PrEP': [False] * num_new_matured + [prep for _, _, prep in arrival_data]
    }).set_index('ID')
    
    # Set initial HIV and PrEP status for matured agents
    mature_mask = new_people['Enter_type'] == 'matured'
    hiv_prevalence = agents['HIV'].mean()
    prep_prevalence = agents[~agents['HIV']]['PrEP'].mean()
    new_people.loc[mature_mask, 'HIV'] = np.random.random(sum(mature_mask)) < hiv_prevalence
    mature_hiv_neg_mask = mature_mask & ~new_people['HIV']
    new_people.loc[mature_hiv_neg_mask, 'PrEP'] = np.random.random(sum(mature_hiv_neg_mask)) < prep_prevalence
    
    # Set SCC status for all agents
    # For matured agents: 89.9% require SCC
    new_people.loc[mature_mask, 'SCC_require'] = np.random.random(sum(mature_mask)) < 0.899
    
    # For arrival agents
    arrival_mask = new_people['Enter_type'] == 'arrival'
    # HIV positive: 41.5% require SCC
    hiv_pos_mask = arrival_mask & new_people['HIV']
    new_people.loc[hiv_pos_mask, 'SCC_require'] = np.random.random(sum(hiv_pos_mask)) < 0.415
    # HIV negative PrEP users: 79.7% require SCC
    prep_mask = arrival_mask & new_people['PrEP'] & ~new_people['HIV']
    new_people.loc[prep_mask, 'SCC_require'] = np.random.random(sum(prep_mask)) < 0.797
    # HIV negative non-PrEP users: 89.9% require SCC
    remaining_mask = arrival_mask & ~new_people['HIV'] & ~new_people['PrEP']
    new_people.loc[remaining_mask, 'SCC_require'] = np.random.random(sum(remaining_mask)) < 0.899
    
    # Set other attributes for new population
    new_people['group'] = np.random.choice(["only_regular", "only_casual", "both"], size=len(new_people), p=[0.226, 0.448, 0.326])
    casual_mask = new_people['group'] != 'only_regular'
    regular_mask = new_people['group'] != 'only_casual'
    new_people['ANCP'] = 0.0000001
    
    # Set ANCP values for different groups
    for mask, shape, scale in [
        (casual_mask & new_people['HIV'], 0.7, 35),
        (casual_mask & new_people['PrEP'] & ~new_people['HIV'], 1.1, 25),
        (casual_mask & ~new_people['HIV'] & ~new_people['PrEP'], 0.4, 20)
    ]:
        if mask.any():
            new_people.loc[mask, 'ANCP'] = np.random.gamma(shape=shape, scale=scale, size=mask.sum())
    
    # Set other attributes
    new_people['Dura_prefer_cas'] = np.clip(np.ceil(-np.log(np.random.uniform(0, 1, size=len(new_people))) * 52 / new_people['ANCP']), 1, 2).astype(int)
    
    # Initialize condom use columns with False
    new_people['Condom_Reg'] = False
    new_people['Condom_Cas'] = False
    
    # Set condom use probabilities for regular partnerships
    for mask, reg_p in [
        (regular_mask & new_people['HIV'], 9.1/100),
        (regular_mask & new_people['PrEP'] & ~new_people['HIV'], 26.1/100),
        (regular_mask & ~new_people['HIV'] & ~new_people['PrEP'], 6.1/100)
    ]:
        if mask.any():
            new_people.loc[mask, 'Condom_Reg'] = (np.random.random(mask.sum()) < reg_p * Always_condom_ratio).astype(bool)
    
    # Set condom use probabilities for casual partnerships
    for mask, cas_p in [
        (casual_mask & new_people['HIV'], 28.8/100),
        (casual_mask & new_people['PrEP'] & ~new_people['HIV'], 26.5/100),
        (casual_mask & ~new_people['HIV'] & ~new_people['PrEP'], 42.1/100)
    ]:
        if mask.any():
            new_people.loc[mask, 'Condom_Cas'] = (np.random.random(mask.sum()) < cas_p * Always_condom_ratio).astype(bool)
            
    # Set default values for other attributes
    default_columns = {
        'Reg_now': False, 'Cas_now': False, 'ANCP_real': 0, 'Lweek_52': 0, 'Test_interval_ave': 1/1.16 * 52,
        'Doxy-PEP': False, 'SCC_require': False, 'Doxy-PEP_Use': 0, 'NG_AMR_Cef': False, 'NG_AMR_Dox': False,
        'NG_Stage_Now': 'U', 'NG_Stage_Next': 'U', 'NG_Stage_Change_week': STI_t_U_to_U,
        'CT_Stage_Now': 'U', 'CT_Stage_Next': 'U', 'CT_Stage_Change_week': STI_t_U_to_U,
        'TP_Stage_Now': 'U', 'TP_Stage_Next': 'U', 'TP_Stage_Change_week': STI_t_U_to_U,
        'NG_Pos': False, 'CT_Pos': False, 'TP_Pos': False
    }
    for col, val in default_columns.items():
        new_people[col] = val

    # Set next screening time
    new_people.loc[new_people['PrEP'] & ~new_people['HIV'], 'Test_interval_ave'] = 1/2.04 * 52
    new_people.loc[new_people['PrEP'], 'Test_interval_ave'] = 100 / (249.8/(1 + np.exp(-0.647 * (week_cycle // 52 + 2009 - 2012.1)))) * 52
    new_people['Next_screen_week'] = week_cycle + np.round(new_people['Test_interval_ave'] * (1 + np.random.normal(0, 0.1, len(new_people)))).astype(int)
    
    # Calculate P_Ci and sexual behavior frequencies
    new_people['P_Ci'] = np.minimum(np.maximum((new_people['ANCP'] - new_people['ANCP_real']) / (52 - (week_cycle - new_people['Lweek_52'])), 0), 1)
    new_people['Prefer_Sex_Fre_Reg'] = -1.145 * new_people['age_year'] + 134.09
    new_people['Prefer_Sex_Fre_Cas'] = -0.4035 * new_people['age_year'] + 58.242
    
    # Set initial STI status based on current population rates
    for arrival_group_mask, rates in [
        ((new_people['Enter_type'] == 'arrival') & (~new_people['PrEP']) & (~new_people['HIV']), 
         {'NG': NG_Ini_Pos_Rate, 'CT': CT_Ini_Pos_Rate, 'TP': TP_Ini_Pos_Rate}),
        ((new_people['Enter_type'] == 'arrival') & (new_people['PrEP']), 
         {'NG': NG_Ini_Pos_Rate_PrEP_new, 'CT': CT_Ini_Pos_Rate_PrEP_new, 'TP': TP_Ini_Pos_Rate_PrEP_new}),
        ((new_people['Enter_type'] == 'arrival') & (new_people['HIV']), 
         {'NG': NG_Ini_Pos_Rate_HIV_new, 'CT': CT_Ini_Pos_Rate_HIV_new, 'TP': TP_Ini_Pos_Rate_HIV_new})
    ]:
        # Get indices of agents that satisfy the mask
        eligible_indices = new_people[arrival_group_mask].index
        
        for sti, rate in rates.items():
            # Generate random values only for eligible agents
            random_values = np.random.random(len(eligible_indices))
            # Determine which eligible agents get STI
            sti_positive_mask = random_values < rate
            # Get the actual indices of agents who will be STI positive
            sti_positive_indices = eligible_indices[sti_positive_mask]
            
            new_people.loc[sti_positive_indices, f'{sti}_Pos'] = True
            if sti == 'NG':
                # Use current population resistance rates instead of fixed rates
                new_people.loc[sti_positive_indices, 'NG_AMR_Cef'] = np.random.random(len(sti_positive_indices)) < NG_Ini_Cef_Res_Rate
                new_people.loc[sti_positive_indices, 'NG_AMR_Dox'] = np.random.random(len(sti_positive_indices)) < NG_Ini_Dox_Res_Rate
                new_people.loc[sti_positive_indices, 'NG_Stage_Now'] = 'E'
                new_people.loc[sti_positive_indices, 'NG_Stage_Next'] = np.random.choice(['Is', 'Ia'], size=len(sti_positive_indices), p=[NG_Sym_Proportion, 1-NG_Sym_Proportion])
                new_people.loc[sti_positive_indices, 'NG_Stage_Change_week'] = week_cycle + np.round(np.random.gamma(*NG_t_E_to_I, size=len(sti_positive_indices))).astype(int)
            elif sti == 'CT':
                new_people.loc[sti_positive_indices, 'CT_Stage_Now'] = 'E'
                new_people.loc[sti_positive_indices, 'CT_Stage_Next'] = np.random.choice(['Is', 'Ia'], size=len(sti_positive_indices), p=[CT_Sym_Proportion, 1-CT_Sym_Proportion])
                new_people.loc[sti_positive_indices, 'CT_Stage_Change_week'] = week_cycle + np.round(np.random.uniform(*CT_t_E_to_I, size=len(sti_positive_indices))).astype(int)
            elif sti == 'TP':
                new_people.loc[sti_positive_indices, 'TP_Stage_Now'] = 'E'
                new_people.loc[sti_positive_indices, 'TP_Stage_Next'] = np.random.choice(['I1s', 'I1a'], size=len(sti_positive_indices), p=[TP_I1_Sym_Proportion, 1-TP_I1_Sym_Proportion])
                new_people.loc[sti_positive_indices, 'TP_Stage_Change_week'] = week_cycle + np.round(np.random.gamma(*TP_t_E_to_I1, size=len(sti_positive_indices))).astype(int)
    
    # Update available sets
    Ra = Ra.union(new_people[new_people['group'].isin(['only_regular', 'both'])].index)
    Ca = Ca.union(new_people[new_people['group'].isin(['only_casual', 'both'])].index)
    
    # Reset matured agents' HIV and PrEP status to False
    new_people.loc[mature_mask, 'HIV'] = False
    new_people.loc[mature_mask, 'PrEP'] = False
    
    # Merge new and existing population
    agents = pd.concat([agents, new_people.drop(columns=['Enter_type'])])
    
    # Update PrEP status
    target_coverage = 32.3 / (1 + np.exp(-0.88 * ((week_cycle // 52 - 2 + 2012) - 2018.0))) / 100
    eligible_for_prep = agents[(agents['HIV'] == False) & (agents['PrEP'] == False)]
    if (num_new_users := int(len(agents[agents['HIV'] == False]) * target_coverage) - agents['PrEP'].sum()) > 0:
        prep_probs = eligible_for_prep['ANCP'].values / eligible_for_prep['ANCP'].sum()
        new_prep_users = np.random.choice(eligible_for_prep.index, size=num_new_users, replace=False, p=prep_probs)
        agents.loc[new_prep_users, 'PrEP'] = True
    
    # Update sexual behavior frequencies for all agents
    agents['Prefer_Sex_Fre_Reg'] = -1.145 * agents['age_year'] + 134.09
    agents['Prefer_Sex_Fre_Cas'] = -0.4035 * agents['age_year'] + 58.242
    
    return agents, Now_regular_partnerships, Now_casual_partnerships, All_casual_partnerships, Ra, Ca

# %% Fun 3. Assign gamma distribution ages
def assign_gamma_ages(N_agents, shape_param=1.71, scale_param=40, lower=15, upper=64):
    """
    Generate age distributions for agents using a truncated gamma distribution.

    This function creates age distributions that approximate real-world demographic
    patterns in sexual networks. The gamma distribution is truncated to ensure ages
    fall within a specified range, typically representing the sexually active population.

    Parameters:
    -----------
    N_agents : int
        Number of age samples to generate.
    shape_param : float, optional
        Shape parameter (k) of the gamma distribution. Default is 1.8.
    scale_param : float, optional
        Scale parameter (theta) of the gamma distribution. Default is 40.
    lower : int, optional
        Minimum age limit. Default is 15.
    upper : int, optional
        Maximum age limit. Default is 64.

    Returns:
    --------
    numpy.ndarray
        Array of integer ages following a truncated gamma distribution.

    Notes:
    ------
    - Uses rejection sampling to ensure all generated ages fall within [lower, upper]
    - Ages are rounded to the nearest integer
    - The distribution parameters are calibrated to match typical age distributions
      in sexual network studies
    """
    # Initialize a list to store the sampled ages
    sampled_ages = []

    # Use rejection sampling to generate samples within the specified age range
    while len(sampled_ages) < N_agents:
        # Generate samples from the gamma distribution using np.random.gamma
        sample = np.random.gamma(shape=shape_param, scale=scale_param, size=1000)
        # Keep only the samples within the specified range
        sample_in_range = sample[(sample >= lower) & (sample <= upper)]
        sampled_ages.extend(sample_in_range)

    # Limit the number of samples to exactly N_agents
    sampled_ages = np.array(sampled_ages[:N_agents])

    # Return the ages (in years), rounded to the nearest integer
    ages_year = np.round(sampled_ages).astype(int)

    return ages_year

# %% Fun 4. Update sex information
def Update_sex_info(agents, All_casual_partnerships, week_cycle):
    """
    Update sexual behavior metrics for agents based on their partnership history.

    This function calculates and updates several key sexual behavior metrics for each agent:
    - Actual number of casual partnerships (ANCP_real)
    - Last week of partnership formation (Lweek_52)
    - Probability of forming new casual partnerships (P_Ci)

    Parameters:
    -----------
    agents : pandas.DataFrame
        DataFrame containing agent information including current sexual behavior metrics.
    All_casual_partnerships : pandas.DataFrame
        DataFrame containing all casual partnerships with columns:
        - partner1, partner2: Agent IDs
        - end_week: Week when partnership ended
        - ini_week: Week when partnership started
    week_cycle : int
        Current simulation week.

    Returns:
    --------
    pandas.DataFrame
        Updated agents DataFrame with recalculated sexual behavior metrics.

    Notes:
    ------
    - ANCP_real is calculated from actual partnership data
    - Lweek_52 tracks the most recent partnership formation within the last 52 weeks
    - P_Ci represents the probability of forming new casual partnerships based on
      the difference between desired and actual number of partners
    """
    # Update ANCP_real
    partner_counts = pd.concat([
        All_casual_partnerships['partner1'],
        All_casual_partnerships['partner2']
    ]).value_counts()
    agents['ANCP_real'] = partner_counts.reindex(agents.index).fillna(0)

    # Update Lweek_52
    recent_ended_partnerships = All_casual_partnerships[
        (All_casual_partnerships['end_week'] > (week_cycle - 52)) &
        (All_casual_partnerships['ini_week'] <= week_cycle)
    ]
    earliest_end_week_52_partner1 = recent_ended_partnerships.groupby('partner1')['end_week'].min()
    earliest_end_week_52_partner2 = recent_ended_partnerships.groupby('partner2')['end_week'].min()
    earliest_end_week_52 = pd.concat([earliest_end_week_52_partner1, earliest_end_week_52_partner2], axis=0).groupby(level=0).min()
    agents['Lweek_52'] = earliest_end_week_52.reindex(agents.index).fillna(max(week_cycle - 51, 0)).astype(int)

    # Update P_Ci
    agents['P_Ci'] = np.minimum(np.maximum((agents['ANCP'] - agents['ANCP_real']) / (52 - (week_cycle - agents['Lweek_52'])), 0), 1)

    return agents

# %% Fun 5. Format regular partnerships
def Format_regular_partnership(agents, Ra, pairs, All_regular_partnerships, Now_regular_partnerships, week_cycle, sometime_condom_prob=0.5):
    """
    Create and format regular partnerships between agents.
    
    Parameters
    ----------
    agents : DataFrame
        DataFrame containing agent information
    Ra : set
        Set of available agents for regular partnerships
    pairs : DataFrame
        DataFrame containing partnership pairs
    All_regular_partnerships : DataFrame
        Historical record of all regular partnerships
    Now_regular_partnerships : DataFrame
        Current regular partnerships
    week_cycle : int
        Current week in the simulation
    default_condom_prob : float, optional
        Default condom use probability when not both partners prefer condom use (default: 0.5)
    """
    # Remove them from the available list
    Ra = Ra.difference(pairs['partner1']).difference(pairs['partner2'])

    # Update agents' Reg_now status
    agents.loc[pd.concat([pairs['partner1'], pairs['partner2']]).unique(), 'Reg_now'] = True

    # Set a random end week for the partnership
    pairs['total_duration'] = np.ceil(-(52*4) * np.log(np.random.uniform(size=len(pairs))))
    pairs['ini_week'] = week_cycle
    pairs['end_week'] = week_cycle + pairs['total_duration']

    # Calculate due_sexual_frequency (annual) and acts (duration)
    pairs['due_sexual_frequency'] = (agents.loc[pairs['partner1'], 'Prefer_Sex_Fre_Reg'].values +
                                 agents.loc[pairs['partner2'], 'Prefer_Sex_Fre_Reg'].values) / 2
    pairs['due_sexual_acts'] = np.maximum(pairs['due_sexual_frequency'] * pairs['total_duration'] / 52, 1)

    # Initialize past_sexual_acts and weekly_sex
    pairs['past_sexual_acts'] = 0
    pairs['weekly_sex_epi'] = 0
    pairs['condom_use_prob'] = np.where(
        (agents.loc[pairs['partner1'], 'Condom_Reg'].values > 0) & 
        (agents.loc[pairs['partner2'], 'Condom_Reg'].values > 0),
        1.0, sometime_condom_prob
    )
    pairs['weekly_condomless_sex_epi'] = 0

    # Add to regular_partnerships
    All_regular_partnerships = pd.concat([All_regular_partnerships, pairs[['partner1', 'partner2', 'ini_week', 'end_week']]], ignore_index=True)
    Now_regular_partnerships = pd.concat([Now_regular_partnerships, pairs[['partner1', 'partner2', 'ini_week', 'end_week', 'total_duration',
           'due_sexual_frequency', 'due_sexual_acts', 'past_sexual_acts', 'weekly_sex_epi', 'condom_use_prob',
           'weekly_condomless_sex_epi']]], ignore_index=True)

    return agents, Ra, All_regular_partnerships, Now_regular_partnerships

# %% Fun 6. Format casual partnerships
def Format_casual_partnership(agents, Ca, pairs, All_casual_partnerships, Now_casual_partnerships, week_cycle, sometime_condom_prob=0.5):
    """
    Create and format casual partnerships between agents.
    
    Parameters
    ----------
    agents : DataFrame
        DataFrame containing agent information
    Ca : set
        Set of available agents for casual partnerships
    pairs : DataFrame
        DataFrame containing partnership pairs
    All_casual_partnerships : DataFrame
        Historical record of all casual partnerships
    Now_casual_partnerships : DataFrame
        Current casual partnerships
    week_cycle : int
        Current week in the simulation
    default_condom_prob : float, optional
        Default condom use probability when not both partners prefer condom use (default: 0.5)
    """
    # Remove them from the available list
    Ca = Ca.difference(pairs['partner1']).difference(pairs['partner2'])

    # Update agents' Cas_now status
    agents.loc[pd.concat([pairs['partner1'], pairs['partner2']]).unique(), 'Cas_now'] = True

    # Set a random end week for the partnership
    pairs['total_duration'] = np.minimum(
        agents.loc[pairs['partner1'], 'Dura_prefer_cas'].values,
        agents.loc[pairs['partner2'], 'Dura_prefer_cas'].values
    )
    pairs['ini_week'] = week_cycle
    pairs['end_week'] = week_cycle + pairs['total_duration']

    # Calculate due_sexual_frequency (annual) and acts (duration)
    pairs['due_sexual_frequency'] = (agents.loc[pairs['partner1'], 'Prefer_Sex_Fre_Cas'].values +
                                     agents.loc[pairs['partner2'], 'Prefer_Sex_Fre_Cas'].values) / 2
    pairs['due_sexual_acts'] = np.maximum(pairs['due_sexual_frequency'] * pairs['total_duration'] / 52, 1)

    # Initialize past_sexual_acts and weekly_sex
    pairs['past_sexual_acts'] = 0
    pairs['weekly_sex_epi'] = 0

    # Calculate condom use probability
    pairs['condom_use_prob'] = np.where(
        agents.loc[pairs['partner1'], 'Condom_Cas'].values &
        agents.loc[pairs['partner2'], 'Condom_Cas'].values,
        1.0, sometime_condom_prob
    )
    pairs['weekly_condomless_sex_epi'] = 0

    # Add to casual_partnerships
    All_casual_partnerships = pd.concat([All_casual_partnerships, pairs[['partner1', 'partner2', 'ini_week', 'end_week']]], ignore_index=True)
    Now_casual_partnerships = pd.concat([Now_casual_partnerships, pairs], ignore_index=True)

    return agents, Ca, All_casual_partnerships, Now_casual_partnerships

# %% Fun 7. Calculate sex act probability
def Calculate_sex_act_prob(Partnership_df, week_cycle):
    """
    Calculate sexual activity probabilities and occurrences within partnerships.

    This function determines the probability and actual occurrence of sexual acts
    within partnerships for a given week, taking into account partnership duration
    and preferred sexual frequency. It also calculates condomless sexual episodes
    for Doxy-PEP usage assessment.

    Parameters:
    -----------
    Partnership_df : pandas.DataFrame
        DataFrame containing partnership information including:
        - due_sexual_acts: Total expected sexual acts
        - past_sexual_acts: Already occurred sexual acts
        - end_week: Partnership end week
        - total_duration: Total partnership duration
        - condom_use_prob: Probability of condom use
    week_cycle : int
        Current simulation week.

    Returns:
    --------
    pandas.DataFrame
        Updated partnership DataFrame with new columns:
        - daily_prob_sex: Daily probability of sexual activity
        - weekly_sex_epi: Number of sexual episodes in the week
        - weekly_condomless_sex_epi: Number of condomless episodes
        - past_sexual_acts: Updated count of past sexual acts

    Notes:
    ------
    - Daily probability is calculated based on remaining sexual acts and time
    - Weekly occurrences follow a binomial distribution
    - One-week partnerships are guaranteed at least one occurrence
    - Condomless episodes are calculated for Doxy-PEP effectiveness assessment
    """
    # Calculate daily probability of sexual act based on a weekly scale, divided by 7 for daily probability
    Partnership_df['daily_prob_sex'] = (
        (Partnership_df['due_sexual_acts'] - Partnership_df['past_sexual_acts']).clip(lower=0) /
        (Partnership_df['end_week'] - week_cycle).clip(lower=1e-7)
    ).clip(upper=1) / 7

    # Calculate weekly occurrences based on daily probability times 7 days
    Partnership_df['weekly_sex_epi'] = np.random.binomial(7, Partnership_df['daily_prob_sex'])

    # Ensure one-week partnerships have at least one occurrence
    Partnership_df.loc[Partnership_df['total_duration'] == 1, 'weekly_sex_epi'] = np.maximum(1, Partnership_df.loc[Partnership_df['total_duration'] == 1, 'weekly_sex_epi'])

    # Calculate the weekly condomless sex episode, to calculate the use of doxy-PEP
    Partnership_df['weekly_condomless_sex_epi'] = np.random.binomial(Partnership_df['weekly_sex_epi'], 1 - Partnership_df['condom_use_prob'])

    # Update the count of past sexual acts
    Partnership_df['past_sexual_acts'] += Partnership_df['weekly_sex_epi']

    return Partnership_df

# %% Fun 8. Initialize infection status
def Initialize_infection_status(agents, week_cycle):
    """
    Initialize STI infection statuses and progression parameters for agents.

    This function sets up the initial infection states for Neisseria gonorrhoeae (NG),
    Chlamydia trachomatis (CT), and Treponema pallidum (TP) for all agents. It includes
    infection status, antibiotic resistance traits, and stage progression parameters.

    Parameters:
    -----------
    agents : pandas.DataFrame
        DataFrame containing agent information.
    week_cycle : int
        Current simulation week.

    Returns:
    --------
    pandas.DataFrame
        Updated agents DataFrame with new columns for each STI:
        - {STI}_Pos: Boolean indicating infection status
        - {STI}_AMR_Cef: Boolean for cephalosporin resistance (NG only)
        - {STI}_AMR_Dox: Boolean for doxycycline resistance (NG only)
        - {STI}_Stage_Now: Current infection stage
        - {STI}_Stage_Next: Next stage in progression
        - {STI}_Stage_Change_week: Week when stage change occurs

    Notes:
    ------
    - Initial prevalence rates are based on epidemiological data for HIV-negative non-PrEP users
    - Different prevalence rates are applied for HIV-positive and PrEP users using ratio parameters
    - Stage progression follows predefined transition probabilities
    - Time to next stage follows gamma distributions
    - Antibiotic resistance is initialized for NG only
    - Stages include: U (uninfected), E (exposed), Is (symptomatic), Ia (asymptomatic)
    """

    # Create masks for different population groups
    hiv_neg_non_prep_mask = (~agents['HIV']) & (~agents['PrEP'])
    hiv_pos_mask = agents['HIV']
    prep_user_mask = agents['PrEP']

    # NG initialization
    agents.loc[hiv_neg_non_prep_mask, 'NG_Pos'] = np.random.choice([True, False], 
                                                                 size=hiv_neg_non_prep_mask.sum(), 
                                                                 p=[NG_Ini_Pos_Rate, 1-NG_Ini_Pos_Rate])
    agents.loc[hiv_pos_mask, 'NG_Pos'] = np.random.choice([True, False], 
                                                        size=hiv_pos_mask.sum(), 
                                                        p=[NG_Ini_Pos_Rate_HIV_new, 1-NG_Ini_Pos_Rate_HIV_new])
    agents.loc[prep_user_mask, 'NG_Pos'] = np.random.choice([True, False], 
                                                         size=prep_user_mask.sum(), 
                                                         p=[NG_Ini_Pos_Rate_PrEP_new, 1-NG_Ini_Pos_Rate_PrEP_new])

    agents['NG_AMR_Cef'] = [np.random.choice([True, False], p=[NG_Ini_Cef_Res_Rate, 1-NG_Ini_Cef_Res_Rate]) if pos else False for pos in agents['NG_Pos']]
    agents['NG_AMR_Dox'] = [np.random.choice([True, False], p=[NG_Ini_Dox_Res_Rate, 1-NG_Ini_Dox_Res_Rate]) if pos else False for pos in agents['NG_Pos']]
    agents['NG_Stage_Now'] = np.where(agents['NG_Pos'], 'E', 'U')

    # Initialize NG Stage Change week and Next Stage
    agents['NG_Stage_Next'] = 'U'  # Default to 'U'
    agents['NG_Stage_Change_week'] = STI_t_U_to_U

    # Update NG Stage Next and Change week based on current stage
    # E to Is or Ia
    NG_E_mask = agents['NG_Stage_Now'] == 'E'
    agents.loc[NG_E_mask, 'NG_Stage_Next'] = np.random.choice(['Is', 'Ia'], size=NG_E_mask.sum(), p=[NG_Sym_Proportion, 1-NG_Sym_Proportion])
    agents.loc[NG_E_mask, 'NG_Stage_Change_week'] = week_cycle + np.round(np.random.gamma(*NG_t_E_to_I, size=NG_E_mask.sum())).astype(int)

    # CT initialization
    agents.loc[hiv_neg_non_prep_mask, 'CT_Pos'] = np.random.choice([True, False], 
                                                                 size=hiv_neg_non_prep_mask.sum(), 
                                                                 p=[CT_Ini_Pos_Rate, 1-CT_Ini_Pos_Rate])
    agents.loc[hiv_pos_mask, 'CT_Pos'] = np.random.choice([True, False], 
                                                        size=hiv_pos_mask.sum(), 
                                                        p=[CT_Ini_Pos_Rate * CT_Ini_Pos_Rate_HIV_new, 1-CT_Ini_Pos_Rate * CT_Ini_Pos_Rate_HIV_new])
    agents.loc[prep_user_mask, 'CT_Pos'] = np.random.choice([True, False], 
                                                         size=prep_user_mask.sum(), 
                                                         p=[CT_Ini_Pos_Rate * CT_Ini_Pos_Rate_PrEP_new, 1-CT_Ini_Pos_Rate * CT_Ini_Pos_Rate_PrEP_new])

    agents['CT_Stage_Now'] = np.where(agents['CT_Pos'], 'E', 'U')

    # Initialize CT Stage Change week and Next Stage
    agents['CT_Stage_Next'] = 'U'  # Default to 'U'
    agents['CT_Stage_Change_week'] = STI_t_U_to_U

    # Update CT Stage Next and Change week based on current stage
    # E to Is or Ia
    CT_E_mask = agents['CT_Stage_Now'] == 'E'
    agents.loc[CT_E_mask, 'CT_Stage_Next'] = np.random.choice(['Is', 'Ia'], size=CT_E_mask.sum(), p=[CT_Sym_Proportion, 1 - CT_Sym_Proportion])
    agents.loc[CT_E_mask, 'CT_Stage_Change_week'] = week_cycle + np.round(np.random.uniform(*CT_t_E_to_I, size=CT_E_mask.sum())).astype(int)

    # TP initialization
    agents.loc[hiv_neg_non_prep_mask, 'TP_Pos'] = np.random.choice([True, False], 
                                                                 size=hiv_neg_non_prep_mask.sum(), 
                                                                 p=[TP_Ini_Pos_Rate, 1-TP_Ini_Pos_Rate])
    agents.loc[hiv_pos_mask, 'TP_Pos'] = np.random.choice([True, False], 
                                                        size=hiv_pos_mask.sum(), 
                                                        p=[TP_Ini_Pos_Rate_HIV_new, 1-TP_Ini_Pos_Rate_HIV_new])
    agents.loc[prep_user_mask, 'TP_Pos'] = np.random.choice([True, False], 
                                                         size=prep_user_mask.sum(), 
                                                         p=[TP_Ini_Pos_Rate_PrEP_new, 1-TP_Ini_Pos_Rate_PrEP_new])

    # Initialize TP Stage Now
    agents['TP_Stage_Now'] = np.where(agents['TP_Pos'],'E','U')
    # Initialize TP Stage Change week and Next Stage
    agents['TP_Stage_Next'] = 'U'  # Default to 'U'
    agents['TP_Stage_Change_week'] = STI_t_U_to_U

    # Update TP Stage Next and Change week based on current stage
    # E to I1 (I1s or I1a)
    TP_E_mask = agents['TP_Stage_Now'] == 'E'
    agents.loc[TP_E_mask, 'TP_Stage_Next'] = np.random.choice(['I1s', 'I1a'], size=TP_E_mask.sum(), p=[TP_I1_Sym_Proportion, 1 - TP_I1_Sym_Proportion])
    agents.loc[TP_E_mask, 'TP_Stage_Change_week'] = week_cycle + np.round(np.random.gamma(*TP_t_E_to_I1, size=TP_E_mask.sum())).astype(int)

    return agents

# %% Fun 9. Assign average test interval
def Assign_average_test_interval(agents):
    """
    Update the 'Test_frequency' attribute for each agent based on their 'ANCP' value.

    Parameters:
    agents (DataFrame): The DataFrame containing agent data.

    Returns:
    DataFrame: The updated agents DataFrame with the 'Test_frequency' attribute.
    """
    for mask, interval in [
        (agents['HIV'], 1/2.04 * 52),
        (agents['PrEP'] & ~agents['HIV'], 100 / (249.8/(1 + np.exp(-0.647 * (2012 - 2012.1)))) * 52),
        (~agents['HIV'] & ~agents['PrEP'], 1/1.16 * 52)
    ]:
        if mask.any():
            agents.loc[mask, 'Test_interval_ave'] = interval
    
    return agents

# %% Fun 11. Filter transmission pairs
def Filter_transmission_pairs(agents, Weekly_sex_pairs):
    """
    Create a DataFrame of pairs that are at risk of transmitting STIs based on transmission probability thresholds.
    Each pair includes a transmissible agent and a susceptible agent.

    Parameters:
    agents (DataFrame): DataFrame containing the agents' data including their STI stages.

    (DataFrame): DataFrame containing pairs of partners that have weekly_sex > 0.
    STI_trans_probs (dict): Dictionary containing the transmission probability thresholds for each STI.
    Condom_protection (float): The effectiveness of condoms in preventing STI transmission.

    Returns:
    DataFrame: A DataFrame containing columns ['partner1', 'partner2', 'STI'].
                Only pairs where the random value less than the transmission threshold are included.
    """

    # Define transmissible and susceptible stages for each STI
    sti_stages = {
        'NG': {'transmissible': ['Is', 'Ia']},
        'CT': {'transmissible': ['Is', 'Ia']},
        'TP': {'transmissible': ['I1a', 'I1s', 'EL1', 'I2a', 'I2s', 'EL2']}
    }

    # # Calculate number of condomless acts using binomial sampling
    # Weekly_sex_pairs['weekly_condomless_sex_epi'] = np.random.binomial(Weekly_sex_pairs['weekly_sex_epi'], 1 - Weekly_sex_pairs['condom_use_prob'])

    # Initialize an empty DataFrame to store transmission pairs
    Transmission_pairs = pd.DataFrame(columns=['partner1', 'partner2', 'STI', 'weekly_sex_epi', 'weekly_condomless_sex_epi'])

    for sti, stages in sti_stages.items():
        # Find indexes (IDs) of transmissible and susceptible agents
        trans_agents = agents.index[agents[f'{sti}_Stage_Now'].isin(stages['transmissible'])]
        suscept_agents = agents.index[agents[f'{sti}_Stage_Now'] == 'U']

        # Filter potential transmission pairs
        trans_pairs = Weekly_sex_pairs[
            ((Weekly_sex_pairs['partner1'].isin(trans_agents) & Weekly_sex_pairs['partner2'].isin(suscept_agents)) |
             (Weekly_sex_pairs['partner2'].isin(trans_agents) & Weekly_sex_pairs['partner1'].isin(suscept_agents)))
        ].copy()
        trans_pairs['STI'] = sti

        # Select pairs with transmission probability
        trans_pairs_final = trans_pairs[(np.random.binomial(trans_pairs['weekly_condomless_sex_epi'], STI_trans_probs[sti]) + \
                           np.random.binomial(trans_pairs['weekly_sex_epi'] - trans_pairs['weekly_condomless_sex_epi'], STI_trans_probs[sti] * (1 - Condom_protection))) > 0]

        # Ensure partner1 is always the transmissible agent
        trans_to_swap = trans_pairs_final['partner2'].isin(trans_agents)
        trans_pairs_final.loc[trans_to_swap, ['partner1', 'partner2']] = trans_pairs_final.loc[trans_to_swap, ['partner2', 'partner1']].values

        # Append to the main DataFrame
        Transmission_pairs = pd.concat([Transmission_pairs, trans_pairs_final], ignore_index=True)

    return Transmission_pairs

# %% Fun 12. STI transmission
def STI_transmission(agents, Transmission_pairs, Weekly_new_infections, week_cycle):
    """
    Simulate the transmission of sexually transmitted infections (STIs) across a given set of transmission pairs,
    update the agents' infection statuses, and record new infections daily.

    Parameters:
    agents (DataFrame): DataFrame containing agents' data including their current STI states and Doxy-PEP status.
    Transmission_pairs (DataFrame): DataFrame of pairs that potentially transmit STIs during sexual encounters.
    Weekly_new_infections (DataFrame): DataFrame to log daily new infections for each STI type.
    week_cycle (int): The current simulation week.

    Returns:
    tuple: Updated agents DataFrame and Weekly_new_infections DataFrame.
    """

    STI_params = {
    'NG': {'next_stages': ['Is', 'Ia'], 'sym_prop': [NG_Sym_Proportion, 1-NG_Sym_Proportion], 'time_to_i': NG_t_E_to_I},
    'CT': {'next_stages': ['Is', 'Ia'], 'sym_prop': [CT_Sym_Proportion, 1-CT_Sym_Proportion], 'time_to_i': CT_t_E_to_I},
    'TP': {'next_stages': ['I1s', 'I1a'], 'sym_prop': [TP_I1_Sym_Proportion, 1-TP_I1_Sym_Proportion], 'time_to_i': TP_t_E_to_I1}
}

    # Process each STI type separately
    for sti in STI_params.keys():
        sti_pairs = Transmission_pairs[Transmission_pairs['STI'] == sti].copy()
        if sti_pairs.empty:
            continue
        doxy_pep_values = agents.loc[sti_pairs['partner2'], 'Doxy-PEP'].values
        if sti == 'NG':

            # Determine if Doxy-PEP induces Doxycycline resistance
            ng_amr_dox_before_PEP = agents.loc[sti_pairs['partner1'], 'NG_AMR_Dox'].values
            sti_pairs['doxy_pep_effect'] = np.where(
                (doxy_pep_values) & (sti_pairs['weekly_condomless_sex_epi'] > 0),
                Doxy_PEP_Efficacy[sti] * Doxy_PEP_Adherence * (~ng_amr_dox_before_PEP),
                0
            )

            transmitted = np.random.rand(len(sti_pairs)) > sti_pairs['doxy_pep_effect']
            transmitted_indices = sti_pairs.loc[transmitted, 'partner2']
            
            # Update resistance traits from partner1 to partner2
            agents.loc[transmitted_indices, 'NG_AMR_Cef'] = agents.loc[sti_pairs.loc[transmitted, 'partner1'], 'NG_AMR_Cef'].values
            agents.loc[transmitted_indices, 'NG_AMR_Dox'] = agents.loc[sti_pairs.loc[transmitted, 'partner1'], 'NG_AMR_Dox'].values

            Weekly_new_infections.loc[Weekly_new_infections['week'] == week_cycle, [
                'NG_new_Cef_infections',
                'NG_new_Dox_infections',
                'NG_new_Double_infections',
                'NG_new_AMS_infections'
            ]] += [
                (agents.loc[transmitted_indices, 'NG_AMR_Cef'] & ~agents.loc[transmitted_indices, 'NG_AMR_Dox']).sum(),  # Cef only
                (agents.loc[transmitted_indices, 'NG_AMR_Dox'] & ~agents.loc[transmitted_indices, 'NG_AMR_Cef']).sum(),  # Dox only
                (agents.loc[transmitted_indices, 'NG_AMR_Cef'] & agents.loc[transmitted_indices, 'NG_AMR_Dox']).sum(),   # Both Cef and Dox
                (~agents.loc[transmitted_indices, 'NG_AMR_Cef'] & ~agents.loc[transmitted_indices, 'NG_AMR_Dox']).sum()  # Neither
            ]

            hiv_pos_mask = agents.loc[transmitted_indices, 'HIV']
            Weekly_new_infections.loc[Weekly_new_infections['week'] == week_cycle, 'NG_new_infections_HIV_True'] += hiv_pos_mask.sum()

            hiv_neg_mask = ~agents.loc[transmitted_indices, 'HIV']
            prep_mask = agents.loc[transmitted_indices, 'PrEP']
            Weekly_new_infections.loc[Weekly_new_infections['week'] == week_cycle, 'NG_new_infections_PrEP_True'] += (hiv_neg_mask & prep_mask).sum()
            Weekly_new_infections.loc[Weekly_new_infections['week'] == week_cycle, 'NG_new_infections_PrEP_False'] += (hiv_neg_mask & ~prep_mask).sum()

        else:
            # Apply Doxy-PEP effect normally for CT and TP
            sti_pairs['doxy_pep_effect'] = np.where(
                (doxy_pep_values) & (sti_pairs['weekly_condomless_sex_epi'] > 0),
                Doxy_PEP_Efficacy[sti] * Doxy_PEP_Adherence,
                0
            )
            transmitted = np.random.rand(len(sti_pairs)) > sti_pairs['doxy_pep_effect']
            transmitted_indices = sti_pairs.loc[transmitted, 'partner2']

            hiv_pos_mask = agents.loc[transmitted_indices, 'HIV']
            Weekly_new_infections.loc[Weekly_new_infections['week'] == week_cycle, f'{sti}_new_infections_HIV_True'] += hiv_pos_mask.sum()

            hiv_neg_mask = ~agents.loc[transmitted_indices, 'HIV']
            prep_mask = agents.loc[transmitted_indices, 'PrEP']
            Weekly_new_infections.loc[Weekly_new_infections['week'] == week_cycle, f'{sti}_new_infections_PrEP_True'] += (hiv_neg_mask & prep_mask).sum()
            Weekly_new_infections.loc[Weekly_new_infections['week'] == week_cycle, f'{sti}_new_infections_PrEP_False'] += (hiv_neg_mask & ~prep_mask).sum()

        Weekly_new_infections.loc[Weekly_new_infections['week'] == week_cycle, f'{sti}_new_infections'] += transmitted.sum()

        # Update infection status and stages
        agents.loc[transmitted_indices, f'{sti}_Pos'] = True
        agents.loc[transmitted_indices, f'{sti}_Stage_Now'] = 'E'
        agents.loc[transmitted_indices, f'{sti}_Stage_Next'] = np.random.choice(STI_params[sti]['next_stages'], p=STI_params[sti]['sym_prop'], size=len(transmitted_indices))
        agents.loc[transmitted_indices, f'{sti}_Stage_Change_week'] = week_cycle + np.round(np.random.gamma(*STI_params[sti]['time_to_i'], size=len(transmitted_indices))).astype(int)
    
    Weekly_new_infections.loc[Weekly_new_infections['week'] == week_cycle, 'All_new_infections'] = (
        Weekly_new_infections.loc[Weekly_new_infections['week'] == week_cycle, 'NG_new_infections'] +
        Weekly_new_infections.loc[Weekly_new_infections['week'] == week_cycle, 'CT_new_infections'] +
        Weekly_new_infections.loc[Weekly_new_infections['week'] == week_cycle, 'TP_new_infections']
    )
    
    return agents, Weekly_new_infections

# %% Fun 13. Update STI stage progress screening treatment
def Update_STI_Stage_progress_screening_treatment(agents, Weekly_screened_diagnosis, week_cycle):
    """
    Update the progression, screening, treatment, and Doxy-PEP usage for STI stages in the simulation.
    This function handles the transitions between different stages of infection based on the current week
    in the simulation cycle, applies treatments, and manages screening for various STIs.

    Parameters:
    agents (DataFrame): Contains individual agent data, including current STI stages and screening schedule.
    Weekly_screened_diagnosis (DataFrame): Logs daily screening and diagnosis outcomes.
    week_cycle (int): Current week in the simulation cycle used to determine timing-specific actions.

    Returns:
    tuple: Updated agents DataFrame and Weekly_screened_diagnosis DataFrame.
    """
# 1.Progress of STIs : Update the stage next and chage week (Exclude those infections with symptoms)
#   1.1 Progress of NG =============================================================================
    # NG: E to Is or Ia
    NG_E_mask = (agents['NG_Stage_Now'] == 'E') & (agents['NG_Stage_Change_week'] == week_cycle)
    agents.loc[NG_E_mask, 'NG_Stage_Now'] = agents.loc[NG_E_mask, 'NG_Stage_Next']
    agents.loc[NG_E_mask, 'NG_Stage_Next'] = np.where(agents.loc[NG_E_mask, 'NG_Stage_Now'] == 'Is', 'T', 'U')
    agents.loc[NG_E_mask, 'NG_Stage_Change_week'] = week_cycle + np.where(agents.loc[NG_E_mask, 'NG_Stage_Now'] == 'Is',
                                                            np.round(np.random.uniform(*Sym_Driven_Treat, size=NG_E_mask.sum())).astype(int),
                                                            np.round(np.random.gamma(*NG_t_Ia_to_U, size=NG_E_mask.sum())).astype(int))
    # NG: Ia to U
    NG_Ia_mask = (agents['NG_Stage_Now'] == 'Ia') & (agents['NG_Stage_Change_week'] == week_cycle)
    agents.loc[NG_Ia_mask, 'NG_Stage_Now'] = agents.loc[NG_Ia_mask, 'NG_Stage_Next']
    agents.loc[NG_Ia_mask, 'NG_Pos'] = False
    agents.loc[NG_Ia_mask, 'NG_Stage_Next'] = 'U'
    agents.loc[NG_Ia_mask, 'NG_Stage_Change_week'] = STI_t_U_to_U

    # NG: T to Ia or U
    NG_T_mask = (agents['NG_Stage_Now'] == 'T') & (agents['NG_Stage_Change_week'] == week_cycle)
    agents.loc[NG_T_mask, 'NG_Stage_Now'] = agents.loc[NG_T_mask, 'NG_Stage_Next']
    agents.loc[NG_T_mask, 'NG_Pos'] = np.where(agents.loc[NG_T_mask, 'NG_Stage_Now'] == 'U', False, True)
    agents.loc[NG_T_mask, 'NG_AMR_Cef'] = ~(agents.loc[NG_T_mask, 'NG_Stage_Now'].isin(['U']))
    agents.loc[NG_T_mask, 'NG_AMR_Dox'] = np.where(agents.loc[NG_T_mask, 'NG_Stage_Now'] == 'U', False, agents.loc[NG_T_mask, 'NG_AMR_Dox'])
    agents.loc[NG_T_mask, 'NG_Stage_Next'] = np.where(agents.loc[NG_T_mask, 'NG_Stage_Now'] == 'Is', 'T', 'U')
    agents.loc[NG_T_mask, 'NG_Stage_Change_week'] = week_cycle + np.select([agents.loc[NG_T_mask, 'NG_Stage_Now'] == 'U',
                                                                          agents.loc[NG_T_mask, 'NG_Stage_Now'] == 'Ia'],
                                                                         [STI_t_U_to_U,
                                                                          np.round(np.random.gamma(*NG_t_Ia_to_U, size=NG_T_mask.sum())).astype(int)],
                                                                         default=np.round(np.random.uniform(*Sym_Driven_Treat, size=NG_T_mask.sum())).astype(int)
                                                                    )
# =============================================================================

#  1.2 Progress of CT =============================================================================
    # CT: E to Is or Ia
    CT_E_mask = (agents['CT_Stage_Now'] == 'E') & (agents['CT_Stage_Change_week'] == week_cycle)
    agents.loc[CT_E_mask, 'CT_Stage_Now'] = agents.loc[CT_E_mask, 'CT_Stage_Next']
    agents.loc[CT_E_mask, 'CT_Stage_Next'] = np.where(agents.loc[CT_E_mask, 'CT_Stage_Now'] == 'Is', 'T', 'U')
    agents.loc[CT_E_mask, 'CT_Stage_Change_week'] = week_cycle + np.where(agents.loc[CT_E_mask, 'CT_Stage_Now'] == 'Is',
                                                            np.round(np.random.uniform(*Sym_Driven_Treat, size=CT_E_mask.sum()).astype(int)),
                                                            np.round(np.random.gamma(*CT_t_Ia_to_U, size=CT_E_mask.sum())).astype(int))

    # CT: Ia to U
    CT_Ia_mask = (agents['CT_Stage_Now'] == 'Ia') & (agents['CT_Stage_Change_week'] == week_cycle)
    agents.loc[CT_Ia_mask, 'CT_Stage_Now'] = agents.loc[CT_Ia_mask, 'CT_Stage_Next']
    agents.loc[CT_Ia_mask, ['CT_Pos', 'CT_Stage_Next','CT_Stage_Change_week' ]] = [False, 'U', STI_t_U_to_U]

    # CT: T to U
    CT_T_mask = (agents['CT_Stage_Now'] == 'T') & (agents['CT_Stage_Change_week'] == week_cycle)
    agents.loc[CT_T_mask, 'CT_Stage_Now'] = agents.loc[CT_T_mask, 'CT_Stage_Next']
    agents.loc[CT_T_mask, ['CT_Pos', 'CT_Stage_Next','CT_Stage_Change_week' ]] = [False, 'U', STI_t_U_to_U]
# =============================================================================

#   1.3 Progress of TP =============================================================================
    # TP: E to I1s or I1a
    TP_E_mask = (agents['TP_Stage_Now'] == 'E') & (agents['TP_Stage_Change_week'] == week_cycle)
    agents.loc[TP_E_mask, 'TP_Stage_Now'] = agents.loc[TP_E_mask, 'TP_Stage_Next']
    agents.loc[TP_E_mask, 'TP_Stage_Next'] = np.where(agents.loc[TP_E_mask, 'TP_Stage_Now'] == 'I1s', 'T1', 'EL1')

    agents.loc[TP_E_mask, 'TP_Stage_Change_week'] = week_cycle + np.where(agents.loc[TP_E_mask, 'TP_Stage_Now'] == 'I1s',
                                                                          np.round(np.random.uniform(*Sym_Driven_Treat, size=TP_E_mask.sum())).astype(int),
                                                                          np.round(np.random.gamma(*TP_t_I1_to_EL1, size=TP_E_mask.sum())).astype(int))

    # TP: I1a to EL1
    TP_I1a_mask = (agents['TP_Stage_Now'] == 'I1a') & (agents['TP_Stage_Change_week'] == week_cycle)
    agents.loc[TP_I1a_mask, 'TP_Stage_Now'] = agents.loc[TP_I1a_mask, 'TP_Stage_Next']
    agents.loc[TP_I1a_mask, 'TP_Stage_Next'] = np.random.choice(['I2s', 'I2a'], size=TP_I1a_mask.sum())
    agents.loc[TP_I1a_mask, 'TP_Stage_Change_week'] = week_cycle + np.round(np.random.gamma(*TP_t_EL1_to_I2, size=TP_I1a_mask.sum())).astype(int)

    # TP: EL1 to I2s or I2a
    TP_EL1_mask = (agents['TP_Stage_Now'] == 'EL1') & (agents['TP_Stage_Change_week'] == week_cycle)
    agents.loc[TP_EL1_mask, 'TP_Stage_Now'] = agents.loc[TP_EL1_mask, 'TP_Stage_Next']
    agents.loc[TP_EL1_mask, 'TP_Stage_Next'] = np.where(agents.loc[TP_EL1_mask, 'TP_Stage_Now'] == 'I2s', 'T1', 'EL2')
    agents.loc[TP_EL1_mask, 'TP_Stage_Change_week'] = week_cycle + np.where(agents.loc[TP_EL1_mask, 'TP_Stage_Now'] == 'I2s',
                                                                            np.round(np.random.uniform(*Sym_Driven_Treat, size=TP_EL1_mask.sum())).astype(int),
                                                                            np.round(np.random.gamma(*TP_t_I2_to_EL2, size=TP_EL1_mask.sum())).astype(int))

    # TP: I2a to EL2
    TP_I2a_mask = (agents['TP_Stage_Now'] == 'I2a') & (agents['TP_Stage_Change_week'] == week_cycle)
    agents.loc[TP_I2a_mask, 'TP_Stage_Now'] = agents.loc[TP_I2a_mask, 'TP_Stage_Next']
    agents.loc[TP_I2a_mask, 'TP_Stage_Next'] = 'LL'
    agents.loc[TP_I2a_mask, 'TP_Stage_Change_week'] = week_cycle + np.round(np.random.gamma(*TP_t_EL2_to_LL, size=TP_I2a_mask.sum())).astype(int)

    # TP: EL2 to LL
    TP_EL2_mask = (agents['TP_Stage_Now'] == 'EL2') & (agents['TP_Stage_Change_week'] == week_cycle)
    agents.loc[TP_EL2_mask, 'TP_Stage_Now'] = agents.loc[TP_EL2_mask, 'TP_Stage_Next']
    agents.loc[TP_EL2_mask, 'TP_Stage_Next'] = 'I3'
    agents.loc[TP_EL2_mask, 'TP_Stage_Change_week'] = week_cycle + np.round(52 * np.random.gamma(*TP_t_LL_to_I3, size=TP_EL2_mask.sum())).astype(int)

    # TP: LL to I3
    TP_LL_mask = (agents['TP_Stage_Now'] == 'LL') & (agents['TP_Stage_Change_week'] == week_cycle)
    agents.loc[TP_LL_mask, 'TP_Stage_Now'] = agents.loc[TP_LL_mask, 'TP_Stage_Next']
    agents.loc[TP_LL_mask, 'TP_Stage_Next'] = 'T2'
    agents.loc[TP_LL_mask, 'TP_Stage_Change_week'] = week_cycle + np.round(np.random.uniform(*Sym_Driven_Treat, size=TP_LL_mask.sum())).astype(int)

    # TP: T1 to U
    TP_T1_mask = (agents['TP_Stage_Now'] == 'T1') & (agents['TP_Stage_Change_week'] == week_cycle)
    agents.loc[TP_T1_mask, 'TP_Stage_Now'] = agents.loc[TP_T1_mask, 'TP_Stage_Next']
    agents.loc[TP_T1_mask, 'TP_Pos'] = False
    agents.loc[TP_T1_mask, 'TP_Stage_Next'] = 'U'
    agents.loc[TP_T1_mask, 'TP_Stage_Change_week'] = STI_t_U_to_U

    # TP: T2 to U
    TP_T2_mask = (agents['TP_Stage_Now'] == 'T2') & (agents['TP_Stage_Change_week'] == week_cycle)
    agents.loc[TP_T2_mask, 'TP_Stage_Now'] = agents.loc[TP_T2_mask, 'TP_Stage_Next']
    agents.loc[TP_T2_mask, 'TP_Pos'] = False
    agents.loc[TP_T2_mask, 'TP_Stage_Next'] = 'U'
    agents.loc[TP_T2_mask, 'TP_Stage_Change_week'] = STI_t_U_to_U
# =============================================================================

# 2. Screening and symptom driven treatment of STIs : Trans all detectable infections agents to T status

# =============================================================================
    # Find those screen for STIs this week
    Screen_All = agents[agents['Next_screen_week'] == week_cycle]
    Screen_NG = Screen_All[Screen_All['NG_Stage_Now'].isin(['Ia'])]
    Screen_CT = Screen_All[Screen_All['CT_Stage_Now'].isin(['Ia'])]
    Screen_TP_early = Screen_All[Screen_All['TP_Stage_Now'].isin(['I1a', 'EL1', 'I2a', 'EL2'])]
    Screen_TP_late = Screen_All[Screen_All['TP_Stage_Now'].isin(['LL'])]

    # Update the Next screening week for agents screened this_week
    agents.loc[Screen_All.index, 'Next_screen_week'] = week_cycle + np.round(Screen_All['Test_interval_ave'] * (1 + np.random.normal(0, 0.1, len(Screen_All)))).astype(int)

    # Detect the index of screened STIs
    Screen_NG_indices = Screen_NG.index
    Screen_CT_indices = Screen_CT.index
    Screen_TP_early_indices = Screen_TP_early.index
    Screen_TP_late_indices = Screen_TP_late.index

    Treat_symptom_NG = agents[(agents['NG_Stage_Now'] == 'Is') & (agents['NG_Stage_Change_week'] == week_cycle)].index
    Treat_symptom_CT = agents[(agents['CT_Stage_Now'] == 'Is') & (agents['CT_Stage_Change_week'] == week_cycle)].index
    Treat_symptom_early_TP = agents[(agents['TP_Stage_Now'].isin(['I1s', 'I2s'])) & (agents['TP_Stage_Next'] == 'T1') & (agents['TP_Stage_Change_week'] == week_cycle)].index
    Treat_symptom_late_TP = agents[(agents['TP_Stage_Now'] == 'I3') & (agents['TP_Stage_Next'] == 'T2') & (agents['TP_Stage_Change_week'] == week_cycle)].index

# =============================================================================

# 3. Treat infections (including the screening-driven and symptom-driven): Transition them to T status

    # 3.1 NG treatment
    Combine_NG_Treat_indices = Screen_NG_indices.union(Treat_symptom_NG)
    agents.loc[Combine_NG_Treat_indices, 'NG_Stage_Change_week'] = week_cycle + np.round(np.random.uniform(*NG_t_T_to_U, len(Combine_NG_Treat_indices))).astype(int)
    NG_DR_Trans_randoms = np.random.rand(len(Combine_NG_Treat_indices))
    NG_AMR_Cef_values = agents.loc[Combine_NG_Treat_indices, 'NG_AMR_Cef'].values
    AMR_Cef_indices = (NG_AMR_Cef_values & (NG_DR_Trans_randoms < Cef_failure_prob)) | (~NG_AMR_Cef_values & (NG_DR_Trans_randoms < Cef_ADR_rate))
    agents.loc[Combine_NG_Treat_indices, 'NG_Stage_Next'] = np.select([(agents.loc[Combine_NG_Treat_indices, 'NG_Stage_Now'] == 'Ia') & AMR_Cef_indices,
                                                                       (agents.loc[Combine_NG_Treat_indices, 'NG_Stage_Now'] == 'Is') & AMR_Cef_indices],
                                                                      ['Ia','Is'],
                                                                       default='U')
    agents.loc[Combine_NG_Treat_indices, 'NG_Stage_Now'] = 'T'

    # 3.2 CT treatment
    Combine_CT_Treat_indices = Screen_CT_indices.union(Treat_symptom_CT)
    agents.loc[Combine_CT_Treat_indices, ['CT_Stage_Now', 'CT_Stage_Next']] = ['T', 'U']
    agents.loc[Combine_CT_Treat_indices, 'CT_Stage_Change_week'] = week_cycle + np.round(np.random.uniform(*CT_t_T_to_U, len(Combine_CT_Treat_indices))).astype(int)

    # 3.3 TP treatment
    Combine_TP_early_Treat_indices = Screen_TP_early_indices.union(Treat_symptom_early_TP)
    Combine_TP_late_Treat_indices = Screen_TP_late_indices.union(Treat_symptom_late_TP)
    agents.loc[Combine_TP_early_Treat_indices, ['TP_Stage_Now', 'TP_Stage_Next']] = ['T1', 'U']
    agents.loc[Combine_TP_early_Treat_indices, 'TP_Stage_Change_week'] = week_cycle + np.round(np.random.uniform(*TP_t_T1_to_U, len(Combine_TP_early_Treat_indices))).astype(int)
    agents.loc[Combine_TP_late_Treat_indices, ['TP_Stage_Now', 'TP_Stage_Next']] = ['T2', 'U']
    agents.loc[Combine_TP_late_Treat_indices, 'TP_Stage_Change_week'] = week_cycle + np.round(52 * np.random.gamma(*TP_t_T2_to_U, len(Combine_TP_late_Treat_indices))).astype(int)

    mask = (Weekly_screened_diagnosis['week'] == week_cycle)
    Treat_symptom_NG_DF = agents.loc[Treat_symptom_NG]
    symptom_groups = [Treat_symptom_NG, Treat_symptom_CT, Treat_symptom_early_TP, Treat_symptom_late_TP]
    
    updates = {
        'All_screened': len(Screen_All), 'NG_screened': len(Screen_NG), 
        'CT_screened': len(Screen_CT), 'TP_early_screened': len(Screen_TP_early), 
        'TP_late_screened': len(Screen_TP_late), 'NG_symptom_diag': len(Treat_symptom_NG),
        'CT_symptom_diag': len(Treat_symptom_CT), 'TP_early_symptom_diag': len(Treat_symptom_early_TP), 
        'TP_late_symptom_diag': len(Treat_symptom_late_TP),
        'NG_diag_Res_Cef': Screen_NG['NG_AMR_Cef'].sum() + Treat_symptom_NG_DF['NG_AMR_Cef'].sum(),
        'NG_diag_Res_Dox': Screen_NG['NG_AMR_Dox'].sum() + Treat_symptom_NG_DF['NG_AMR_Dox'].sum(),
        'NG_diag_Res_Double': (Screen_NG['NG_AMR_Cef'] & Screen_NG['NG_AMR_Dox']).sum() + 
                              (Treat_symptom_NG_DF['NG_AMR_Cef'] & Treat_symptom_NG_DF['NG_AMR_Dox']).sum(),
        'HIV_pos_STI_tests': Screen_All['HIV'].sum() + sum(agents.loc[group]['HIV'].sum() for group in symptom_groups)
    }
    
    Weekly_screened_diagnosis.loc[mask, list(updates.keys())] = list(updates.values())
    # Update the Doxy-PEP users
    All_STI_diag_indices = list(set().union(
        Screen_NG_indices,
        Screen_CT_indices,
        Screen_TP_early_indices,
        Screen_TP_late_indices,
        Treat_symptom_NG,
        Treat_symptom_CT,
        Treat_symptom_early_TP,
        Treat_symptom_late_TP
    ))

    agents.loc[All_STI_diag_indices, 'Last_STI_diag_time'] = week_cycle

    return agents, Weekly_screened_diagnosis

# %% Fun 14. Update STI stage progress screening treatment new
def Update_STI_Stage_progress_screening_treatment_new(agents, Weekly_screened_diagnosis, Weekly_Doxy_outcomes, week_cycle, scenario_index):
    """
    Aggregate daily data into yearly summaries. This function computes the sum of each column for each year
    within the specified date range.

    Parameters:
    df (DataFrame): DataFrame containing daily data to be summarized.
    start_week (int): Starting week of the data.
    end_week (int): Ending week of the data.
    year_length (int): Number of weeks in a simulated year.

    Returns:
    DataFrame: Yearly summary data as a DataFrame.
    """
# 1.Progress of STIs : Update the stage next and chage week (Exclude those infections with symptoms)
#   1.1 Progress of NG =============================================================================
    # NG: E to Is or Ia
    NG_E_mask = (agents['NG_Stage_Now'] == 'E') & (agents['NG_Stage_Change_week'] == week_cycle)
    agents.loc[NG_E_mask, 'NG_Stage_Now'] = agents.loc[NG_E_mask, 'NG_Stage_Next']
    agents.loc[NG_E_mask, 'NG_Stage_Next'] = np.where(agents.loc[NG_E_mask, 'NG_Stage_Now'] == 'Is', 'T', 'U')
    agents.loc[NG_E_mask, 'NG_Stage_Change_week'] = week_cycle + np.where(agents.loc[NG_E_mask, 'NG_Stage_Now'] == 'Is',
                                                            np.round(np.random.uniform(*Sym_Driven_Treat, size=NG_E_mask.sum())).astype(int),
                                                            np.round(np.random.gamma(*NG_t_Ia_to_U, size=NG_E_mask.sum())).astype(int))
    # NG: Ia to U
    NG_Ia_mask = (agents['NG_Stage_Now'] == 'Ia') & (agents['NG_Stage_Change_week'] == week_cycle)
    agents.loc[NG_Ia_mask, 'NG_Stage_Now'] = agents.loc[NG_Ia_mask, 'NG_Stage_Next']
    agents.loc[NG_Ia_mask, 'NG_Pos'] = False
    agents.loc[NG_Ia_mask, 'NG_Stage_Next'] = 'U'
    agents.loc[NG_Ia_mask, 'NG_Stage_Change_week'] = STI_t_U_to_U

    # NG: T to Ia or U
    NG_T_mask = (agents['NG_Stage_Now'] == 'T') & (agents['NG_Stage_Change_week'] == week_cycle)
    agents.loc[NG_T_mask, 'NG_Stage_Now'] = agents.loc[NG_T_mask, 'NG_Stage_Next']
    agents.loc[NG_T_mask, 'NG_Pos'] = np.where(agents.loc[NG_T_mask, 'NG_Stage_Now'] == 'U', False, True)
    agents.loc[NG_T_mask, 'NG_AMR_Cef'] = ~(agents.loc[NG_T_mask, 'NG_Stage_Now'].isin(['U']))
    agents.loc[NG_T_mask, 'NG_AMR_Dox'] = np.where(agents.loc[NG_T_mask, 'NG_Stage_Now'] == 'U', False, agents.loc[NG_T_mask, 'NG_AMR_Dox'])
    agents.loc[NG_T_mask, 'NG_Stage_Next'] = np.where(agents.loc[NG_T_mask, 'NG_Stage_Now'] == 'Is', 'T', 'U')
    agents.loc[NG_T_mask, 'NG_Stage_Change_week'] = week_cycle + np.select([agents.loc[NG_T_mask, 'NG_Stage_Now'] == 'U',
                                                                          agents.loc[NG_T_mask, 'NG_Stage_Now'] == 'Ia'],
                                                                         [STI_t_U_to_U,
                                                                          np.round(np.random.gamma(*NG_t_Ia_to_U, size=NG_T_mask.sum())).astype(int)],
                                                                         default=np.round(np.random.uniform(*Sym_Driven_Treat, size=NG_T_mask.sum())).astype(int)
                                                                    )
# =============================================================================

#  1.2 Progress of CT =============================================================================
    # CT: E to Is or Ia
    CT_E_mask = (agents['CT_Stage_Now'] == 'E') & (agents['CT_Stage_Change_week'] == week_cycle)
    agents.loc[CT_E_mask, 'CT_Stage_Now'] = agents.loc[CT_E_mask, 'CT_Stage_Next']
    agents.loc[CT_E_mask, 'CT_Stage_Next'] = np.where(agents.loc[CT_E_mask, 'CT_Stage_Now'] == 'Is', 'T', 'U')
    agents.loc[CT_E_mask, 'CT_Stage_Change_week'] = week_cycle + np.where(agents.loc[CT_E_mask, 'CT_Stage_Now'] == 'Is',
                                                            np.round(np.random.uniform(*Sym_Driven_Treat, size=CT_E_mask.sum()).astype(int)),
                                                            np.round(np.random.gamma(*CT_t_Ia_to_U, size=CT_E_mask.sum())).astype(int))

    # CT: Ia to U
    CT_Ia_mask = (agents['CT_Stage_Now'] == 'Ia') & (agents['CT_Stage_Change_week'] == week_cycle)
    agents.loc[CT_Ia_mask, 'CT_Stage_Now'] = agents.loc[CT_Ia_mask, 'CT_Stage_Next']
    agents.loc[CT_Ia_mask, ['CT_Pos', 'CT_Stage_Next','CT_Stage_Change_week' ]] = [False, 'U', STI_t_U_to_U]

    # CT: T to U
    CT_T_mask = (agents['CT_Stage_Now'] == 'T') & (agents['CT_Stage_Change_week'] == week_cycle)
    agents.loc[CT_T_mask, 'CT_Stage_Now'] = agents.loc[CT_T_mask, 'CT_Stage_Next']
    agents.loc[CT_T_mask, ['CT_Pos', 'CT_Stage_Next','CT_Stage_Change_week' ]] = [False, 'U', STI_t_U_to_U]
# =============================================================================

#   1.3 Progress of TP =============================================================================
    # TP: E to I1s or I1a
    TP_E_mask = (agents['TP_Stage_Now'] == 'E') & (agents['TP_Stage_Change_week'] == week_cycle)
    agents.loc[TP_E_mask, 'TP_Stage_Now'] = agents.loc[TP_E_mask, 'TP_Stage_Next']
    agents.loc[TP_E_mask, 'TP_Stage_Next'] = np.where(agents.loc[TP_E_mask, 'TP_Stage_Now'] == 'I1s', 'T1', 'EL1')

    agents.loc[TP_E_mask, 'TP_Stage_Change_week'] = week_cycle + np.where(agents.loc[TP_E_mask, 'TP_Stage_Now'] == 'I1s',
                                                                          np.round(np.random.uniform(*Sym_Driven_Treat, size=TP_E_mask.sum())).astype(int),
                                                                          np.round(np.random.gamma(*TP_t_I1_to_EL1, size=TP_E_mask.sum())).astype(int))

    # TP: I1a to EL1
    TP_I1a_mask = (agents['TP_Stage_Now'] == 'I1a') & (agents['TP_Stage_Change_week'] == week_cycle)
    agents.loc[TP_I1a_mask, 'TP_Stage_Now'] = agents.loc[TP_I1a_mask, 'TP_Stage_Next']
    agents.loc[TP_I1a_mask, 'TP_Stage_Next'] = np.random.choice(['I2s', 'I2a'], size=TP_I1a_mask.sum())
    agents.loc[TP_I1a_mask, 'TP_Stage_Change_week'] = week_cycle + np.round(np.random.gamma(*TP_t_EL1_to_I2, size=TP_I1a_mask.sum())).astype(int)

    # TP: EL1 to I2s or I2a
    TP_EL1_mask = (agents['TP_Stage_Now'] == 'EL1') & (agents['TP_Stage_Change_week'] == week_cycle)
    agents.loc[TP_EL1_mask, 'TP_Stage_Now'] = agents.loc[TP_EL1_mask, 'TP_Stage_Next']
    agents.loc[TP_EL1_mask, 'TP_Stage_Next'] = np.where(agents.loc[TP_EL1_mask, 'TP_Stage_Now'] == 'I2s', 'T1', 'EL2')
    agents.loc[TP_EL1_mask, 'TP_Stage_Change_week'] = week_cycle + np.where(agents.loc[TP_EL1_mask, 'TP_Stage_Now'] == 'I2s',
                                                                            np.round(np.random.uniform(*Sym_Driven_Treat, size=TP_EL1_mask.sum())).astype(int),
                                                                            np.round(np.random.gamma(*TP_t_I2_to_EL2, size=TP_EL1_mask.sum())).astype(int))

    # TP: I2a to EL2
    TP_I2a_mask = (agents['TP_Stage_Now'] == 'I2a') & (agents['TP_Stage_Change_week'] == week_cycle)
    agents.loc[TP_I2a_mask, 'TP_Stage_Now'] = agents.loc[TP_I2a_mask, 'TP_Stage_Next']
    agents.loc[TP_I2a_mask, 'TP_Stage_Next'] = 'LL'
    agents.loc[TP_I2a_mask, 'TP_Stage_Change_week'] = week_cycle + np.round(np.random.gamma(*TP_t_EL2_to_LL, size=TP_I2a_mask.sum())).astype(int)

    # TP: EL2 to LL
    TP_EL2_mask = (agents['TP_Stage_Now'] == 'EL2') & (agents['TP_Stage_Change_week'] == week_cycle)
    agents.loc[TP_EL2_mask, 'TP_Stage_Now'] = agents.loc[TP_EL2_mask, 'TP_Stage_Next']
    agents.loc[TP_EL2_mask, 'TP_Stage_Next'] = 'I3'
    agents.loc[TP_EL2_mask, 'TP_Stage_Change_week'] = week_cycle + np.round(52 * np.random.gamma(*TP_t_LL_to_I3, size=TP_EL2_mask.sum())).astype(int)

    # TP: LL to I3
    TP_LL_mask = (agents['TP_Stage_Now'] == 'LL') & (agents['TP_Stage_Change_week'] == week_cycle)
    agents.loc[TP_LL_mask, 'TP_Stage_Now'] = agents.loc[TP_LL_mask, 'TP_Stage_Next']
    agents.loc[TP_LL_mask, 'TP_Stage_Next'] = 'T2'
    agents.loc[TP_LL_mask, 'TP_Stage_Change_week'] = week_cycle + np.round(np.random.uniform(*Sym_Driven_Treat, size=TP_LL_mask.sum())).astype(int)

    # TP: T1 to U
    TP_T1_mask = (agents['TP_Stage_Now'] == 'T1') & (agents['TP_Stage_Change_week'] == week_cycle)
    agents.loc[TP_T1_mask, 'TP_Stage_Now'] = agents.loc[TP_T1_mask, 'TP_Stage_Next']
    agents.loc[TP_T1_mask, 'TP_Pos'] = False
    agents.loc[TP_T1_mask, 'TP_Stage_Next'] = 'U'
    agents.loc[TP_T1_mask, 'TP_Stage_Change_week'] = STI_t_U_to_U

    # TP: T2 to U
    TP_T2_mask = (agents['TP_Stage_Now'] == 'T2') & (agents['TP_Stage_Change_week'] == week_cycle)
    agents.loc[TP_T2_mask, 'TP_Stage_Now'] = agents.loc[TP_T2_mask, 'TP_Stage_Next']
    agents.loc[TP_T2_mask, 'TP_Pos'] = False
    agents.loc[TP_T2_mask, 'TP_Stage_Next'] = 'U'
    agents.loc[TP_T2_mask, 'TP_Stage_Change_week'] = STI_t_U_to_U
# =============================================================================

# 2. Screening and symptom driven treatment of STIs : Trans all detectable infections agents to T status

# =============================================================================
    # Find those screen for STIs this week
    Screen_All = agents[agents['Next_screen_week'] == week_cycle]
    Screen_NG = Screen_All[Screen_All['NG_Stage_Now'].isin(['Ia'])]
    Screen_CT = Screen_All[Screen_All['CT_Stage_Now'].isin(['Ia'])]
    Screen_TP_early = Screen_All[Screen_All['TP_Stage_Now'].isin(['I1a', 'EL1', 'I2a', 'EL2'])]
    Screen_TP_late = Screen_All[Screen_All['TP_Stage_Now'].isin(['LL'])]

    # Update the Next screening week for agents screened this_week
    agents.loc[Screen_All.index, 'Next_screen_week'] = week_cycle + np.round(Screen_All['Test_interval_ave'] * (1 + np.random.normal(0, 0.1, len(Screen_All)))).astype(int)

    # Detect the index of screened STIs
    Screen_All_indices = Screen_All.index
    Screen_NG_indices = Screen_NG.index
    Screen_CT_indices = Screen_CT.index
    Screen_TP_early_indices = Screen_TP_early.index
    Screen_TP_late_indices = Screen_TP_late.index

    Treat_symptom_NG = agents[(agents['NG_Stage_Now'] == 'Is') & (agents['NG_Stage_Change_week'] == week_cycle)].index
    Treat_symptom_CT = agents[(agents['CT_Stage_Now'] == 'Is') & (agents['CT_Stage_Change_week'] == week_cycle)].index
    Treat_symptom_early_TP = agents[(agents['TP_Stage_Now'].isin(['I1s', 'I2s'])) & (agents['TP_Stage_Next'] == 'T1') & (agents['TP_Stage_Change_week'] == week_cycle)].index
    Treat_symptom_late_TP = agents[(agents['TP_Stage_Now'] == 'I3') & (agents['TP_Stage_Next'] == 'T2') & (agents['TP_Stage_Change_week'] == week_cycle)].index

# =============================================================================

# 3. Treat infections (including the screening-driven and symptom-driven): Transition them to T status

    # 3.1 NG treatment
    Combine_NG_Treat_indices = Screen_NG_indices.union(Treat_symptom_NG)
    agents.loc[Combine_NG_Treat_indices, 'NG_Stage_Change_week'] = week_cycle + np.round(np.random.uniform(*NG_t_T_to_U, len(Combine_NG_Treat_indices))).astype(int)
    NG_DR_Trans_randoms = np.random.rand(len(Combine_NG_Treat_indices))
    NG_AMR_Cef_values = agents.loc[Combine_NG_Treat_indices, 'NG_AMR_Cef'].values
    AMR_Cef_indices = (NG_AMR_Cef_values & (NG_DR_Trans_randoms < Cef_failure_prob)) | (~NG_AMR_Cef_values & (NG_DR_Trans_randoms < Cef_ADR_rate))
    agents.loc[Combine_NG_Treat_indices, 'NG_Stage_Next'] = np.select([(agents.loc[Combine_NG_Treat_indices, 'NG_Stage_Now'] == 'Ia') & AMR_Cef_indices,
                                                                       (agents.loc[Combine_NG_Treat_indices, 'NG_Stage_Now'] == 'Is') & AMR_Cef_indices],
                                                                      ['Ia','Is'],
                                                                       default='U')
    agents.loc[Combine_NG_Treat_indices, 'NG_Stage_Now'] = 'T'

    # 3.2 CT treatment
    Combine_CT_Treat_indices = Screen_CT_indices.union(Treat_symptom_CT)
    agents.loc[Combine_CT_Treat_indices, ['CT_Stage_Now', 'CT_Stage_Next']] = ['T', 'U']
    agents.loc[Combine_CT_Treat_indices, 'CT_Stage_Change_week'] = week_cycle + np.round(np.random.uniform(*CT_t_T_to_U, len(Combine_CT_Treat_indices))).astype(int)

    # 3.3 TP treatment
    Combine_TP_early_Treat_indices = Screen_TP_early_indices.union(Treat_symptom_early_TP)
    Combine_TP_late_Treat_indices = Screen_TP_late_indices.union(Treat_symptom_late_TP)
    agents.loc[Combine_TP_early_Treat_indices, ['TP_Stage_Now', 'TP_Stage_Next']] = ['T1', 'U']
    agents.loc[Combine_TP_early_Treat_indices, 'TP_Stage_Change_week'] = week_cycle + np.round(np.random.uniform(*TP_t_T1_to_U, len(Combine_TP_early_Treat_indices))).astype(int)
    agents.loc[Combine_TP_late_Treat_indices, ['TP_Stage_Now', 'TP_Stage_Next']] = ['T2', 'U']
    agents.loc[Combine_TP_late_Treat_indices, 'TP_Stage_Change_week'] = week_cycle + np.round(52 * np.random.gamma(*TP_t_T2_to_U, len(Combine_TP_late_Treat_indices))).astype(int)

    mask = (Weekly_screened_diagnosis['week'] == week_cycle)
    Treat_symptom_NG_DF = agents.loc[Treat_symptom_NG]
    symptom_groups = [Treat_symptom_NG, Treat_symptom_CT, Treat_symptom_early_TP, Treat_symptom_late_TP]
    
    updates = {
        'All_screened': len(Screen_All), 'NG_screened': len(Screen_NG), 
        'CT_screened': len(Screen_CT), 'TP_early_screened': len(Screen_TP_early), 
        'TP_late_screened': len(Screen_TP_late), 'NG_symptom_diag': len(Treat_symptom_NG),
        'CT_symptom_diag': len(Treat_symptom_CT), 'TP_early_symptom_diag': len(Treat_symptom_early_TP), 
        'TP_late_symptom_diag': len(Treat_symptom_late_TP),
        'NG_diag_Res_Cef': Screen_NG['NG_AMR_Cef'].sum() + Treat_symptom_NG_DF['NG_AMR_Cef'].sum(),
        'NG_diag_Res_Dox': Screen_NG['NG_AMR_Dox'].sum() + Treat_symptom_NG_DF['NG_AMR_Dox'].sum(),
        'NG_diag_Res_Double': (Screen_NG['NG_AMR_Cef'] & Screen_NG['NG_AMR_Dox']).sum() + 
                              (Treat_symptom_NG_DF['NG_AMR_Cef'] & Treat_symptom_NG_DF['NG_AMR_Dox']).sum(),
        'HIV_pos_STI_tests': Screen_All['HIV'].sum() + sum(agents.loc[group]['HIV'].sum() for group in symptom_groups)
    }
    
    Weekly_screened_diagnosis.loc[mask, list(updates.keys())] = list(updates.values())
    
    # Update the Doxy-PEP users
    All_Attendance_indices = list(set().union(
        Screen_All_indices,
        Treat_symptom_NG,
        Treat_symptom_CT,
        Treat_symptom_early_TP,
        Treat_symptom_late_TP
    ))

    All_STI_diag_indices = list(set().union(
        Screen_NG_indices,
        Screen_CT_indices,
        Screen_TP_early_indices,
        Screen_TP_late_indices,
        Treat_symptom_NG,
        Treat_symptom_CT,
        Treat_symptom_early_TP,
        Treat_symptom_late_TP
    ))

    All_TP_diag_indices = list(set().union(
        Screen_TP_early_indices,
        Screen_TP_late_indices,
        Treat_symptom_early_TP,
        Treat_symptom_late_TP
    ))

    scenario = Doxy_PEP_Scenarios.loc[scenario_index]

    Condition_map = {
        'HIV_PrEP': ((agents.index.isin(All_Attendance_indices)) &
                     (agents['HIV'].isin(scenario['HIV']) & agents['PrEP'].isin(scenario['PrEP'])) &
                     (~agents['Doxy-PEP'])),

        'TP_diag': ((agents.index.isin(All_TP_diag_indices)) &
                    (~agents['Doxy-PEP'])),

        'STI_diag': ((agents.index.isin(All_STI_diag_indices)) &
                     (agents['Last_STI_diag_time'] >= (week_cycle - scenario['Interval'])) &
                     (~agents['Doxy-PEP']))
    }

    eligible_agents = agents.loc[Condition_map.get(scenario['strategy_type'])]
    new_doxy_users_indices = eligible_agents.sample(frac=Doxy_PEP_Uptake, random_state=123).index
    
    if len(new_doxy_users_indices) > 0:
        age_groups = [(15,19), (20,24), (25,29), (30,34), (35,39), (40,44), (45,49), (50,54), (55,59), (60,64)]
        new_users = agents.loc[new_doxy_users_indices]

        mask = Weekly_Doxy_outcomes['week'] == week_cycle
        Weekly_Doxy_outcomes.loc[mask, 'Doxy_PEP_enter'] = len(new_doxy_users_indices)
        Weekly_Doxy_outcomes.loc[mask, 'Doxy_PEP_HIV_pos'] = new_users['HIV'].sum()
        Weekly_Doxy_outcomes.loc[mask, 'Doxy_PEP_PrEP_users'] = new_users['PrEP'].sum()

        for min_age, max_age in age_groups:
            age_mask = (new_users['age_year'] >= min_age) & (new_users['age_year'] <= max_age)
            Weekly_Doxy_outcomes.loc[mask, f'Doxy_PEP_age_{min_age}_{max_age}'] = age_mask.sum()
    else:
        Weekly_Doxy_outcomes.loc[Weekly_Doxy_outcomes['week'] == week_cycle, 'Doxy_PEP_enter'] = 0

    agents.loc[new_doxy_users_indices, ['Doxy-PEP', 'Doxy-PEP_Use']] = [True, 0]
    Weekly_Doxy_outcomes.loc[Weekly_Doxy_outcomes['week'] == week_cycle, 'Doxy_PEP_enter'] = len(new_doxy_users_indices)

    agents.loc[All_STI_diag_indices, 'Last_STI_diag_time'] = week_cycle

    return agents, Weekly_screened_diagnosis, Weekly_Doxy_outcomes
# %% Fun 15. Summarize yearly data
def summarize_yearly(df, start_week, end_week, start_year=2012, year_length=52):
    """
    Aggregate daily data into yearly summaries. This function computes the sum of each column for each year
    within the specified date range.

    Parameters:
    df (DataFrame): DataFrame containing daily data to be summarized.
    start_week (int): Starting week of the data.
    end_week (int): Ending week of the data.
    start_year (int): The starting year of the summary.
    year_length (int): Number of weeks in a simulated year.

    Returns:
    DataFrame: Yearly summary data as a DataFrame with columns named by years starting from start_year.
    """
    # Initialize a dictionary to store yearly summaries
    yearly_summary = {}

    # Loop through each year and calculate the sum for each column
    for year_start in range(start_week + 1, end_week, year_length):
        year_end = year_start + year_length - 1
        year_data = df[(df['week'] >= year_start) & (df['week'] <= year_end)]
        summary = year_data.sum()
        summary.drop('week', inplace=True)  # Remove the 'week' column from the sum
        year_index = int((year_start - start_week) / year_length) + start_year
        yearly_summary[f'{year_index}'] = summary

    # Convert the dictionary to a DataFrame
    yearly_summary_df = pd.DataFrame(yearly_summary)
    return yearly_summary_df

# %% Fun 16. Plot model vs real data
def safe_divide(numerator, denominator):
    return np.where(denominator != 0, numerator / denominator, 0)

# %% Fun 17. Run simulation first part
def run_simulation_first_part(simu, params, N_agents, N_weeks_1, N_weeks_2, N_weeks_3, N_weeks_4, week_ini):
    """
    Run the first part of the simulation model.
    
    Parameters:
    -----------
    simu : int
        Simulation index
    params : dict
        Dictionary containing all simulation parameters
    N_agents : int
        Total number of agents in the simulation
    N_weeks_1 : int
        Number of weeks for the first period (2012-2015)
    N_weeks_2 : int
        Number of weeks for the second period (2015-2018)
    N_weeks_3 : int
        Number of weeks for the third period (2018-2021)
    N_weeks_4 : int
        Number of weeks for the fourth period (2021-2023)
    week_ini : int
        Initial week number
        
    Returns:
    --------
    tuple
        A tuple containing:
        - agents: DataFrame with agent information
        - All_regular_partnerships: DataFrame with regular partnership information
        - All_casual_partnerships: DataFrame with casual partnership information
        - Now_regular_partnerships: DataFrame with current regular partnerships
        - Now_casual_partnerships: DataFrame with current casual partnerships
        - Weekly_sex_pairs: DataFrame with weekly sexual activity information
        - Weekly_new_infections: DataFrame with weekly new infection information
        - Weekly_screened_diagnosis: DataFrame with weekly screening and diagnosis information
        - Yearly_screened_diagnosis: DataFrame with yearly screening and diagnosis information
        - Popu_struc_data: DataFrame with population structure information
        - Ra: DataFrame with regular partnership parameters
        - Ca: DataFrame with casual partnership parameters
    """
    np.random.seed(123)

    global STI_trans_probs, NG_Ini_Pos_Rate, NG_Ini_Cef_Res_Rate, NG_Ini_Dox_Res_Rate, CT_Ini_Pos_Rate, TP_Ini_Pos_Rate,\
        Cef_failure_prob, Cef_ADR_rate, Tetra_Bg_increase, Doxy_PEP_Uptake, Doxy_PEP_Adherence, Doxy_PEP_Efficacy,\
        NG_Ini_Pos_Rate_HIV_new, NG_Ini_Pos_Rate_PrEP_new, CT_Ini_Pos_Rate_HIV_new, CT_Ini_Pos_Rate_PrEP_new,\
        TP_Ini_Pos_Rate_HIV_new, TP_Ini_Pos_Rate_PrEP_new, sometime_condom_prob, Always_condom_ratio, NG_Sym_Proportion

    STI_trans_probs = params['STI_trans_probs']
    NG_Ini_Pos_Rate = params['NG_Ini_Pos_Rate']
    NG_Ini_Cef_Res_Rate = params['NG_Ini_Cef_Res_Rate']
    NG_Ini_Dox_Res_Rate = params['NG_Ini_Dox_Res_Rate']
    CT_Ini_Pos_Rate = params['CT_Ini_Pos_Rate']
    TP_Ini_Pos_Rate = params['TP_Ini_Pos_Rate']
    Cef_failure_prob = params['Cef_failure_prob']
    Cef_ADR_rate = params['Cef_ADR_rate']
    Tetra_Bg_increase = params['Tetra_Bg_increase_1st']
    NG_Ini_Pos_Rate_HIV_new = params['NG_Ini_Pos_Rate_HIV']
    NG_Ini_Pos_Rate_PrEP_new = params['NG_Ini_Pos_Rate_PrEP']
    CT_Ini_Pos_Rate_HIV_new = params['CT_Ini_Pos_Rate_HIV']
    CT_Ini_Pos_Rate_PrEP_new = params['CT_Ini_Pos_Rate_PrEP']
    TP_Ini_Pos_Rate_HIV_new = params['TP_Ini_Pos_Rate_HIV']
    TP_Ini_Pos_Rate_PrEP_new = params['TP_Ini_Pos_Rate_PrEP']
    sometime_condom_prob = 0.5
    Always_condom_ratio = 1
    NG_Sym_Proportion = 0.3

    Doxy_PEP_Uptake = 0
    Doxy_PEP_Adherence = 0
    Doxy_PEP_Efficacy = {'NG': 0.45, 'CT': 0.81, 'TP': 0.77}

    # %% 1. Initialize the agents
    agents = pd.DataFrame({
        'ID': range(1, N_agents + 1),
        # Proportion of the for kinds of partnership preference, derived from the AGSP reports, a docx file for more details.
        'group': np.random.choice(["only_regular", "only_casual", "both"], N_agents, replace=True,
                                  p= [0.226, 0.448, 0.326] ),
        'ANCP': [0.0000001] * N_agents,  # Annual number of casual partnership
        'Dura_prefer_cas': [0] * N_agents,  # Preferred duration of casual partnership
        'Reg_now': [False] * N_agents,
        'Cas_now': [False] * N_agents,
        'ANCP_real': [0] * N_agents,  # Initialize ANCP_real
        'Lweek_52': [0] * N_agents,  # Initialize Lweek_52
        'P_Ci': [0.0] * N_agents,  # Initialize P_Ci
        'Prefer_Sex_Fre_Reg': [0] * N_agents,
        'Prefer_Sex_Fre_Cas': [0] * N_agents
    })
    agents.set_index('ID', inplace=True)

    # Assig the Ra_now and Ca_now according to their groups
    agents['Reg_now'] = agents['group'].isin(['only_regular', 'both'])
    agents['Cas_now'] = agents['group'].isin(['only_casual', 'both'])

    # Assign the Age
    agents['age_year'] = assign_gamma_ages(N_agents)

    # Assign the HIV status
    agents['HIV'] = np.random.choice([True, False], size=N_agents, p=[(HIV_pos_prob := 0.095), 1-HIV_pos_prob])

    # Assign PrEP use only for HIV (-) individuals
    agents['Doxy-PEP'] = False  # Initialize all as False
    agents['PrEP'] = False  # Initialize all as False
    agents.loc[agents['HIV'] == False, 'PrEP'] = np.random.choice([True, False], size=(agents['HIV'] == False).sum(), p=[(PrEP_prob := 0.00164), 1-PrEP_prob])

    # Assign SCC requirement
    agents['SCC_require'] = False  # Initialize all as False
    # For HIV positive: 41.5% require SCC
    agents.loc[agents['HIV'] == True, 'SCC_require'] = np.random.choice([True, False], 
        size=(agents['HIV'] == True).sum(), p=[0.415, 0.585])
    # For HIV negative PrEP users: 79.7% require SCC
    agents.loc[(agents['HIV'] == False) & (agents['PrEP'] == True), 'SCC_require'] = np.random.choice([True, False], 
        size=((agents['HIV'] == False) & (agents['PrEP'] == True)).sum(), p=[0.797, 0.203])
    # For HIV negative non-PrEP users: 89.9% require SCC
    agents.loc[(agents['HIV'] == False) & (agents['PrEP'] == False), 'SCC_require'] = np.random.choice([True, False], 
        size=((agents['HIV'] == False) & (agents['PrEP'] == False)).sum(), p=[0.899, 0.101])

    # Assigning ANCP for each agent
    # (1) For "only_regular", we assign the 0.00000001
    agents.loc[agents['group'].isin(['only_regular']), 'ANCP'] = 0.0000001

    # (2) For "only_casual" and "both", we sample from the gamma distribution
    Cas_available = agents['group'].isin(['only_casual', 'both'])
    # Subgroup sampling from gamma distributions according to the HIV and PrEP statuss
    agents.loc[agents['HIV'] & Cas_available, 'ANCP'] = np.random.gamma(shape=0.7, scale=35, size=(agents['HIV'] & Cas_available).sum())
    agents.loc[(~agents['HIV']) & agents['PrEP'] & Cas_available, 'ANCP'] = np.random.gamma(shape=1.1, scale=25, size=(~agents['HIV'] & agents['PrEP'] & Cas_available).sum())
    agents.loc[(~agents['HIV']) & (~agents['PrEP']) & Cas_available, 'ANCP'] = np.random.gamma(shape=0.4, scale=20, size=(~agents['HIV'] & (~agents['PrEP']) & Cas_available).sum())

    # Assign the preferred duration of casual partnership according to the ANCP
    agents.loc[agents['group'] != 'only_regular', 'Dura_prefer_cas'] = np.clip(np.ceil(-np.log(np.random.uniform(0, 1, size=len(agents))) * 52 / agents['ANCP']), 1, 2).astype(int)

    # Assign the preferred sexual act frequency
    agents['Prefer_Sex_Fre_Reg'] = np.round(-1.145 * agents['age_year'] + 134.09)
    agents['Prefer_Sex_Fre_Cas'] = np.round(-0.4035 * agents['age_year'] + 58.242)

    # Assign the condom use preference with regular and casual partnerships
    # Assignment of "Condom_Reg"
    agents['Condom_Reg'] = False
    agents.loc[agents['HIV'], 'Condom_Reg'] = np.random.choice([True, False], size=agents[agents['HIV']].shape[0], p=[0.091, 0.909])
    agents.loc[~agents['HIV'] & agents['PrEP'], 'Condom_Reg'] = np.random.choice([True, False], size=agents[~agents['HIV'] & agents['PrEP']].shape[0], p=[0.061, 0.939])
    agents.loc[~agents['HIV'] & ~agents['PrEP'], 'Condom_Reg'] = np.random.choice([True, False], size=agents[~agents['HIV'] & ~agents['PrEP']].shape[0], p=[0.261, 0.739])

    # Assignment of "Condom_Cas"
    agents['Condom_Cas'] = False
    agents.loc[agents['HIV'], 'Condom_Cas'] = np.random.choice([True, False], size=agents[agents['HIV']].shape[0], p=[0.288, 0.712])
    agents.loc[~agents['HIV'] & agents['PrEP'], 'Condom_Cas'] = np.random.choice([True, False], size=agents[~agents['HIV'] & agents['PrEP']].shape[0], p=[0.265, 0.735])
    agents.loc[~agents['HIV'] & ~agents['PrEP'], 'Condom_Cas'] = np.random.choice([True, False], size=agents[~agents['HIV'] & ~agents['PrEP']].shape[0], p=[0.421, 0.579])

    # %%  2. Create the vector or data.table for saving

    # Initialize the lists of available partners
    Ra = agents.index[agents['Reg_now']]
    Ca = agents.index[agents['Cas_now']]

     # Initialize data frames to store partnerships
    All_regular_partnerships = All_casual_partnerships = pd.DataFrame({
        'partner1': pd.Series(dtype='int'),
        'partner2': pd.Series(dtype='int'),
        'ini_week': pd.Series(dtype='int'),
        'end_week': pd.Series(dtype='int')
    })

    Now_casual_partnerships = Now_regular_partnerships = pd.DataFrame({
        'partner1': pd.Series(dtype='int'),
        'partner2': pd.Series(dtype='int'),
        'ini_week': pd.Series(dtype='int'),
        'end_week': pd.Series(dtype='int'),
        'total_duration': pd.Series(dtype='int'),
        'due_sexual_frequency': pd.Series(dtype='int'),
        'due_sexual_acts': pd.Series(dtype='int'),
        'past_sexual_acts': pd.Series(dtype='int'),
        'daily_prob_sex': pd.Series(dtype='float'),
        'weekly_sex_epi': pd.Series(dtype='int'),
        'condom_use_prob': pd.Series(dtype='float'),
        'weekly_condomless_sex_epi': pd.Series(dtype='int'),
    })

    # %% 3. Generate regular partnerships at week=0
    while len(Ra) > 1:
        pairs_Reg = (pd.DataFrame(np.reshape(np.random.choice(Ra, size=(len(Ra) // 2) * 2, replace=False), (-1, 2)),
                                  columns=['partner1', 'partner2'])
            .merge(agents[['SCC_require', 'HIV']], left_on='partner1', right_index=True)
            .merge(agents[['SCC_require', 'HIV']], left_on='partner2', right_index=True, suffixes=('_1', '_2'))
            # Filter pairs based on the criteria
            .query("((SCC_require_1 | SCC_require_2) & (HIV_1 == HIV_2)) | (~SCC_require_1 & ~SCC_require_2)")
        )
        # Only proceed if there are valid pairs
        if len(pairs_Reg) > 0:
            agents, Ra, All_regular_partnerships, Now_regular_partnerships = Format_regular_partnership(
                agents, Ra, pairs_Reg, All_regular_partnerships, Now_regular_partnerships, week_ini
            )
        else:
            break

    if len(Ca) > 1:
        # Selected all the pairs
        pairs_Cas = pd.DataFrame(np.reshape(np.random.choice(Ca, size=(len(Ca) // 2) * 2, replace=False), (-1, 2)),
                                 columns=['partner1', 'partner2'])
        # Call the format_casual_partnership function
        agents, Ca, All_casual_partnerships, Now_casual_partnerships = Format_casual_partnership(
            agents, Ca, pairs_Cas, All_casual_partnerships, Now_casual_partnerships, week_ini
        )

    # Generate the sexual character of each agent
    agents = Update_sex_info(agents, All_casual_partnerships, week_ini)

    # %%  4. Simulation until N_weeks_1 to stabilize the partnership network
    for week_cycle in range(1, N_weeks_1 + 1):
        # Simulate daily sex acts and update partnership network without age progression
        # This phase is for network stabilization only

    # ### (1) Simulate the daily sex act
        Now_regular_partnerships = Calculate_sex_act_prob(Now_regular_partnerships, week_cycle)
        Now_casual_partnerships = Calculate_sex_act_prob(Now_casual_partnerships, week_cycle)

    # ### (2) Update the partnership network
        # (A) Detect the partnership ends this_week
        Ending_regular_partnerships = Now_regular_partnerships[Now_regular_partnerships['end_week'] == week_cycle]
        Ending_casual_partnerships = Now_casual_partnerships[Now_casual_partnerships['end_week'] == week_cycle]

        # Update the existed partnerships
        # Remove end partnership
        Now_regular_partnerships = Now_regular_partnerships[Now_regular_partnerships['end_week'] > week_cycle]
        Now_casual_partnerships = Now_casual_partnerships[Now_casual_partnerships['end_week'] > week_cycle]

        ending_reg_ids = pd.Index(Ending_regular_partnerships[['partner1', 'partner2']].values.ravel())
        ending_cas_ids = pd.Index(Ending_casual_partnerships[['partner1', 'partner2']].values.ravel())

        agents.loc[ending_reg_ids, 'Reg_now'] = False
        agents.loc[ending_cas_ids, 'Cas_now'] = False

        Ra = Ra.union(ending_reg_ids)
        Ca = Ca.union(ending_cas_ids)

        # (B) Reunite the regular partnerships
        if len(Ra) > 1:
            pairs_Reg = (pd.DataFrame(np.reshape(np.random.choice(Ra, size=(len(Ra) // 2) * 2, replace=False), (-1, 2)),
                                      columns=['partner1', 'partner2'])
                .merge(agents[['SCC_require', 'HIV']], left_on='partner1', right_index=True)
                .merge(agents[['SCC_require', 'HIV']], left_on='partner2', right_index=True, suffixes=('_1', '_2'))
                # Filter pairs based on the criteria
                .query("((SCC_require_1 | SCC_require_2) & (HIV_1 == HIV_2)) | (~SCC_require_1 & ~SCC_require_2)")
                [['partner1', 'partner2']]
            )
            # Only proceed if there are valid pairs
            if len(pairs_Reg) > 0:
                agents, Ra, All_regular_partnerships, Now_regular_partnerships = Format_regular_partnership(
                    agents, Ra, pairs_Reg, All_regular_partnerships, Now_regular_partnerships, week_cycle
                )

        # (C) Reunite the casual partnerships
        if len(Ca) > 1:
            temp = agents.loc[Ca][['P_Ci']]
            temp['P_Cd'] = np.random.binomial(1, np.minimum(temp['P_Ci'], 1))

            Ca_d = set(temp[temp['P_Cd'] == 1].index)
            # if len(Ca_d) > 1:
            pairs_Cas = pd.DataFrame(np.reshape(np.random.choice(list(Ca_d), size=(len(Ca_d) // 2) * 2, replace=False), (-1, 2)), columns=['partner1', 'partner2'])
            # Call the format_casual_partnership function
            agents, Ca, All_casual_partnerships, Now_casual_partnerships = Format_casual_partnership(
                agents, Ca, pairs_Cas, All_casual_partnerships, Now_casual_partnerships, week_cycle
            )

        # Update sexual information without age progression
        agents = Update_sex_info(agents, All_casual_partnerships, week_cycle)
    # =============================================================================

    # Initialize the STI infection status
    agents = Initialize_infection_status(agents, week_cycle)
    # Assign the preferred STI test interval, initialize the next screen week
    agents = Assign_average_test_interval(agents)
    agents['Next_screen_week'] = week_cycle + np.round(agents['Test_interval_ave'] * (1 + np.random.normal(0, 1, size=len(agents)) / 10)).astype(int)

    Weekly_new_infections = pd.DataFrame({
        'week': range(N_weeks_1 + 1, N_weeks_4 + 1),
        'NG_new_infections': 0,
        'NG_new_Cef_infections': 0,
        'NG_new_Dox_infections': 0,
        'NG_new_Double_infections': 0,
        'NG_new_AMS_infections': 0,
        'CT_new_infections': 0,
        'TP_new_infections': 0,
        'NG_new_infections_HIV_True': 0,
        'NG_new_infections_PrEP_True': 0,
        'NG_new_infections_PrEP_False': 0,
        'CT_new_infections_HIV_True': 0,
        'CT_new_infections_PrEP_True': 0,
        'CT_new_infections_PrEP_False': 0,
        'TP_new_infections_HIV_True': 0,
        'TP_new_infections_PrEP_True': 0,
        'TP_new_infections_PrEP_False': 0,
        'All_new_infections': 0   
    })

    Weekly_screened_diagnosis = pd.DataFrame({
        'week': range(N_weeks_1 + 1, N_weeks_4 + 1),
        'All_screened': 0,
        'NG_screened': 0,
        'CT_screened': 0,
        'TP_early_screened': 0,
        'TP_late_screened': 0,
        'NG_symptom_diag': 0,
        'CT_symptom_diag': 0,
        'TP_early_symptom_diag': 0,
        'TP_late_symptom_diag': 0,
        'HIV_pos_STI_tests': 0,
        'NG_diag_Res_Cef': 0,
        'NG_diag_Res_Dox': 0,
        'NG_diag_Res_Double': 0
    })

    agents['Last_STI_diag_time'] = 0
    agents = agents.assign(**{
        'Doxy-PEP': False,
        'Doxy-PEP_Use': 0,
        'Quit_doxy_week': 0
    })

    # %%  5. Simulation until N_weeks_2 (without Doxy PEP):
    """
    (1) STI transmision according to sex act, condom use, transmission probability;
    (2) STI recovery, test/screening, treatment;
    ### Key point: Output the outbreak information here
    (3) Reformat the partnership network
    """
    for week_cycle in range(N_weeks_1 + 1, N_weeks_2 + 1):

    # (1) STI transmision according to sex act, condom use, transmission probability

        # Apply the sex prob function to the partnerships DataFrames
        Now_regular_partnerships = Calculate_sex_act_prob(Now_regular_partnerships, week_cycle)
        Now_casual_partnerships = Calculate_sex_act_prob(Now_casual_partnerships, week_cycle)

        # Transmit the infection according to the sex act this week
        Weekly_sex_pairs = pd.concat([
            Now_regular_partnerships[Now_regular_partnerships['weekly_sex_epi'] > 0],
            Now_casual_partnerships[Now_casual_partnerships['weekly_sex_epi'] > 0]
        ])

        Transmission_pairs = Filter_transmission_pairs(agents,Weekly_sex_pairs)
        agents, Weekly_new_infections = STI_transmission(agents, Transmission_pairs, Weekly_new_infections, week_cycle)

        # Update the doxy ADR (only the background ADR before doxy-PEP)
        agents.loc[(agents['NG_Pos'] == True) & (agents['NG_AMR_Dox'] == False), 'NG_AMR_Dox'] = np.random.binomial(
            1,
            Tetra_Bg_increase,
            size=len(agents[(agents['NG_Pos'] == True) & (agents['NG_AMR_Dox'] == False)])
        ).astype(bool)

    # (2) STI progress, test/screening, treatment, with the prevalence calculation
        agents, Weekly_screened_diagnosis = Update_STI_Stage_progress_screening_treatment(agents, Weekly_screened_diagnosis, week_cycle)

    # (3) Reformat aging agents;
        # (A) Detect the partnership ends this week
        Ending_regular_partnerships = Now_regular_partnerships[Now_regular_partnerships['end_week'] == week_cycle]
        Ending_casual_partnerships = Now_casual_partnerships[Now_casual_partnerships['end_week'] == week_cycle]

        # Update the existed partnerships
        # Remove end partnership
        Now_regular_partnerships = Now_regular_partnerships[Now_regular_partnerships['end_week'] > week_cycle]
        Now_casual_partnerships = Now_casual_partnerships[Now_casual_partnerships['end_week'] > week_cycle]

        # Return partners back to Ra, Ca
        ending_reg_ids = pd.Index(Ending_regular_partnerships[['partner1', 'partner2']].values.ravel())
        ending_cas_ids = pd.Index(Ending_casual_partnerships[['partner1', 'partner2']].values.ravel())

        agents.loc[ending_reg_ids, 'Reg_now'] = False
        agents.loc[ending_cas_ids, 'Cas_now'] = False

        Ra = Ra.union(ending_reg_ids)
        Ca = Ca.union(ending_cas_ids)

        # (B) Reunite the regular partnerships
        if len(Ra) > 1:
            pairs_Reg = (pd.DataFrame(np.reshape(np.random.choice(Ra, size=(len(Ra) // 2) * 2, replace=False), (-1, 2)),
                                      columns=['partner1', 'partner2'])
                .merge(agents[['SCC_require', 'HIV']], left_on='partner1', right_index=True)
                .merge(agents[['SCC_require', 'HIV']], left_on='partner2', right_index=True, suffixes=('_1', '_2'))
                # Filter pairs based on the criteria
                .query("((SCC_require_1 | SCC_require_2) & (HIV_1 == HIV_2)) | (~SCC_require_1 & ~SCC_require_2)")
                [['partner1', 'partner2']]
            )
            # Only proceed if there are valid pairs
            if len(pairs_Reg) > 0:
                agents, Ra, All_regular_partnerships, Now_regular_partnerships = Format_regular_partnership(
                    agents, Ra, pairs_Reg, All_regular_partnerships, Now_regular_partnerships, week_cycle
                )

        # (C) Reunite the casual partnerships
        if len(Ca) > 1:
            temp = agents.loc[Ca][['P_Ci']]
            temp['P_Cd'] = np.random.binomial(1, np.minimum(temp['P_Ci'], 1))

            Ca_d = set(temp[temp['P_Cd'] == 1].index)
            # if len(Ca_d) > 1:
            pairs_Cas = pd.DataFrame(np.reshape(np.random.choice(list(Ca_d), size=(len(Ca_d) // 2) * 2, replace=False), (-1, 2)), columns=['partner1', 'partner2'])
            # Call the format_casual_partnership function
            agents, Ca, All_casual_partnerships, Now_casual_partnerships = Format_casual_partnership(
                agents, Ca, pairs_Cas, All_casual_partnerships, Now_casual_partnerships, week_cycle
            )

        All_regular_partnerships = All_regular_partnerships[All_regular_partnerships['ini_week'] >= week_cycle - 52]
        All_casual_partnerships = All_casual_partnerships[All_casual_partnerships['ini_week'] >= week_cycle - 52]
        agents = Update_sex_info(agents, All_casual_partnerships, week_cycle)
#%%
    Popu_struc_data = load_population_data()
    years = range(2012, 2012 + (N_weeks_4 - N_weeks_2) // 52)
    Yearly_HIV_PrEP_Popu = pd.DataFrame(index=['Total_Population','PrEP_users', 'HIV_positive', 'PrEP_non_users', 'Doxy_PEP_coverage'], 
                                   columns=[str(year) for year in years])
    for week_cycle in range(N_weeks_2 + 1, N_weeks_3 + 1):
        if week_cycle >= 442:
            Tetra_Bg_increase = params['Tetra_Bg_increase_2nd']
            
        if week_cycle % 52 == 0:
            year = str(week_cycle // 52 + 2009)
            Yearly_HIV_PrEP_Popu.loc['PrEP_users', year] = agents['PrEP'].sum()
            Yearly_HIV_PrEP_Popu.loc['HIV_positive', year] = agents['HIV'].sum()
            Yearly_HIV_PrEP_Popu.loc['PrEP_non_users', year] = len(agents) - agents['PrEP'].sum() - agents['HIV'].sum()
            Yearly_HIV_PrEP_Popu.loc['Total_Population', year] = len(agents)
            Yearly_HIV_PrEP_Popu.loc['Doxy_PEP_coverage', year] = agents['Doxy-PEP'].sum()/len(agents)
            
            agents, Now_regular_partnerships, Now_casual_partnerships, All_casual_partnerships, Ra, Ca = update_population(
                agents, week_cycle, Popu_struc_data, Now_regular_partnerships, Now_casual_partnerships, All_casual_partnerships, Ra, Ca
            )
       
        # (1) STI transmision according to sex act, condom use, transmission probability
        # Apply the sex prob function to the partnerships DataFrames
        Now_regular_partnerships = Calculate_sex_act_prob(Now_regular_partnerships, week_cycle)
        Now_casual_partnerships = Calculate_sex_act_prob(Now_casual_partnerships, week_cycle)

        # Transmit the infection according to the sex act this week
        Weekly_sex_pairs = pd.concat([
            Now_regular_partnerships[Now_regular_partnerships['weekly_sex_epi'] > 0],
            Now_casual_partnerships[Now_casual_partnerships['weekly_sex_epi'] > 0]
        ])

        Transmission_pairs = Filter_transmission_pairs(agents,Weekly_sex_pairs)
        agents, Weekly_new_infections = STI_transmission(agents, Transmission_pairs, Weekly_new_infections, week_cycle)

        # Update the doxy ADR (only the background ADR before doxy-PEP)
        agents.loc[(agents['NG_Pos'] == True) & (agents['NG_AMR_Dox'] == False), 'NG_AMR_Dox'] = np.random.binomial(
            1,
            Tetra_Bg_increase,
            size=len(agents[(agents['NG_Pos'] == True) & (agents['NG_AMR_Dox'] == False)])
        ).astype(bool)

    # (2) STI progress, test/screening, treatment, with the prevalence calculation
        agents, Weekly_screened_diagnosis = Update_STI_Stage_progress_screening_treatment(agents, Weekly_screened_diagnosis, week_cycle)

    # (3) Reformat aging agents;
        # (A) Detect the partnership ends this week
        Ending_regular_partnerships = Now_regular_partnerships[Now_regular_partnerships['end_week'] == week_cycle]
        Ending_casual_partnerships = Now_casual_partnerships[Now_casual_partnerships['end_week'] == week_cycle]

        # Update the existed partnerships
        # Remove end partnership
        Now_regular_partnerships = Now_regular_partnerships[Now_regular_partnerships['end_week'] > week_cycle]
        Now_casual_partnerships = Now_casual_partnerships[Now_casual_partnerships['end_week'] > week_cycle]

        # Return partners back to Ra, Ca
        ending_reg_ids = pd.Index(Ending_regular_partnerships[['partner1', 'partner2']].values.ravel())
        ending_cas_ids = pd.Index(Ending_casual_partnerships[['partner1', 'partner2']].values.ravel())

        agents.loc[ending_reg_ids, 'Reg_now'] = False
        agents.loc[ending_cas_ids, 'Cas_now'] = False

        Ra = Ra.union(ending_reg_ids)
        Ca = Ca.union(ending_cas_ids)

        # (B) Reunite the regular partnerships
        if len(Ra) > 1:
            pairs_Reg = (pd.DataFrame(np.reshape(np.random.choice(Ra, size=(len(Ra) // 2) * 2, replace=False), (-1, 2)),
                                      columns=['partner1', 'partner2'])
                .merge(agents[['SCC_require', 'HIV']], left_on='partner1', right_index=True)
                .merge(agents[['SCC_require', 'HIV']], left_on='partner2', right_index=True, suffixes=('_1', '_2'))
                # Filter pairs based on the criteria
                .query("((SCC_require_1 | SCC_require_2) & (HIV_1 == HIV_2)) | (~SCC_require_1 & ~SCC_require_2)")
                [['partner1', 'partner2']]
            )
            # Only proceed if there are valid pairs
            if len(pairs_Reg) > 0:
                agents, Ra, All_regular_partnerships, Now_regular_partnerships = Format_regular_partnership(
                    agents, Ra, pairs_Reg, All_regular_partnerships, Now_regular_partnerships, week_cycle
                )

        # (C) Reunite the casual partnerships
        if len(Ca) > 1:
            temp = agents.loc[Ca][['P_Ci']]
            temp['P_Cd'] = np.random.binomial(1, np.minimum(temp['P_Ci'], 1))

            Ca_d = set(temp[temp['P_Cd'] == 1].index)
            # if len(Ca_d) > 1:
            pairs_Cas = pd.DataFrame(np.reshape(np.random.choice(list(Ca_d), size=(len(Ca_d) // 2) * 2, replace=False), (-1, 2)), columns=['partner1', 'partner2'])
            # Call the format_casual_partnership function
            agents, Ca, All_casual_partnerships, Now_casual_partnerships = Format_casual_partnership(
                agents, Ca, pairs_Cas, All_casual_partnerships, Now_casual_partnerships, week_cycle
            )

        All_regular_partnerships = All_regular_partnerships[All_regular_partnerships['ini_week'] >= week_cycle - 52]
        All_casual_partnerships = All_casual_partnerships[All_casual_partnerships['ini_week'] >= week_cycle - 52]
        agents = Update_sex_info(agents, All_casual_partnerships, week_cycle)
#%%
    Yearly_infection = summarize_yearly(Weekly_new_infections, N_weeks_2, N_weeks_4)
    Yearly_screened_diagnosis = summarize_yearly(Weekly_screened_diagnosis, N_weeks_2, N_weeks_4)

    new_inci_values = {
        'NG_Inci_Overall': safe_divide(Yearly_infection.loc['NG_new_infections'], Yearly_HIV_PrEP_Popu.loc['Total_Population']),
        'CT_Inci_Overall': safe_divide(Yearly_infection.loc['CT_new_infections'], Yearly_HIV_PrEP_Popu.loc['Total_Population']),
        'TP_Inci_Overall': safe_divide(Yearly_infection.loc['TP_new_infections'], Yearly_HIV_PrEP_Popu.loc['Total_Population']),
        'NG_Inci_NoPrEP': safe_divide(Yearly_infection.loc['NG_new_infections_PrEP_False'], Yearly_HIV_PrEP_Popu.loc['PrEP_non_users']),
        'NG_Inci_PrEP': safe_divide(Yearly_infection.loc['NG_new_infections_PrEP_True'], Yearly_HIV_PrEP_Popu.loc['PrEP_users']),
        'NG_Inci_HIV': safe_divide(Yearly_infection.loc['NG_new_infections_HIV_True'], Yearly_HIV_PrEP_Popu.loc['HIV_positive']),
        'CT_Inci_NoPrEP': safe_divide(Yearly_infection.loc['CT_new_infections_PrEP_False'], Yearly_HIV_PrEP_Popu.loc['PrEP_non_users']),
        'CT_Inci_PrEP': safe_divide(Yearly_infection.loc['CT_new_infections_PrEP_True'], Yearly_HIV_PrEP_Popu.loc['PrEP_users']),
        'CT_Inci_HIV': safe_divide(Yearly_infection.loc['CT_new_infections_HIV_True'], Yearly_HIV_PrEP_Popu.loc['HIV_positive']),
        'TP_Inci_NoPrEP': safe_divide(Yearly_infection.loc['TP_new_infections_PrEP_False'], Yearly_HIV_PrEP_Popu.loc['PrEP_non_users']),
        'TP_Inci_PrEP': safe_divide(Yearly_infection.loc['TP_new_infections_PrEP_True'], Yearly_HIV_PrEP_Popu.loc['PrEP_users']),
        'TP_Inci_HIV': safe_divide(Yearly_infection.loc['TP_new_infections_HIV_True'], Yearly_HIV_PrEP_Popu.loc['HIV_positive']),
    }

    for key, value in new_inci_values.items():
        Yearly_infection.loc[key] = value

    Yearly_infection.loc[list(new_inci_values.keys())]

    new_diag_values = {
    'NG_Pos_rate': safe_divide((Yearly_screened_diagnosis.loc['NG_screened'] + Yearly_screened_diagnosis.loc['NG_symptom_diag']),
                               (Yearly_screened_diagnosis.loc['All_screened'] + Yearly_screened_diagnosis.loc['NG_symptom_diag'])),
    'CT_Pos_rate': safe_divide((Yearly_screened_diagnosis.loc['CT_screened'] + Yearly_screened_diagnosis.loc['CT_symptom_diag']),
                               (Yearly_screened_diagnosis.loc['All_screened'] + Yearly_screened_diagnosis.loc['CT_symptom_diag'])),
    'TP_Pos_rate': safe_divide((Yearly_screened_diagnosis.loc['TP_early_screened'] + Yearly_screened_diagnosis.loc['TP_early_symptom_diag'] +
                                Yearly_screened_diagnosis.loc['TP_late_screened'] + Yearly_screened_diagnosis.loc['TP_late_symptom_diag']),
                               (Yearly_screened_diagnosis.loc['All_screened'] + Yearly_screened_diagnosis.loc['TP_early_symptom_diag'] +
                                Yearly_screened_diagnosis.loc['TP_late_symptom_diag'])),
    'NG_Cef_prop': safe_divide(Yearly_screened_diagnosis.loc['NG_diag_Res_Cef'],
                               (Yearly_screened_diagnosis.loc['NG_screened'] + Yearly_screened_diagnosis.loc['NG_symptom_diag'])),
    'NG_Dox_prop': safe_divide(Yearly_screened_diagnosis.loc['NG_diag_Res_Dox'],
                               (Yearly_screened_diagnosis.loc['NG_screened'] + Yearly_screened_diagnosis.loc['NG_symptom_diag'])),
    }

    for key, value in new_diag_values.items():
        Yearly_screened_diagnosis.loc[key] = value

    return (
        params,
        agents,
        All_regular_partnerships,
        All_casual_partnerships,
        Now_regular_partnerships,
        Now_casual_partnerships,
        Ra, Ca,
        Weekly_new_infections,
        Weekly_screened_diagnosis,
        Yearly_HIV_PrEP_Popu,
        Yearly_infection,
        Yearly_screened_diagnosis
    )

# %% Fun 18. Run simulation second part
def run_simulation_second_part(intermediate_data, scenario_index, N_agents, N_weeks_1, N_weeks_2, N_weeks_3, N_weeks_4):
    """
    Continue the simulation from N_weeks_2 to N_weeks_3 incorporating the use of Doxy-PEP based on a specified strategy.
    This function simulates the dynamics of STI transmission, progression, and intervention with Doxy-PEP,
    and recalculates the partnership network and infection dynamics.

    Parameters:
    intermediate_data (dict): Dictionary containing data from the first part of the simulation.
    scenario_index (str): Scenario identifier for Doxy-PEP intervention.
    N_agents (int): Number of agents in the simulation.
    N_weeks_1 (int): Number of weeks completed in the first part of the simulation.
    N_weeks_2 (int): Starting week for the second part of the simulation.
    N_weeks_3 (int): Total number of weeks for the simulation.

    Returns:
    tuple: A tuple containing the final agents DataFrame, yearly infection data, yearly screening and diagnosis data, and yearly Doxy use data.
    """

    """
    (1) STI transmision according to sex act, condom use, transmission probability;
    (2) STI recovery, test/screening, treatment;
    ### Key point: Output the outbreak information here
    (3) Reformat the partnership network
    """
    np.random.seed(123)
    params = intermediate_data[0]
    agents = intermediate_data[1]
    All_regular_partnerships = intermediate_data[2]
    All_casual_partnerships = intermediate_data[3]
    Now_regular_partnerships = intermediate_data[4]
    Now_casual_partnerships = intermediate_data[5]
    Ra = intermediate_data[6]
    Ca = intermediate_data[7]
    Weekly_new_infections = intermediate_data[8]
    Weekly_screened_diagnosis = intermediate_data[9]    
    Yearly_HIV_PrEP_Popu = intermediate_data[10]
    
    # Initialize Weekly_Doxy_outcomes DataFrame
    age_groups = [(15,19), (20,24), (25,29), (30,34), (35,39), (40,44), (45,49), (50,54), (55,59), (60,64)]
    age_columns = {f'Doxy_PEP_age_{min_age}_{max_age}': 0 for min_age, max_age in age_groups}
    
    Weekly_Doxy_outcomes = pd.DataFrame({
        'week': range(N_weeks_1 + 1, N_weeks_4 + 1),
        'Doxy_PEP_enter': 0,
        'Doxy_PEP_quit': 0,
        'Doxy_PEP_consume': 0,
        'Doxy_PEP_HIV_pos': 0,
        'Doxy_PEP_PrEP_users': 0,
        **age_columns
    })

    global STI_trans_probs, NG_Ini_Pos_Rate, NG_Ini_Cef_Res_Rate, NG_Ini_Dox_Res_Rate, CT_Ini_Pos_Rate, TP_Ini_Pos_Rate,\
           Cef_failure_prob, Cef_ADR_rate, Tetra_Bg_increase, Doxy_PEP_Uptake, Doxy_PEP_Adherence, Doxy_PEP_Efficacy,\
           NG_Ini_Pos_Rate_HIV_new, NG_Ini_Pos_Rate_PrEP_new, CT_Ini_Pos_Rate_HIV_new, CT_Ini_Pos_Rate_PrEP_new,\
           TP_Ini_Pos_Rate_HIV_new, TP_Ini_Pos_Rate_PrEP_new, sometime_condom_prob, Always_condom_ratio,\
           NG_Sym_Proportion, Doxy_resis_increase

    STI_trans_probs = params['STI_trans_probs']
    NG_Ini_Pos_Rate = params['NG_Ini_Pos_Rate']
    NG_Ini_Cef_Res_Rate = params['NG_Ini_Cef_Res_Rate']
    NG_Ini_Dox_Res_Rate = params['NG_Ini_Dox_Res_Rate']
    CT_Ini_Pos_Rate = params['CT_Ini_Pos_Rate']
    TP_Ini_Pos_Rate = params['TP_Ini_Pos_Rate']
    Cef_ADR_rate = params['Cef_ADR_rate']
    NG_Ini_Pos_Rate_HIV_new = params['NG_Ini_Pos_Rate_HIV']*Doxy_PEP_Scenarios.loc[scenario_index]['Ini_Pos_Ratio']
    NG_Ini_Pos_Rate_PrEP_new = params['NG_Ini_Pos_Rate_PrEP']*Doxy_PEP_Scenarios.loc[scenario_index]['Ini_Pos_Ratio']
    CT_Ini_Pos_Rate_HIV_new = params['CT_Ini_Pos_Rate_HIV']*Doxy_PEP_Scenarios.loc[scenario_index]['Ini_Pos_Ratio']
    CT_Ini_Pos_Rate_PrEP_new = params['CT_Ini_Pos_Rate_PrEP']*Doxy_PEP_Scenarios.loc[scenario_index]['Ini_Pos_Ratio']
    TP_Ini_Pos_Rate_HIV_new = params['TP_Ini_Pos_Rate_HIV']*Doxy_PEP_Scenarios.loc[scenario_index]['Ini_Pos_Ratio']
    TP_Ini_Pos_Rate_PrEP_new = params['TP_Ini_Pos_Rate_PrEP']*Doxy_PEP_Scenarios.loc[scenario_index]['Ini_Pos_Ratio']
    
    Tetra_Bg_increase = params['Tetra_Bg_increase_2nd']*Doxy_PEP_Scenarios.loc[scenario_index]['Background_increase_ratio']
    Doxy_resis_increase = Tetra_Bg_increase*Doxy_PEP_Scenarios.loc[scenario_index]['Doxy_increase_ratio']
    Cef_failure_prob = params['Cef_failure_prob']*Doxy_PEP_Scenarios.loc[scenario_index]['Cef_failure_prob_ratio']

    Doxy_PEP_Uptake = Doxy_PEP_Scenarios.loc[scenario_index]['Uptake']
    Doxy_PEP_Adherence = Doxy_PEP_Scenarios.loc[scenario_index]['Adherence']
    Doxy_PEP_Efficacy = Doxy_PEP_Scenarios.loc[scenario_index]['Efficacy']
    Always_condom_ratio = Doxy_PEP_Scenarios.loc[scenario_index]['Always_condom_ratio']
    sometime_condom_prob = Doxy_PEP_Scenarios.loc[scenario_index]['Sometime_condom']
    NG_Sym_Proportion = Doxy_PEP_Scenarios.loc[scenario_index]['NG_Sym_Proportion']

    Popu_struc_data = load_population_data()

    for week_cycle in range(N_weeks_3 + 1, N_weeks_4 + 1):
        if week_cycle % 52 == 0:
            year = str(week_cycle // 52 + 2009)
            Yearly_HIV_PrEP_Popu.loc['PrEP_users', year] = agents['PrEP'].sum()
            Yearly_HIV_PrEP_Popu.loc['HIV_positive', year] = agents['HIV'].sum()
            Yearly_HIV_PrEP_Popu.loc['PrEP_non_users', year] = len(agents) - agents['PrEP'].sum() - agents['HIV'].sum()
            Yearly_HIV_PrEP_Popu.loc['Total_Population', year] = len(agents)
            Yearly_HIV_PrEP_Popu.loc['Doxy_PEP_coverage', year] = agents['Doxy-PEP'].sum()/len(agents)

            agents, Now_regular_partnerships, Now_casual_partnerships, All_casual_partnerships, Ra, Ca = update_population(
                agents, week_cycle, Popu_struc_data, Now_regular_partnerships, Now_casual_partnerships, All_casual_partnerships, Ra, Ca
            )
            
    # (1) STI transmision according to sex act, condom use, transmission probability
        # Apply the sex prob function to the partnerships DataFrames
        Now_regular_partnerships = Calculate_sex_act_prob(Now_regular_partnerships, week_cycle)
        Now_casual_partnerships = Calculate_sex_act_prob(Now_casual_partnerships, week_cycle)

        # Transmit the infection according to the weekly sex act
        Weekly_sex_pairs = pd.concat([
            Now_regular_partnerships[Now_regular_partnerships['weekly_sex_epi'] > 0],
            Now_casual_partnerships[Now_casual_partnerships['weekly_sex_epi'] > 0]
        ])

        Transmission_pairs = Filter_transmission_pairs(agents,Weekly_sex_pairs)
        agents, Weekly_new_infections = STI_transmission(agents, Transmission_pairs, Weekly_new_infections, week_cycle)

        # Update the doxy ADR (both the background ADR and DoxyPEP-related ADR)
        agents.loc[(agents['NG_Pos'] == True) & (agents['NG_AMR_Dox'] == False), 'NG_AMR_Dox'] = np.random.binomial(
            1,
            Tetra_Bg_increase,
            size=len(agents[(agents['NG_Pos'] == True) & (agents['NG_AMR_Dox'] == False)])
        ).astype(bool)

        # Detect the daily Doxycycline usage
        Weekly_condomless_sex_pairs = pd.concat([
            Now_regular_partnerships[Now_regular_partnerships['weekly_condomless_sex_epi'] > 0],
            Now_casual_partnerships[Now_casual_partnerships['weekly_condomless_sex_epi'] > 0]
        ])

        Condomless_epi_by_agents = pd.concat([
            Weekly_condomless_sex_pairs[['partner1', 'weekly_condomless_sex_epi']].rename(columns={'partner1': 'Agent'}),
            Weekly_condomless_sex_pairs[['partner2', 'weekly_condomless_sex_epi']].rename(columns={'partner2': 'Agent'})
            ]).groupby('Agent')['weekly_condomless_sex_epi'].sum()

        doxy_indices = Condomless_epi_by_agents.index.intersection(agents[agents['Doxy-PEP'] == True].index)
        actual_usage = np.random.binomial(Condomless_epi_by_agents[doxy_indices],Doxy_PEP_Adherence)
        agents.loc[doxy_indices, 'Doxy-PEP_Use'] += actual_usage
        Weekly_Doxy_outcomes.loc[Weekly_Doxy_outcomes['week'] == week_cycle, 'Doxy_PEP_consume'] = actual_usage.sum()
        
        Agents_Might_Dox_ADR = doxy_indices.intersection(agents[(agents['NG_Pos'] == True) & (agents['NG_AMR_Dox'] == False)].index)
        agents.loc[Agents_Might_Dox_ADR, 'NG_AMR_Dox'] = (
            np.random.binomial(actual_usage[np.isin(doxy_indices, Agents_Might_Dox_ADR)], Doxy_resis_increase) > 0
            ).astype(bool)
        
    # (2) STI progress, test/screening, treatment
        agents, Weekly_screened_diagnosis, Weekly_Doxy_outcomes = Update_STI_Stage_progress_screening_treatment_new(agents, Weekly_screened_diagnosis, Weekly_Doxy_outcomes, week_cycle, scenario_index)
        Doxy_quit_index = (agents['Doxy-PEP'] == True) & (agents['Doxy-PEP_Use'] >= 2*Doxy_PEP_Scenarios.loc[scenario_index]['Duration'])
        agents.loc[Doxy_quit_index, 'Doxy-PEP'] = False
        agents.loc[Doxy_quit_index, 'Doxy-PEP_Use'] = 0
        Weekly_Doxy_outcomes.loc[Weekly_Doxy_outcomes['week'] == week_cycle, 'Doxy_PEP_quit'] = Doxy_quit_index.sum()

    # (3) Reformat aging agents;
        # (A) Detect the partnership ends this week
        Ending_regular_partnerships = Now_regular_partnerships[Now_regular_partnerships['end_week'] == week_cycle]
        Ending_casual_partnerships = Now_casual_partnerships[Now_casual_partnerships['end_week'] == week_cycle]

        # Update the existed partnerships
        # Remove end partnership
        Now_regular_partnerships = Now_regular_partnerships[Now_regular_partnerships['end_week'] > week_cycle]
        Now_casual_partnerships = Now_casual_partnerships[Now_casual_partnerships['end_week'] > week_cycle]

        # Return partners back to Ra, Ca
        ending_reg_ids = pd.Index(Ending_regular_partnerships[['partner1', 'partner2']].values.ravel())
        ending_cas_ids = pd.Index(Ending_casual_partnerships[['partner1', 'partner2']].values.ravel())

        agents.loc[ending_reg_ids, 'Reg_now'] = False
        agents.loc[ending_cas_ids, 'Cas_now'] = False

        Ra = Ra.union(ending_reg_ids)
        Ca = Ca.union(ending_cas_ids)

        # (B) Reunite the regular partnerships
        if len(Ra) > 1:
            pairs_Reg = (pd.DataFrame(np.reshape(np.random.choice(Ra, size=(len(Ra) // 2) * 2, replace=False), (-1, 2)),
                                      columns=['partner1', 'partner2'])
                .merge(agents[['SCC_require', 'HIV']], left_on='partner1', right_index=True)
                .merge(agents[['SCC_require', 'HIV']], left_on='partner2', right_index=True, suffixes=('_1', '_2'))
                # Filter pairs based on the criteria
                .query("((SCC_require_1 | SCC_require_2) & (HIV_1 == HIV_2)) | (~SCC_require_1 & ~SCC_require_2)")
                [['partner1', 'partner2']]
            )
            # Only proceed if there are valid pairs
            if len(pairs_Reg) > 0:
                agents, Ra, All_regular_partnerships, Now_regular_partnerships = Format_regular_partnership(
                    agents, Ra, pairs_Reg, All_regular_partnerships, Now_regular_partnerships, week_cycle, sometime_condom_prob
                )

        # (C) Reunite the casual partnerships
        if len(Ca) > 1:
            temp = agents.loc[Ca][['P_Ci']]
            temp['P_Cd'] = np.random.binomial(1, np.minimum(temp['P_Ci'], 1))

            Ca_d = set(temp[temp['P_Cd'] == 1].index)
            # if len(Ca_d) > 1:
            pairs_Cas = pd.DataFrame(np.reshape(np.random.choice(list(Ca_d), size=(len(Ca_d) // 2) * 2, replace=False), (-1, 2)), columns=['partner1', 'partner2'])
            # Call the format_casual_partnership function
            agents, Ca, All_casual_partnerships, Now_casual_partnerships = Format_casual_partnership(
                agents, Ca, pairs_Cas, All_casual_partnerships, Now_casual_partnerships, week_cycle, sometime_condom_prob
            )

        All_regular_partnerships = All_regular_partnerships[All_regular_partnerships['ini_week'] >= week_cycle - 52]
        All_casual_partnerships = All_casual_partnerships[All_casual_partnerships['ini_week'] >= week_cycle - 52]
        agents = Update_sex_info(agents, All_casual_partnerships, week_cycle)

    Yearly_infection = summarize_yearly(Weekly_new_infections, N_weeks_2, N_weeks_4)
    Yearly_screened_diagnosis = summarize_yearly(Weekly_screened_diagnosis, N_weeks_2, N_weeks_4)

    new_inci_values = {
        'All_Inci_Overall': safe_divide(Yearly_infection.loc['All_new_infections'], Yearly_HIV_PrEP_Popu.loc['Total_Population']),
        'NG_Inci_Overall': safe_divide(Yearly_infection.loc['NG_new_infections'], Yearly_HIV_PrEP_Popu.loc['Total_Population']),
        'CT_Inci_Overall': safe_divide(Yearly_infection.loc['CT_new_infections'], Yearly_HIV_PrEP_Popu.loc['Total_Population']),
        'TP_Inci_Overall': safe_divide(Yearly_infection.loc['TP_new_infections'], Yearly_HIV_PrEP_Popu.loc['Total_Population']),
        'NG_Inci_NoPrEP': safe_divide(Yearly_infection.loc['NG_new_infections_PrEP_False'], Yearly_HIV_PrEP_Popu.loc['PrEP_non_users']),
        'NG_Inci_PrEP': safe_divide(Yearly_infection.loc['NG_new_infections_PrEP_True'], Yearly_HIV_PrEP_Popu.loc['PrEP_users']),
        'NG_Inci_HIV': safe_divide(Yearly_infection.loc['NG_new_infections_HIV_True'], Yearly_HIV_PrEP_Popu.loc['HIV_positive']),
        'CT_Inci_NoPrEP': safe_divide(Yearly_infection.loc['CT_new_infections_PrEP_False'], Yearly_HIV_PrEP_Popu.loc['PrEP_non_users']),
        'CT_Inci_PrEP': safe_divide(Yearly_infection.loc['CT_new_infections_PrEP_True'], Yearly_HIV_PrEP_Popu.loc['PrEP_users']),
        'CT_Inci_HIV': safe_divide(Yearly_infection.loc['CT_new_infections_HIV_True'], Yearly_HIV_PrEP_Popu.loc['HIV_positive']),
        'TP_Inci_NoPrEP': safe_divide(Yearly_infection.loc['TP_new_infections_PrEP_False'], Yearly_HIV_PrEP_Popu.loc['PrEP_non_users']),
        'TP_Inci_PrEP': safe_divide(Yearly_infection.loc['TP_new_infections_PrEP_True'], Yearly_HIV_PrEP_Popu.loc['PrEP_users']),
        'TP_Inci_HIV': safe_divide(Yearly_infection.loc['TP_new_infections_HIV_True'], Yearly_HIV_PrEP_Popu.loc['HIV_positive']),
    }

    for key, value in new_inci_values.items():
        Yearly_infection.loc[key] = value

    Yearly_infection.loc[list(new_inci_values.keys())]

    new_diag_values = {
    'NG_Pos_rate': safe_divide((Yearly_screened_diagnosis.loc['NG_screened'] + Yearly_screened_diagnosis.loc['NG_symptom_diag']),
                               (Yearly_screened_diagnosis.loc['All_screened'] + Yearly_screened_diagnosis.loc['NG_symptom_diag'])),
    'CT_Pos_rate': safe_divide((Yearly_screened_diagnosis.loc['CT_screened'] + Yearly_screened_diagnosis.loc['CT_symptom_diag']),
                               (Yearly_screened_diagnosis.loc['All_screened'] + Yearly_screened_diagnosis.loc['CT_symptom_diag'])),
    'TP_Pos_rate': safe_divide((Yearly_screened_diagnosis.loc['TP_early_screened'] + Yearly_screened_diagnosis.loc['TP_early_symptom_diag'] +
                                Yearly_screened_diagnosis.loc['TP_late_screened'] + Yearly_screened_diagnosis.loc['TP_late_symptom_diag']),
                               (Yearly_screened_diagnosis.loc['All_screened'] + Yearly_screened_diagnosis.loc['TP_early_symptom_diag'] +
                                Yearly_screened_diagnosis.loc['TP_late_symptom_diag'])),
    'NG_Cef_prop': safe_divide(Yearly_screened_diagnosis.loc['NG_diag_Res_Cef'],
                               (Yearly_screened_diagnosis.loc['NG_screened'] + Yearly_screened_diagnosis.loc['NG_symptom_diag'])),
    'NG_Dox_prop': safe_divide(Yearly_screened_diagnosis.loc['NG_diag_Res_Dox'],
                               (Yearly_screened_diagnosis.loc['NG_screened'] + Yearly_screened_diagnosis.loc['NG_symptom_diag'])),
}

    for key, value in new_diag_values.items():
        Yearly_screened_diagnosis.loc[key] = value

    Yearly_screened_diagnosis.loc[list(new_diag_values.keys())]
    Yearly_Doxy_use = summarize_yearly(Weekly_Doxy_outcomes, N_weeks_2, N_weeks_4)

    return Yearly_infection, Yearly_screened_diagnosis, Yearly_Doxy_use, Yearly_HIV_PrEP_Popu