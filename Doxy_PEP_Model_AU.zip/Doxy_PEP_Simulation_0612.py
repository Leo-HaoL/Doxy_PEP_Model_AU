"""
Doxy-PEP Simulation Main Script
==============================

Main entry point for the Doxy-PEP simulation model. Orchestrates the simulation process:
1. Network stabilization
2. STI distribution stabilization
3. Historical STI transmission (2012-2024)
4. Future STI transmission under Doxy-PEP scenarios (2025-2034)

Features:
- Parallel processing for multiple parameter sets
- Multi-phase simulation approach
- Comprehensive data storage

Author: HaoL
"""


# %% Import necessary packages and the seeds
import numpy as np

import os
from datetime import datetime
from joblib import Parallel, delayed
import importlib
import pickle
import Doxy_PEP_Simu_functions_0612 as my_fc

current_folder_path = os.path.dirname(os.path.abspath(__file__))
os.chdir(current_folder_path)

# %% Prepare for the indicator assignments
# Set seeds
np.random.seed(123)

week_ini = 0 
N_agents = 10000  # Initial num of agents
N_weeks_1 = 52  # Time simulated for network stabilization (not counted in the real-word time)
N_weeks_2 = N_weeks_1 + 52  # Time simulated for STI distribution stabilization (not counted in the real-word time)
N_weeks_3 = N_weeks_2 + 52 * 13  # Time simulated for STI transmission before doxy-PEP (2012-2024)
N_weeks_4 = N_weeks_3 + 52 * 10  # Time simulated for STI transmission under different doxy-PEP scenarios (2025-2034)
n_jobs = -1 # Use all available cores

with open('Data_tobe_called/Best_params_sets.pkl', 'rb') as f:
    simulation_params_list = pickle.load(f)
    
N_simu = simulation_params_list
#%% Parallel processing 1
start_time_1 = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

importlib.reload(my_fc)

# Run the base case between 2012 and 2024, then save the outcomes for the 12 scenarios
intermediate_outcomes = Parallel(n_jobs=n_jobs)(
    delayed(my_fc.run_simulation_first_part)(
        simu, simulation_params_list[simu], N_agents, N_weeks_1, N_weeks_2, N_weeks_3, N_weeks_4, week_ini
    ) for simu in range(N_simu)
)

end_time_1 = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
print(f"Runtime：{np.round((datetime.strptime(end_time_1, '%Y-%m-%d %H:%M:%S').timestamp() - datetime.strptime(start_time_1, '%Y-%m-%d %H:%M:%S').timestamp())/60, 1)} mins")
#%% Parallel processing 2
    
start_time_2 = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
doxy_scenarios = range(0, 150)

results = []
for strategy in doxy_scenarios:
    strategy_results = Parallel(n_jobs=n_jobs)(
        delayed(my_fc.run_simulation_second_part)(
            data, strategy, N_agents, N_weeks_1, N_weeks_2, N_weeks_3, N_weeks_4
        ) for data in intermediate_outcomes
    )
    results.append(strategy_results)

end_time_2 = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

with open('Data_tobe_called/All_params_results.pkl', 'wb') as f:
    pickle.dump(results, f)

print(f"Runtime：{np.round((datetime.strptime(end_time_2, '%Y-%m-%d %H:%M:%S').timestamp() - datetime.strptime(start_time_2, '%Y-%m-%d %H:%M:%S').timestamp())/60, 1)} mins")