"""
Doxy-PEP Analysis and Visualization Functions
===========================================

Functions for analyzing and visualizing Doxy-PEP simulation results:

1. Data Analysis:
   - Statistical calculations and CIs
   - Scenario comparison
   - Cost-effectiveness analysis
   - Resistance analysis

2. Visualization:
   - STI incidence trends
   - Resistance patterns
   - Cost-effectiveness plots
   - Sensitivity analysis
   - Efficient frontiers

3. Results Processing:
   - Data aggregation
   - Model validation
   - Publication formatting

4. Reporting:
   - Summary statistics
   - Publication figures
   - Custom formatting

Author: HaoL
"""

import numpy as np
import pandas as pd
import os
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
import matplotlib.gridspec as gridspec
from scipy.stats import t, sem
from scipy import stats

# -----------------------------------------------------------------------------
# FILE PATHS AND GLOBAL CONFIGURATIONS
# -----------------------------------------------------------------------------
current_folder_path = os.path.dirname(os.path.abspath(__file__))
output_dir = os.path.join(current_folder_path, 'Data_output')
input_dir = os.path.join(current_folder_path, 'Data_tobe_called')
os.chdir(current_folder_path)
np.random.seed(123)
scenario_names = [
    'Base case (No doxy-PEP)',
    'One syphilis diagnosis',
    'Two STI diagnoses in 6m',
    'Two STI diagnoses in 12m',
    'HIV positive attendees',
    'PrEP-using attendees'
]

# -----------------------------------------------------------------------------
# DATA PREPROCESSING AND COMBINATION FUNCTIONS
# -----------------------------------------------------------------------------
def combine_model_outcomes(results_for_process):
    """
    Merge dataframes 1-4 for each parameter set.
    
    Args:
        results_for_process: List of results for 6 scenarios, each containing 100 parameter sets
        
    Returns:
        List of merged results for 6 scenarios, each containing 100 merged dataframes
    """
    combined_results = []

    for scenario in results_for_process:
        scenario_combined = []
        for param_set in scenario:
            df1, df2, df3, df4 = param_set[0:4]
            combined_df = pd.concat([df1, df2, df3, df4], axis=0)

            combined_df.loc['Doxycycline_consume'] = combined_df.loc['Doxy_PEP_consume'] * 2
            combined_df.loc['STI_Inci_Overall'] = combined_df.loc['NG_Inci_Overall'] + combined_df.loc['CT_Inci_Overall'] + combined_df.loc['TP_Inci_Overall']
            scenario_combined.append(combined_df)
        combined_results.append(scenario_combined)
    return combined_results

# -----------------------------------------------------------------------------
# CORE CALCULATION FUNCTIONS
# -----------------------------------------------------------------------------
def calculate_means_for_scenario(scenario_results, variable, years):
    """
    Calculate mean values for a variable or variable combination across all parameter sets.
    
    Args:
        scenario_results: List of DataFrames containing results for all parameter sets
        variable: Single variable name or list of variables/coefficients
        years: List of years to include in calculation
    """
    means = []
    for year in years:
        year_values = []
        for param_set in scenario_results:
            if isinstance(variable, list):
                if all(isinstance(item, str) for item in variable):
                    value = sum(param_set.loc[var, str(year)] for var in variable)
                else:
                    value = sum(param_set.loc[var, str(year)] * coef for var, coef in variable)
            else:
                value = param_set.loc[variable, str(year)]
            year_values.append(value)
        means.append(np.mean(year_values))
    return means

def Compute_mean_CI(results_for_process, start_year=2012, end_year=2034):
    """
    Calculate mean values and confidence intervals for all variables across all scenarios.
    
    Args:
        results_for_process: List of results for 6 scenarios, each containing 100 parameter sets
        start_year: Start year for calculations
        end_year: End year for calculations
        
    Returns:
        List of (stats_df, delta_df) tuples for each scenario, where:
        - stats_df contains mean, standard error, and confidence intervals for each variable
        - delta_df contains differences from the baseline scenario
    """
    final_output = []
    year_range = [str(year) for year in range(start_year, end_year + 1)]
    columns = pd.MultiIndex.from_product([year_range, ['Mean', 'SE', 'CI Lower', 'CI Upper']])

    baseline_dataframes = None 

    for i, scenario in enumerate(results_for_process):
        merged_dataframes = []
        for params in scenario:
            merged_dataframes.append(params)

        variables = merged_dataframes[0].index
        stats_df = pd.DataFrame(index=variables, columns=columns) 
        delta_df = pd.DataFrame(index=variables, columns=columns) 

        for var in variables:
            data = np.array([df.loc[var, year_range].astype(float) for df in merged_dataframes])
            mean_values = np.mean(data, axis=0)
            se_values = sem(data, axis=0)
            freedom_degree = len(data) - 1
            ci_values = se_values * t.ppf((1 + 0.95) / 2., freedom_degree)

            for year_idx, year_str in enumerate(year_range):
                stats_df.loc[var, (year_str, 'Mean')] = mean_values[year_idx]
                stats_df.loc[var, (year_str, 'SE')] = se_values[year_idx]
                stats_df.loc[var, (year_str, 'CI Lower')] = mean_values[year_idx] - ci_values[year_idx]
                stats_df.loc[var, (year_str, 'CI Upper')] = mean_values[year_idx] + ci_values[year_idx]

        if baseline_dataframes is None:
            baseline_dataframes = stats_df.copy()

        for var in variables:
            for year_str in year_range:
                for stat in ['Mean', 'SE', 'CI Lower', 'CI Upper']:
                    baseline_value = baseline_dataframes.loc[var, (year_str, stat)]
                    current_value = stats_df.loc[var, (year_str, stat)]
                    delta_df.loc[var, (year_str, stat)] = current_value - baseline_value
        
        final_output.append((stats_df, delta_df))
    return final_output

def calc_ratio_pdf(numerator, denominator, scale_factor=1, metric_name='Ratio', threshold=0.01):
    """
    Calculate ratio and its confidence interval using probability density function (PDF) and t-distribution.
    
    Args:
        numerator: Numerator values for ratio calculation
        denominator: Denominator values for ratio calculation
        scale_factor: Scaling factor for the ratio
        metric_name: Name of the calculated metric
        threshold: Minimum threshold for denominator values
    
    Returns:
        Dictionary containing ratio statistics, if calculation fails returns None
    """
    mean_numerator, mean_denominator = np.mean(numerator), np.mean(denominator)
    
    # Handle cases where denominator is close to zero or zero
    if abs(mean_denominator) < threshold and mean_denominator != 0:
        pass  # Ratio might be unstable
    elif mean_denominator == 0:
        return None
        
    calculated_ratio = (mean_numerator * scale_factor) / mean_denominator
    
    # Convert to numpy arrays
    numerator_array, denominator_array = np.array(numerator), np.array(denominator)
    
    # Use kernel density estimation (KDE) to calculate PDF
    from scipy import stats
    
    # Calculate statistical variations
    statistical_variations = []
    for _ in range(100):
        num_indices = np.random.choice(len(numerator_array), len(numerator_array), replace=True)
        num_numerator, num_denominator = np.mean(numerator_array[num_indices]), np.mean(denominator_array[num_indices])
        
        if abs(num_denominator) >= threshold:
            variation_ratio = (num_numerator * scale_factor) / num_denominator
            statistical_variations.append(variation_ratio)
    
    if not statistical_variations:
        return None
        
    # Use KDE to estimate PDF
    kde = stats.gaussian_kde(statistical_variations)
    
    # Calculate confidence intervals
    statistical_variations = np.array(statistical_variations)
    mean_ratio = np.mean(statistical_variations)
    se_ratio = sem(statistical_variations)
    
    if len(statistical_variations) > 1:
        t_crit = t.ppf((1 + 0.95) / 2, len(statistical_variations) - 1)
    else:
        t_crit = t.ppf((1 + 0.95) / 2, 1)
    
    ci_lower = mean_ratio - t_crit * se_ratio
    ci_upper = mean_ratio + t_crit * se_ratio
    
    # Calculate x-axis range for PDF plotting
    x_range = np.linspace(min(statistical_variations), max(statistical_variations), 1000)
    
    return {
        'Variable': metric_name,
        'Mean': calculated_ratio,
        '95% CI Lower': ci_lower,
        '95% CI Upper': ci_upper,
        'PDF': kde,
        'x_range': x_range,
        'statistical_data': {'ratio': statistical_variations}
    }

# -----------------------------------------------------------------------------
# RESULT SUMMARIZATION AND ANALYSIS FUNCTIONS
# -----------------------------------------------------------------------------
def Summarize_results(results, start_year, end_year, Var_calcu_formula, Var_calcu_formula_differ=None, Var_for_save=None, calculate_difference=True):
    """
    Calculate statistics for scenarios, optionally calculate difference statistics and format output.
    
    Args:
        results: List of results for 6 scenarios
        start_year: Start year for calculations
        end_year: End year for calculations
        Var_calcu_formula: Dictionary of formulas for calculating variables
        Var_calcu_formula_differ: Dictionary of formulas for calculating difference variables (optional)
        Var_for_save: Dictionary for formatting output variables (optional)
        calculate_difference: Whether to calculate difference statistics (default: True)
        
    Returns:
        If calculate_difference is True:
        - Original statistics DataFrame
        - Difference statistics DataFrame
        - Formatted output DataFrame
        If calculate_difference is False:
        - Original statistics DataFrame
        - None
        - Formatted output DataFrame
    """
    year_range = [str(year) for year in range(start_year, end_year + 1)]
    
    def calculate_scenario_stats(scenario_data, components, discount_rate):
        """
        Calculate statistics for a single scenario.
        
        Args:
            scenario_data: Data for the scenario
            components: Components to calculate
            discount_rate: Discount rate for calculations
            
        Returns:
            Dictionary of calculated statistics
        """
        param_set_totals = []
        for param_set in scenario_data:
            total_value = sum(
                sum(param_set.loc[component, year] * coef / ((1 + discount_rate) ** (int(year) - start_year + 1))
                    for component, coef in components
                    if component in param_set.index)
                for year in year_range
            )
            param_set_totals.append(total_value)
        
        if param_set_totals:
            mean_value = np.mean(param_set_totals)
            se_value = sem(param_set_totals)
            if len(param_set_totals) > 1:
                 t_crit = t.ppf((1 + 0.95) / 2, len(param_set_totals) - 1)
            else:
                 t_crit = t.ppf((1 + 0.95) / 2, 1)
            return mean_value, mean_value - t_crit * se_value, mean_value + t_crit * se_value
        return None, None, None

    all_results = []
    for idx, scenario_data in enumerate(results):
        for target_variable, (components, discount_rate) in Var_calcu_formula.items():
            mean_value, ci_lower, ci_upper = calculate_scenario_stats(scenario_data, components, discount_rate)
            if mean_value is not None:
                all_results.append({
                    'Scenario': scenario_names[idx],
                    'Variable': target_variable,
                    'Mean': mean_value,
                    '95% CI Lower': ci_lower,
                    '95% CI Upper': ci_upper
                })

    df_unstacked = (pd.DataFrame(all_results)
                    .set_index(['Scenario', 'Variable'])
                    .unstack(level='Variable')
                    .swaplevel(axis=1)
                    .sort_index(axis=1))
    
    df_unstacked.columns.set_names(['Variable', 'Statistics'], inplace=True)
    
    df_unstacked = (df_unstacked
                    .reindex(['Mean', '95% CI Lower', '95% CI Upper'], axis=1, level='Statistics')
                    .reindex(list(Var_calcu_formula.keys()), axis=1, level='Variable')
                    .reindex(scenario_names, axis=0, level='Scenario')
                    .round(0))

    if not calculate_difference:
        if Var_for_save:
            formatted_df = pd.DataFrame(index=df_unstacked.index)
            for variable, (save, precision) in Var_for_save.items():
                if save:
                    def custom_formatter(value, precision_val):
                        if pd.isna(value):
                            return "NA"
                        if precision_val == 0:
                            return f"{int(round(value)):,}"
                        else:
                            return f"{round(value, precision_val):,}"
            
                    formatted_df[variable] = df_unstacked.apply(
                        lambda row: f"{custom_formatter(row[(variable, 'Mean')], precision)} "
                                    f"({custom_formatter(row[(variable, '95% CI Lower')], precision)} to "
                                    f"{custom_formatter(row[(variable, '95% CI Upper')], precision)})",
                        axis=1
                    )
            return df_unstacked, formatted_df
        return df_unstacked

    def calculate_value(param_set, components, discount_rate):
        """
        Calculate value for a parameter set.
        
        Args:
            param_set: Parameter set to calculate
            components: Components to include
            discount_rate: Discount rate for calculations
            
        Returns:
            Calculated value
        """
        return sum(
            sum(param_set.loc[component, year] * coef / ((1 + discount_rate) ** (int(year) - start_year + 1))
                for component, coef in components
                if component in param_set.index)
            for year in year_range
        )
    
    def calculate_stats_for_diff(values):
        """
        Calculate statistics for differences.
        
        Args:
            values: Values to calculate statistics for
            
        Returns:
            Dictionary of difference statistics
        """
        if not values:
            return None, None, None
        mean_value = np.mean(values)
        se_value = sem(values)
        if len(values) > 1:
            t_crit = t.ppf((1 + 0.95) / 2, len(values) - 1)
        return mean_value, mean_value - t_crit * se_value, mean_value + t_crit * se_value
    
    base_case_results = {
        var: [calculate_value(param_set, components, rate) 
              for param_set in results[0]]
        for var, (components, rate) in Var_calcu_formula_differ.items()
    }
    
    all_results_diff = []
    scenario_resampling_data = {}
    
    for idx in range(1, len(results)):
        scenario_data = results[idx]
        current_scenario_pool_data = {key: [] for key in [
            'cost_differences', 'qaly_differences', 'sti_reductions',
            'prescriptions', 'doxy_costs', 'direct_cost_changes'
        ]}
        
        for target_variable, (components, discount_rate) in Var_calcu_formula_differ.items():
            differences = [
                calculate_value(param_set, components, discount_rate) - base_case_results[target_variable][i]
                for i, param_set in enumerate(scenario_data)
                if i < len(base_case_results[target_variable])
            ]
            
            if differences:
                mean_value, ci_lower, ci_upper = calculate_stats_for_diff(differences)
                if mean_value is not None:
                    all_results_diff.append({
                        'Scenario': scenario_names[idx],
                        'Variable': target_variable,
                        'Mean': mean_value,
                        '95% CI Lower': ci_lower,
                        '95% CI Upper': ci_upper
                    })
                    
                    key_map = {
                        'Change in total cost (A$ ,000)': 'cost_differences',
                        'QALYs gained': 'qaly_differences',
                        'Reduction in new STIs': 'sti_reductions',
                        'Doxy-PEP prescriptions': 'prescriptions',
                        'Cost of doxy-PEP (A$ ,000)': 'doxy_costs',
                        'Change in direct cost (A$ ,000)': 'direct_cost_changes'
                    }
                    num_key = key_map.get(target_variable)
                    if num_key:
                        current_scenario_pool_data[num_key] = differences
        
        ratio_calculations = [
            ('cost_differences', 'qaly_differences', 'ICER (A$ per QALYs gained)', False, 1000),
            ('sti_reductions', 'prescriptions', 'New IA per Doxy-PEP prescription', False, 1),
            ('doxy_costs', 'sti_reductions', 'Cost per new IA (A$)', False, 1000),
            ('direct_cost_changes', 'doxy_costs', 'Benefit-cost ratio', True, 1) 
        ]
        
        for num_key, den_key, name, negate, multiplier in ratio_calculations:
            if current_scenario_pool_data.get(num_key) and current_scenario_pool_data.get(den_key):
                num_values = [-x for x in current_scenario_pool_data[num_key]] if negate else current_scenario_pool_data[num_key]
                num_values = [x * multiplier for x in num_values]
                
                # Ensure denominator is not empty and contains non-zero values before calling calc_ratio
                if not current_scenario_pool_data[den_key] or all(d == 0 for d in current_scenario_pool_data[den_key]):
                    ratio_result = None
                else:
                    ratio_result = calc_ratio_pdf(num_values, current_scenario_pool_data[den_key], metric_name=name)

                if ratio_result:
                    draws_data = ratio_result.pop('statistical_data')
                    current_scenario_pool_data[f'{name.lower().replace(" ", "_")}_statistical_data'] = draws_data
                    all_results_diff.append({
                        'Scenario': scenario_names[idx],
                        **ratio_result
                    })
        
        scenario_resampling_data[scenario_names[idx]] = current_scenario_pool_data
    
    df_unstacked_diff = (pd.DataFrame(all_results_diff)
                         .set_index(['Scenario', 'Variable'])
                         .unstack(level='Variable')
                         .swaplevel(axis=1)
                         .sort_index(axis=1))
    
    if not df_unstacked_diff.empty:
        df_unstacked_diff.columns.set_names(['Variable', 'Statistics'], inplace=True)
    
        variables_for_diff_reindex = list(Var_calcu_formula_differ.keys()) + [
            'ICER (A$ per QALYs gained)', 'New IA per Doxy-PEP prescription',
            'Cost per new IA (A$)', 'Benefit-cost ratio'
        ]

        df_unstacked_diff = (df_unstacked_diff
                            .reindex(['Mean', '95% CI Lower', '95% CI Upper'], axis=1, level='Statistics')
                            .reindex(variables_for_diff_reindex, axis=1, level='Variable')
                            .reindex(scenario_names[1:], axis=0, level='Scenario'))
    else: # Handle case where df_unstacked_diff might be empty
        # Create an empty DataFrame with expected structure if needed, or handle downstream
        pass


    if Var_for_save:
        formatted_df = pd.DataFrame(index=df_unstacked_diff.index if not df_unstacked_diff.empty else scenario_names[1:]) # Adjust index if diff is empty
        
        base_case_row_data = {col: '-' for col_group in Var_for_save.keys() for col in [col_group]} # Initialize with '-'
        
        additional_vars_from_original = {
            'Direct medical cost (A$ ,000)': (True, 0),
            'Cost of doxy-PEP (A$ ,000)': (True, 0),
            'QALYs lost due to STI': (True, 0)
        }
        for var_name in additional_vars_from_original:
            base_case_row_data[var_name] = '-' # Ensure these columns exist for base case

        formatted_df = pd.concat([pd.DataFrame(base_case_row_data, index=['Base case (No doxy-PEP)']), formatted_df])
        
        def custom_formatter(value, precision_val):
            if pd.isna(value) or value == '-':
                return "NA" if pd.isna(value) else "-"
            if precision_val == 0:
                return f"{int(round(value)):,}"
            else:
                return f"{round(value, precision_val):,}"
        
        for variable, (save, precision) in additional_vars_from_original.items():
            if save and variable in df_unstacked.columns.levels[0]:
                base_case_value = df_unstacked.loc['Base case (No doxy-PEP)', variable]
                formatted_df.loc['Base case (No doxy-PEP)', variable] = (
                    f"{custom_formatter(base_case_value['Mean'], precision)} "
                    f"({custom_formatter(base_case_value['95% CI Lower'], precision)} to "
                    f"{custom_formatter(base_case_value['95% CI Upper'], precision)})"
                )
                for scenario_name_idx in df_unstacked_diff.index if not df_unstacked_diff.empty else []:
                    if scenario_name_idx in df_unstacked.index: # Check if scenario exists in original stats
                        scenario_value = df_unstacked.loc[scenario_name_idx, variable]
                        formatted_df.loc[scenario_name_idx, variable] = (
                            f"{custom_formatter(scenario_value['Mean'], precision)} "
                            f"({custom_formatter(scenario_value['95% CI Lower'], precision)} to "
                            f"{custom_formatter(scenario_value['95% CI Upper'], precision)})"
                        )
        
        for variable, (save, precision) in Var_for_save.items():
            if save:
                if not df_unstacked_diff.empty and variable in df_unstacked_diff.columns.levels[0]:
                    # Apply formatting for non-base case rows
                    for scenario_idx in df_unstacked_diff.index:
                        row_data = df_unstacked_diff.loc[scenario_idx]
                        formatted_df.loc[scenario_idx, variable] = (
                            f"{custom_formatter(row_data[(variable, 'Mean')], precision)} "
                            f"({custom_formatter(row_data[(variable, '95% CI Lower')], precision)} to "
                            f"{custom_formatter(row_data[(variable, '95% CI Upper')], precision)})"
                        )
                else: # If variable not in diff table or diff table is empty, fill with '-' for non-base cases
                     for scenario_idx in formatted_df.index:
                        if scenario_idx != 'Base case (No doxy-PEP)':
                            if variable not in formatted_df.columns:
                                formatted_df[variable] = '-'
                            else:
                                formatted_df.loc[scenario_idx, variable] = '-'
        
        column_order = [
            'Direct medical cost (A$ ,000)',
            'QALYs lost due to STI',
            'Cost of doxy-PEP (A$ ,000)',
            'ICER (A$ per QALYs gained)',
            'New IA per Doxy-PEP prescription',
            'Cost per new IA (A$)',
            'Benefit-cost ratio'
        ]
        
        # Ensure all columns exist before reordering, add if missing and fill with '-'
        for col in column_order:
            if col not in formatted_df.columns:
                formatted_df[col] = '-'
        formatted_df = formatted_df[column_order]
        
        return df_unstacked, df_unstacked_diff, formatted_df
    
    return df_unstacked, df_unstacked_diff

def rank_scenarios_and_transpose(table_mean_CI_differ, plot_marker=False):
    """
    Input: table_mean_CI_differ
    Output: ranking table (rows: scenarios, columns: variables and combined ranks), transposed ranking table (rows: Rank 1~5, columns: all variables, content: scenario names)
    """
    # Ensure table_mean_CI_differ is not empty and has the expected structure
    if table_mean_CI_differ is None or table_mean_CI_differ.empty:
        # Return empty DataFrames or handle as appropriate
        empty_rank_df = pd.DataFrame()
        empty_result_df = pd.DataFrame()
        if plot_marker:
            # print("Skipping marker plot due to empty input table.")
            pass
        return empty_rank_df, empty_result_df
        
    base_vars = [
        'Reduction in new STIs',
        'Reduction in new Syphilis',
        'Increased new NG infections with HL TetR',
        'Benefit-cost ratio'
    ]
    base_var_rename = {
        'Reduction in new STIs': 'STI Reduc.',
        'Reduction in new Syphilis': 'Syphilis Reduc.',
        'Increased new NG infections with HL TetR': 'HL TetR',
        'Benefit-cost ratio': 'BCR'
    }
    
    # Filter for existing base_vars and 'Mean' statistic
    existing_base_vars = [var for var in base_vars if (var, 'Mean') in table_mean_CI_differ.columns]
    if not existing_base_vars:
        return pd.DataFrame(), pd.DataFrame()

    df = table_mean_CI_differ.loc[:, pd.IndexSlice[existing_base_vars, 'Mean']]
    df.columns = df.columns.droplevel(1) # Drop 'Mean' level for easier access

    rank_df = pd.DataFrame(index=df.index)
    
    if 'Reduction in new STIs' in df.columns:
        rank_df['STI Reduc.'] = df['Reduction in new STIs'].rank(ascending=False, method='min')
    if 'Reduction in new Syphilis' in df.columns:
        rank_df['Syphilis Reduc.'] = df['Reduction in new Syphilis'].rank(ascending=False, method='min')
    if 'Benefit-cost ratio' in df.columns:
        rank_df['BCR'] = df['Benefit-cost ratio'].rank(ascending=False, method='min')
    if 'Increased new NG infections with HL TetR' in df.columns:
        rank_df['HL TetR'] = df['Increased new NG infections with HL TetR'].rank(ascending=True, method='min')

    combs_def = [
        ('STI Reduc.', 'HL TetR'),
        ('Syphilis Reduc.', 'HL TetR'),
        ('STI Reduc.', 'BCR'),
        ('Syphilis Reduc.', 'BCR'),
        ('HL TetR', 'BCR'),
        ('STI Reduc.', 'HL TetR', 'BCR'),
        ('Syphilis Reduc.', 'HL TetR', 'BCR')
    ]
    
    # Filter combinations based on available ranked columns in rank_df
    combs = []
    for comb_tuple in combs_def:
        if all(c in rank_df.columns for c in comb_tuple):
            combs.append(comb_tuple)

    for comb in combs:
        colname = comb[0] + ''.join(['\n& ' + c for c in comb[1:]])
        rank_df[colname] = rank_df[list(comb)].sum(axis=1)
    
    # Define all_vars based on successfully created columns in rank_df
    all_vars = [base_var_rename[var] for var in existing_base_vars if var in base_var_rename and base_var_rename[var] in rank_df.columns]
    all_vars += [comb[0] + ''.join(['\n& ' + c for c in comb[1:]]) for comb in combs]
    
    if not all_vars: # If no variables to rank by
        return rank_df, pd.DataFrame()

    result = pd.DataFrame(index=[f'Rank {i}' for i in range(1, 6)], columns=all_vars)
    for var in all_vars:
        if var in rank_df.columns:
             sorted_scenarios = rank_df[var].sort_values(ascending=True).index.tolist()
             for i in range(min(5, len(sorted_scenarios))): # Ensure we don't go out of bounds
                result.loc[f'Rank {i+1}', var] = sorted_scenarios[i]
    
    # Add 'Best Rank Value' row if rank_df is not empty and var exists
    best_rank_values = {}
    for var in all_vars:
        if var in rank_df.columns and not rank_df[var].empty:
            best_rank_values[var] = int(rank_df[var].min())
        else:
            best_rank_values[var] = np.nan # Or some other placeholder if the column wasn't ranked
    result.loc['Best Rank Value', :] = pd.Series(best_rank_values)


    if plot_marker:
        scenario_plot_names = [
            'One syphilis diagnosis',
            'Two STI diagnoses in 6m',
            'Two STI diagnoses in 12m',
            'HIV positive attendees',
            'PrEP-using attendees'
        ]
        marker_styles_plot = ['^', 's', 'D', 'p', 'h']
        colors_plot = ['#229FDB', '#CC522A', '#8A2C84', '#E4AE16', '#42A946']
        scenario_marker = {name: (marker, color) for name, marker, color in zip(scenario_plot_names, marker_styles_plot, colors_plot)}

        x_labels = all_vars
        y_labels = [f'Rank {i}' for i in range(1, 6)]
        fig, ax = plt.subplots(figsize=(len(x_labels)*1.2, 4.5))

        for i in range(len(y_labels)):
            for j in range(len(x_labels)):
                ax.add_patch(plt.Rectangle((j-0.5, i-0.5), 1, 1, color='#f2f2f2', zorder=0, linewidth=0))

        for i, y_val in enumerate(y_labels):
            for j, x_val in enumerate(x_labels):
                if x_val in result.columns and y_val in result.index:
                    scenario = result.loc[y_val, x_val]
                    if pd.notna(scenario) and scenario in scenario_marker:
                        marker, color = scenario_marker[scenario]
                        ax.scatter(j, i, marker=marker, color=color, s=200, linewidths=1.2, zorder=2)
                    else:
                        ax.text(j, i, '', ha='center', va='center')
                else: # If column/row doesn't exist
                    ax.text(j, i, '', ha='center', va='center')


        ax.set_xticks(range(len(x_labels)))
        ax.set_xticklabels(x_labels, rotation=0, ha='center', fontsize=10)
        ax.set_yticks(range(len(y_labels)))
        
        yticklabels_plot = []
        for label_item in y_labels:
            if label_item == 'Rank 1':
                yticklabels_plot.append(r'$\bf{' + label_item + '}$')
            else:
                yticklabels_plot.append(label_item)
        ax.set_yticklabels(yticklabels_plot, fontsize=11)
        ax.set_xlim(-0.5, len(x_labels)-0.5)
        ax.set_ylim(-0.5, len(y_labels)-0.5)
        ax.invert_yaxis()

        ax.set_axisbelow(True)
        ax.grid(which='major', color='gray', linestyle='-', linewidth=0.7, alpha=0.3)

        for spine in ax.spines.values():
            spine.set_visible(False)

        handles_legend = []
        for name, (marker, color) in scenario_marker.items():
            handles_legend.append(plt.Line2D([], [], marker=marker, color='w', markerfacecolor=color, markeredgecolor='none', markersize=12, label=name, linewidth=0))
        ax.legend(handles=handles_legend, loc='upper center', bbox_to_anchor=(0.5, -0.18), ncol=5, frameon=False, fontsize=10)

        plt.tight_layout()
        plt.show()

    return rank_df, result, fig

# -----------------------------------------------------------------------------
# PLOTTING FUNCTIONS
# -----------------------------------------------------------------------------
def plot_combined_STI_incidence(results, start_year=2024, end_year=2034, bar_start_year=2025, bar_end_year=2034):
    """
    Plot STI incidence trends and cumulative incidence.
    
    Args:
        results: List of results for 6 scenarios, each containing 100 parameter sets
        start_year: Start year for line plot
        end_year: End year for line plot
        bar_start_year: Start year for bar plot
        bar_end_year: End year for bar plot
    """
    fontsize_title = 30
    fontsize_label = 24
    fontsize_ticks = 20
    fontsize_legend = 18

    variable_names_sti = ['NG_Inci_Overall', 'CT_Inci_Overall', 'TP_Inci_Overall']
    BAR_WIDTH = 0.2
    BAR_SPACING = 0.05

    def plot_STIs_incidence_trend(axs_list):
        titles_list = ['Gonorrhoea', 'Chlamydia', 'Syphilis', 'All three STIs',
                       'Doxy-PEP Prescriptions', 'Doxy-PEP Coverage']
        horizontal_lines_list = [1.44, 8.15, 0.51] 

        marker_styles_list = ['o', '^', 's', 'D', 'p', 'h']
        colors_list = ['#000000', '#229FDB', '#CC522A', '#8A2C84', '#E4AE16', '#42A946']
        years_list = list(range(start_year, end_year + 1))

        for idx, ax_item in enumerate(axs_list):
            if idx < len(variable_names_sti):
                variable_plot = variable_names_sti[idx]
                for scenario_index, scenario_item in enumerate(results):
                    mean_values_plot = calculate_means_for_scenario(scenario_item, variable_plot, years_list)
                    mean_values_plot = [x * 100 for x in mean_values_plot] 

                    ax_item.plot(years_list, mean_values_plot, marker=marker_styles_list[scenario_index], linestyle='-',
                                 color=colors_list[scenario_index], label=scenario_names[scenario_index],
                                 markersize=8, linewidth=2.5, markeredgewidth=1.5)
                if idx < 3:
                    ax_item.axhline(y=horizontal_lines_list[idx], color='red', linestyle='--', linewidth=3)
                    ax_item.set_ylim([0, ax_item.get_ylim()[1]])
                    if idx == 0:  # Only add black horizontal dashed line in Panel A
                        ax_item.axhline(y=14.4, color='black', linestyle='--', linewidth=3)
                ax_item.set_ylabel('Incidence (per 100 PY)', fontsize=fontsize_label)

            elif idx == 3:
                for scenario_index, scenario_item in enumerate(results):
                    mean_values_plot = calculate_means_for_scenario(scenario_item, 'STI_Inci_Overall', years_list)
                    mean_values_plot = [x * 100 for x in mean_values_plot]
                    ax_item.plot(years_list, mean_values_plot, marker=marker_styles_list[scenario_index], linestyle='-',
                                 color=colors_list[scenario_index], label=scenario_names[scenario_index],
                                 markersize=8, linewidth=2.5, markeredgewidth=1.5)
                ax_item.set_ylabel('Incidence (per 100 PY)', fontsize=fontsize_label)

            elif idx == 4:
                for scenario_index, scenario_item in enumerate(results):
                    mean_values_plot = calculate_means_for_scenario(scenario_item, 'Doxy_PEP_enter', years_list)
                    mean_values_plot = [x/1000 for x in mean_values_plot]
                    ax_item.plot(years_list, mean_values_plot, marker=marker_styles_list[scenario_index], linestyle='-',
                                 color=colors_list[scenario_index], label=scenario_names[scenario_index],
                                 markersize=8, linewidth=2.5, markeredgewidth=1.5)
                ax_item.set_ylabel('Prescriptions (thousands)', fontsize=fontsize_label)

            elif idx == 5:
                for scenario_index, scenario_item in enumerate(results):
                    mean_values_plot = calculate_means_for_scenario(scenario_item, 'Doxy_PEP_coverage', years_list)
                    mean_values_plot = [x * 100 for x in mean_values_plot]
                    ax_item.plot(years_list, mean_values_plot, marker=marker_styles_list[scenario_index], linestyle='-',
                                 color=colors_list[scenario_index], label=scenario_names[scenario_index],
                                 markersize=8, linewidth=2.5, markeredgewidth=1.5)
                ax_item.set_ylabel('Coverage (%)', fontsize=fontsize_label)

            ax_item.set_title(titles_list[idx], fontsize=fontsize_title, pad=15, x=0.5)
            ax_item.set_xlabel('Year', fontsize=fontsize_label)
            ax_item.set_xticks(np.arange(start_year, end_year + 1, 2))
            ax_item.tick_params(axis='both', labelsize=fontsize_ticks)
            ax_item.grid(True, alpha=0.3)
            ax_item.spines['top'].set_visible(False)
            ax_item.spines['right'].set_visible(False)

        line_handles_list = [
            mlines.Line2D([], [], color=colors_list[i], marker=marker_styles_list[i], linestyle='-',
                          markersize=8, markeredgewidth=1.5, label=scenario_names[i])
            for i in range(len(scenario_names))
        ]
        return line_handles_list

    def plot_cumulative_bar(ax_bar):
        title_bar = f'Cumulative incident STIs and doxy-PEP prescriptions ({bar_start_year}-{bar_end_year})'
        years_bar = list(range(bar_start_year, bar_end_year + 1))
        
        ng_total_list = []
        ct_total_list = []
        tp_total_list = []
        sti_total_list = [] 
        sti_total_ci_list = [] 
        prescriptions_list = []
        prescription_ci_list = []

        for i, scenario_item in enumerate(results):
            ng_values_bar = calculate_means_for_scenario(scenario_item, 'NG_new_infections', years_bar)
            ct_values_bar = calculate_means_for_scenario(scenario_item, 'CT_new_infections', years_bar)
            tp_values_bar = calculate_means_for_scenario(scenario_item, 'TP_new_infections', years_bar)

            ng_total_list.append(sum(ng_values_bar) / 1000)
            ct_total_list.append(sum(ct_values_bar) / 1000)
            tp_total_list.append(sum(tp_values_bar) / 1000)

            total_sti_values_iter = []
            for param_set_item in scenario_item:
                ng_current_iter = sum(param_set_item.loc['NG_new_infections', str(year_iter)] for year_iter in years_bar)
                ct_current_iter = sum(param_set_item.loc['CT_new_infections', str(year_iter)] for year_iter in years_bar)
                tp_current_iter = sum(param_set_item.loc['TP_new_infections', str(year_iter)] for year_iter in years_bar)
                total_sti_iter = (ng_current_iter + ct_current_iter + tp_current_iter) / 1000
                total_sti_values_iter.append(total_sti_iter)
            
            total_sti_values_np = np.array(total_sti_values_iter)
            mean_total_sti_val = np.nanmean(total_sti_values_np)
            se_total_sti_val = sem(total_sti_values_np, nan_policy='omit')
            if len(total_sti_values_np) >1:
                ci_total_sti_val = se_total_sti_val * t.ppf((1 + 0.95) / 2., len(total_sti_values_np) - 1)
            else:
                ci_total_sti_val = 0
            sti_total_list.append(mean_total_sti_val)
            sti_total_ci_list.append(ci_total_sti_val)

            prescription_values_iter = []
            for param_set_item in scenario_item:
                total_presc = sum(param_set_item.loc['Doxy_PEP_enter', str(year_iter)] for year_iter in years_bar) / 1000
                prescription_values_iter.append(total_presc)
            
            prescription_values_np = np.array(prescription_values_iter)
            mean_prescriptions_val = np.nanmean(prescription_values_np)
            se_prescriptions_val = sem(prescription_values_np, nan_policy='omit')
            if len(prescription_values_np) > 1:
                ci_prescriptions_val = se_prescriptions_val * t.ppf((1 + 0.95) / 2., len(prescription_values_np) - 1)
            else:
                ci_prescriptions_val = 0
            prescriptions_list.append(mean_prescriptions_val)
            prescription_ci_list.append(ci_prescriptions_val)

        index_bar = np.arange(len(results))
        ax2_bar = ax_bar.twinx()

        bottom_bar = np.zeros(len(results))
        ax_bar.bar(index_bar - BAR_WIDTH/2 - BAR_SPACING/2, tp_total_list, width=BAR_WIDTH,
                   label='Syphilis', color='#F25F5C', alpha=0.8, bottom=bottom_bar)
        bottom_bar += np.array(tp_total_list)
        ax_bar.bar(index_bar - BAR_WIDTH/2 - BAR_SPACING/2, ct_total_list, width=BAR_WIDTH,
                   label='Chlamydia', color='#247BA0', alpha=0.8, bottom=bottom_bar)
        bottom_bar += np.array(ct_total_list)
        ax_bar.bar(index_bar - BAR_WIDTH/2 - BAR_SPACING/2, ng_total_list, width=BAR_WIDTH,
                   label='Gonorrhoea', color='#FFE066', alpha=0.8, bottom=bottom_bar)

        ax_bar.errorbar(index_bar - BAR_WIDTH/2 - BAR_SPACING/2, sti_total_list, yerr=sti_total_ci_list,
                        fmt='none', color='black', capsize=5)

        ax2_bar.bar(index_bar + BAR_WIDTH/2 + BAR_SPACING/2, prescriptions_list, width=BAR_WIDTH,
                    label='Prescriptions', color='#70C1B3', alpha=0.8)
        ax2_bar.errorbar(index_bar + BAR_WIDTH/2 + BAR_SPACING/2, prescriptions_list, yerr=prescription_ci_list,
                         fmt='none', color='black', capsize=5)

        ax_bar.set_xticks([])
        ax_bar.set_ylabel('Total STIs (,000)', fontsize=fontsize_label-2)
        ax2_bar.set_ylabel('Prescriptions (,000)', fontsize=fontsize_label-2)
        ax_bar.set_title(title_bar, fontsize=fontsize_title-4, pad=20)

        ax_bar.tick_params(axis='both', labelsize=fontsize_ticks-2)
        ax2_bar.tick_params(axis='y', labelsize=fontsize_ticks-2)
        ax_bar.spines['left'].set_color('black')
        ax2_bar.spines['right'].set_color('black')

        lines1_bar, labels1_bar = ax_bar.get_legend_handles_labels()
        lines2_bar, labels2_bar = ax2_bar.get_legend_handles_labels()
        ax_bar.legend(lines1_bar + lines2_bar, labels1_bar + labels2_bar,
                      loc='upper left', bbox_to_anchor=(0.0, 1.25),
                      fontsize=fontsize_legend, frameon=False, framealpha=0.9,
                      ncol=2, columnspacing=0.5)

        ax_bar.grid(True, alpha=0.3)
        ax_bar.spines['top'].set_visible(False)
        ax2_bar.spines['top'].set_visible(False)

    def plot_effectiveness_bar(ax_eff):
        title_eff = f'Total and per-prescription infections averted (IA) ({bar_start_year}-{bar_end_year})'
        years_eff = list(range(bar_start_year, bar_end_year + 1))
        baseline_scenario_eff = results[0]

        ng_reduced_list = []
        ct_reduced_list = []
        tp_reduced_list = []
        total_sti_reduced_list = []
        total_sti_reduced_ci_list = []
        total_per_rx_list = []
        per_rx_ci_list = []

        ng_baseline_eff = sum(calculate_means_for_scenario(baseline_scenario_eff, 'NG_new_infections', years_eff))
        ct_baseline_eff = sum(calculate_means_for_scenario(baseline_scenario_eff, 'CT_new_infections', years_eff))
        tp_baseline_eff = sum(calculate_means_for_scenario(baseline_scenario_eff, 'TP_new_infections', years_eff))

        for i, scenario_item in enumerate(results):
            if i == 0: 
                ng_reduced_list.append(0)
                ct_reduced_list.append(0)
                tp_reduced_list.append(0)
                total_sti_reduced_list.append(0)
                total_sti_reduced_ci_list.append(0)
                total_per_rx_list.append(0)
                per_rx_ci_list.append(0)
            else:
                sti_reduced_values_iter = []
                
                total_sti_reduced_all_iter = []
                total_prescriptions_all_iter = []

                for param_set_item in scenario_item:
                    ng_current_iter = sum(param_set_item.loc['NG_new_infections', str(year_iter)] for year_iter in years_eff)
                    ct_current_iter = sum(param_set_item.loc['CT_new_infections', str(year_iter)] for year_iter in years_eff)
                    tp_current_iter = sum(param_set_item.loc['TP_new_infections', str(year_iter)] for year_iter in years_eff)

                    ng_avoided_iter = ng_baseline_eff - ng_current_iter
                    ct_avoided_iter = ct_baseline_eff - ct_current_iter
                    tp_avoided_iter = tp_baseline_eff - tp_current_iter
                    
                    total_sti_avoided_iter = ng_avoided_iter + ct_avoided_iter + tp_avoided_iter
                    sti_reduced_values_iter.append(total_sti_avoided_iter)
                    total_sti_reduced_all_iter.append(total_sti_avoided_iter)
                    
                    prescriptions_iter = sum(param_set_item.loc['Doxy_PEP_enter', str(year_iter)] for year_iter in years_eff)
                    total_prescriptions_all_iter.append(prescriptions_iter)
                
                sti_reduced_values_np = np.array(sti_reduced_values_iter)
                mean_sti_reduced_val = np.nanmean(sti_reduced_values_np) / 1000 
                se_sti_reduced_val = sem(sti_reduced_values_np, nan_policy='omit') / 1000
                if len(sti_reduced_values_np) > 1:
                    ci_sti_reduced_val = se_sti_reduced_val * t.ppf((1 + 0.95) / 2., len(sti_reduced_values_np) - 1)
                else:
                    ci_sti_reduced_val = 0
                total_sti_reduced_list.append(mean_sti_reduced_val)
                total_sti_reduced_ci_list.append(ci_sti_reduced_val)

                if i == 0:
                    mean_per_rx_val = 0
                    ci_per_rx_val = 0
                else:
                    # Using calc_ratio for ratio and its CI
                    if not total_prescriptions_all_iter or all(p == 0 for p in total_prescriptions_all_iter):
                        mean_per_rx_val = np.nan # Or some other indicator of failure
                        ci_per_rx_val = np.nan
                    else:
                        ratio_result_eff = calc_ratio_pdf(
                            numerator=total_sti_reduced_all_iter, denominator=total_prescriptions_all_iter,
                            scale_factor=1, metric_name='IA per prescription'
                        )
                        if ratio_result_eff:
                            mean_per_rx_val = ratio_result_eff['Mean']
                            ci_per_rx_val = (ratio_result_eff['95% CI Upper'] - ratio_result_eff['95% CI Lower']) / 2
                        else:
                            mean_per_rx_val = 0 # Or np.nan
                            ci_per_rx_val = 0   # Or np.nan
                total_per_rx_list.append(mean_per_rx_val)
                per_rx_ci_list.append(ci_per_rx_val)
                
                ng_reduced_list.append((ng_baseline_eff - sum(calculate_means_for_scenario(scenario_item, 'NG_new_infections', years_eff))) / 1000)
                ct_reduced_list.append((ct_baseline_eff - sum(calculate_means_for_scenario(scenario_item, 'CT_new_infections', years_eff))) / 1000)
                tp_reduced_list.append((tp_baseline_eff - sum(calculate_means_for_scenario(scenario_item, 'TP_new_infections', years_eff))) / 1000)

        index_eff = np.arange(len(results))
        ax2_eff = ax_eff.twinx()

        bottom_eff = np.zeros(len(results))
        ax_eff.bar(index_eff - BAR_WIDTH/2 - BAR_SPACING/2, tp_reduced_list, width=BAR_WIDTH,
                   label='Syphilis', color='#F25F5C', alpha=0.8, bottom=bottom_eff)
        bottom_eff += np.array(tp_reduced_list)
        ax_eff.bar(index_eff - BAR_WIDTH/2 - BAR_SPACING/2, ct_reduced_list, width=BAR_WIDTH,
                   label='Chlamydia', color='#247BA0', alpha=0.8, bottom=bottom_eff)
        bottom_eff += np.array(ct_reduced_list)
        ax_eff.bar(index_eff - BAR_WIDTH/2 - BAR_SPACING/2, ng_reduced_list, width=BAR_WIDTH,
                   label='Gonorrhoea', color='#FFE066', alpha=0.8, bottom=bottom_eff)

        ax_eff.errorbar(index_eff - BAR_WIDTH/2 - BAR_SPACING/2, total_sti_reduced_list, yerr=total_sti_reduced_ci_list,
                        fmt='none', color='black', capsize=5)

        ax2_eff.bar(index_eff + BAR_WIDTH/2 + BAR_SPACING/2, total_per_rx_list, width=BAR_WIDTH,
                    label='IA per Prescription', color='#70C1B3', alpha=0.8)
        ax2_eff.errorbar(index_eff + BAR_WIDTH/2 + BAR_SPACING/2, total_per_rx_list, yerr=per_rx_ci_list,
                         fmt='none', color='black', capsize=5)

        ax_eff.set_xticks(index_eff)
        labels_with_newlines_eff = [
            'Base case\n(No doxy-PEP)', 'One syphilis\ndiagnosis',
            'Two STI\ndiagnoses in 6m', 'Two STI\ndiagnoses in 12m',
            'HIV positive\nattendees', 'PrEP-using\nattendees'
        ]
        ax_eff.set_xticklabels(labels_with_newlines_eff)
        ax_eff.set_ylabel('Total IA (,000)', fontsize=fontsize_label-2)
        ax2_eff.set_ylabel('IA per prescription', fontsize=fontsize_label-2)
        ax_eff.set_title(title_eff, fontsize=fontsize_title-4, pad=20)

        ax_eff.tick_params(axis='both', labelsize=fontsize_ticks-2)
        ax2_eff.tick_params(axis='y', labelsize=fontsize_ticks-2)
        ax_eff.spines['left'].set_color('black')
        ax2_eff.spines['right'].set_color('black')

        lines1_eff, labels1_eff = ax_eff.get_legend_handles_labels()
        lines2_eff, labels2_eff = ax2_eff.get_legend_handles_labels()
        ax_eff.legend(lines1_eff + lines2_eff, labels1_eff + labels2_eff,
                      loc='upper left', bbox_to_anchor=(0.0, 1.25),
                      fontsize=fontsize_legend, frameon=False, framealpha=0.9,
                      ncol=2, columnspacing=0.5)

        ax_eff.grid(True, alpha=0.3)
        ax_eff.spines['top'].set_visible(False)
        ax2_eff.spines['top'].set_visible(False)

    fig_main = plt.figure(figsize=(24, 22))
    gs_main_fig = gridspec.GridSpec(4, 1, height_ratios=[6.5, 0.4, 1.6, 1.6]) 

    gs_line_graphs_fig = gridspec.GridSpecFromSubplotSpec(2, 3, subplot_spec=gs_main_fig[0],
                                                      hspace=0.3, wspace=0.3)
    gs_legend_fig = gridspec.GridSpecFromSubplotSpec(1, 1, subplot_spec=gs_main_fig[1])
    ax_legend_fig = plt.subplot(gs_legend_fig[0])
    ax_legend_fig.axis('off')

    gs_panel_g_fig = gridspec.GridSpecFromSubplotSpec(1, 1, subplot_spec=gs_main_fig[2])
    gs_panel_h_fig = gridspec.GridSpecFromSubplotSpec(1, 1, subplot_spec=gs_main_fig[3])

    axs_main = [plt.subplot(gs_line_graphs_fig[i//3, i%3]) for i in range(6)]
    line_handles_main = plot_STIs_incidence_trend(axs_main)

    ax_g_main = plt.subplot(gs_panel_g_fig[0])
    plot_cumulative_bar(ax_g_main)

    ax_h_main = plt.subplot(gs_panel_h_fig[0])
    plot_effectiveness_bar(ax_h_main)

    panel_labels_main = ['(A)', '(B)', '(C)', '(D)', '(E)', '(F)', '(G)', '(H)']
    positions_main = [(0.03, 0.98), (0.365, 0.98), (0.7, 0.98),
                      (0.03, 0.69), (0.365, 0.69), (0.7, 0.69),
                      (0.03, 0.36), (0.03, 0.18)]

    for label_main, pos_main in zip(panel_labels_main, positions_main):
        fig_main.text(pos_main[0], pos_main[1], label_main, ha='center', va='center',
                      fontsize=fontsize_title)

    fig_main.legend(line_handles_main, scenario_names,
                    loc='upper center', bbox_to_anchor=(0.5, 0.415),
                    ncol=3, fontsize=20, columnspacing=1.2,
                    handlelength=1.8, markerscale=1.3, frameon=True, handletextpad=0.5)

    plt.tight_layout()
    plt.show()
    return fig_main

def plot_NG_resistance_trends(results, start_year=2024, end_year=2034):
    """
    Plot the trend of NG resistance incidence rates.
    
    Parameters:
    -----------
    results : list
        List containing results for 6 scenarios
    start_year : int
        Start year for the analysis
    end_year : int
        End year for the analysis
    """
    fontsize_title = 30
    fontsize_label = 24
    fontsize_ticks = 20
    fontsize_legend = 18

    variable_names_ng = ['NG_new_AMS_infections', 'NG_new_Cef_infections',
                         'NG_new_Dox_infections', 'NG_new_Double_infections']
    colors_ng = ['#7f9695', '#bba59d', '#a44a76', '#9181ab']
    
    fig_ng = plt.figure(figsize=(16.5, 19))
    gs_main_ng = gridspec.GridSpec(3, 1, height_ratios=[6.5, 0.4, 2.5])
    gs_incidence_ng = gridspec.GridSpecFromSubplotSpec(2, 2, subplot_spec=gs_main_ng[0],
                                                   hspace=0.2, wspace=0.3)
    gs_legend_ng = gridspec.GridSpecFromSubplotSpec(1, 1, subplot_spec=gs_main_ng[1])
    ax_legend_ng = plt.subplot(gs_legend_ng[0])
    ax_legend_ng.axis('off')

    axs_incidence_ng = [plt.subplot(gs_incidence_ng[i//2, i%2]) for i in range(4)]
    
    titles_ng = ['Neither', 'Ceftriaxone DS only', 
                 'HL TetR only', 'Both']
    marker_styles_ng = ['o', '^', 's', 'D', 'p', 'h']
    scenario_colors_ng = ['#000000', '#229FDB', '#CC522A', '#8A2C84', '#E4AE16', '#42A946']
    years_ng = list(range(start_year, end_year + 1))

    for idx, ax_item in enumerate(axs_incidence_ng):
        variable_ng = variable_names_ng[idx]
        for scenario_index, scenario_item in enumerate(results):
            mean_values_ng = calculate_means_for_scenario(scenario_item, variable_ng, years_ng)
            total_pop_ng = calculate_means_for_scenario(scenario_item, 'Total_Population', years_ng)
            incidence_ng = [(v/p*100 if p > 0 else 0) for v, p in zip(mean_values_ng, total_pop_ng)] 

            ax_item.plot(years_ng, incidence_ng, marker=marker_styles_ng[scenario_index], linestyle='-',
                         color=scenario_colors_ng[scenario_index], label=scenario_names[scenario_index],
                         markersize=8, linewidth=2.5, markeredgewidth=1.5)

        ax_item.set_title(titles_ng[idx], fontsize=fontsize_title, pad=15, x=0.5)
        if idx >= 2:
            ax_item.set_xlabel('Year', fontsize=fontsize_label)
            ax_item.set_xticks(np.arange(start_year, end_year + 1, 2))
            ax_item.set_xticklabels(np.arange(start_year, end_year + 1, 2))
        else:
            ax_item.set_xticks(np.arange(start_year, end_year + 1, 2))
            ax_item.set_xticklabels([])
        ax_item.set_ylabel('Incidence (per 100 PY)', fontsize=fontsize_label)
        ax_item.tick_params(axis='both', labelsize=fontsize_ticks)
        ax_item.grid(True, alpha=0.3)
        ax_item.spines['top'].set_visible(False)
        ax_item.spines['right'].set_visible(False)

    line_handles_ng = [
        mlines.Line2D([], [], color=scenario_colors_ng[i], marker=marker_styles_ng[i], linestyle='-',
                      markersize=8, markeredgewidth=1.5, label=scenario_names[i])
        for i in range(len(scenario_names))
    ]

    panel_labels_ng = ['(A)', '(B)', '(C)', '(D)']
    positions_ng = [(0.03, 0.98), (0.55, 0.98), 
                    (0.03, 0.68), (0.55, 0.68)]

    for label_ng, pos_ng in zip(panel_labels_ng, positions_ng):
        fig_ng.text(pos_ng[0], pos_ng[1], label_ng, ha='center', va='center',
                    fontsize=fontsize_title)

    fig_ng.legend(line_handles_ng, scenario_names,
                  loc='upper center', bbox_to_anchor=(0.5, 0.375),
                  ncol=3, fontsize=fontsize_legend, columnspacing=1.2,
                  handlelength=1.8, markerscale=1.3, frameon=True, handletextpad=0.5)

    ax_e_ng = plt.subplot(gs_main_ng[2])
    
    labels_with_newlines_ng = [
        'Base case\n(No doxy-PEP)', 'One syphilis\ndiagnosis',
        'Two STI\ndiagnoses in 6m', 'Two STI\ndiagnoses in 12m',
        'HIV positive\nattendees', 'PrEP-using\nattendees'
    ]
    
    BAR_WIDTH_NG = 0.2
    BAR_SPACING_NG = 0.05
    
    # Change year range to 2025-2034
    years_bar_ng = list(range(2025, 2035))
    
    total_infections_ng_list = []
    total_infections_ci_ng_list = []
    for scenario_item in results:
        scenario_total_values_iter = [] 
        
        for param_set_item in scenario_item:
            total_val = 0
            for var_item in variable_names_ng:
                total_val += sum(param_set_item.loc[var_item, str(year_item)] for year_item in years_bar_ng)
            scenario_total_values_iter.append(total_val / 1000) 
        
        scenario_total_values_np = np.array(scenario_total_values_iter)
        se_total_val = sem(scenario_total_values_np)
        if len(scenario_total_values_np) > 1:
            ci_total_val = se_total_val * t.ppf((1 + 0.95) / 2., len(scenario_total_values_np) - 1)
        else:
            ci_total_val = 0
        total_infections_ci_ng_list.append(ci_total_val)
        
        scenario_type_total_list = []
        for var_item in variable_names_ng:
            param_set_totals = []
            for param_set_item in scenario_item:
                total_val = sum(param_set_item.loc[var_item, str(year_item)] for year_item in years_bar_ng)
                param_set_totals.append(total_val)
            mean_total = np.mean(param_set_totals) / 1000
            scenario_type_total_list.append(mean_total)
        total_infections_ng_list.append(scenario_type_total_list)
    
    total_infections_ng_np = np.array(total_infections_ng_list)
    
    increased_resistance_ng_list = []
    increased_resistance_ci_ng_list = []
    
    base_case_dox_values_list = [] 
    base_case_double_values_list = [] 
    
    for param_set_item in results[0]:
        base_case_dox_val = sum(param_set_item.loc['NG_new_Dox_infections', str(year_item)] for year_item in years_bar_ng) / 1000
        base_case_double_val = sum(param_set_item.loc['NG_new_Double_infections', str(year_item)] for year_item in years_bar_ng) / 1000
        base_case_dox_values_list.append(base_case_dox_val)
        base_case_double_values_list.append(base_case_double_val)
    
    base_case_dox_values_np = np.array(base_case_dox_values_list)
    base_case_double_values_np = np.array(base_case_double_values_list)
    
    for scenario_idx, scenario_item in enumerate(results):
        if scenario_idx == 0: 
            increased_resistance_ng_list.append([0, 0])
            increased_resistance_ci_ng_list.append([[0, 0], [0, 0]])
        else:
            scenario_dox_diff_values_iter = []
            scenario_double_diff_values_iter = []
            
            for param_idx, param_set_item in enumerate(scenario_item):
                scenario_dox_val = sum(param_set_item.loc['NG_new_Dox_infections', str(year_item)] for year_item in years_bar_ng) / 1000
                scenario_double_val = sum(param_set_item.loc['NG_new_Double_infections', str(year_item)] for year_item in years_bar_ng) / 1000
                
                dox_diff_val = scenario_dox_val - base_case_dox_values_np[param_idx]
                double_diff_val = scenario_double_val - base_case_double_values_np[param_idx]
                
                scenario_dox_diff_values_iter.append(dox_diff_val)
                scenario_double_diff_values_iter.append(double_diff_val)
            
            scenario_dox_diff_values_np = np.array(scenario_dox_diff_values_iter)
            scenario_double_diff_values_np = np.array(scenario_double_diff_values_iter)
            
            mean_dox_diff_val = np.mean(scenario_dox_diff_values_np)
            mean_double_diff_val = np.mean(scenario_double_diff_values_np)
            
            # Calculate statistical variations for confidence intervals
            stat_variations_dox = []
            stat_variations_double = []
            for _ in range(100):
                scenario_num_dox = np.random.choice(len(scenario_dox_diff_values_np), 
                                                      len(scenario_dox_diff_values_np), 
                                                      replace=True)
                scenario_num_double = np.random.choice(len(scenario_double_diff_values_np), 
                                                         len(scenario_double_diff_values_np), 
                                                         replace=True)
                
                stat_variations_dox.append(np.mean(scenario_dox_diff_values_np[scenario_num_dox]))
                stat_variations_double.append(np.mean(scenario_double_diff_values_np[scenario_num_double]))
            
            # Sort statistical variations for confidence interval calculation
            stat_variations_dox_sorted = np.sort(stat_variations_dox)
            stat_variations_double_sorted = np.sort(stat_variations_double)
            
            # Calculate confidence intervals
            dox_ci_lower_val = stat_variations_dox_sorted[int(0.025 * 100)]
            dox_ci_upper_val = stat_variations_dox_sorted[int(0.975 * 100)]
            double_ci_lower_val = stat_variations_double_sorted[int(0.025 * 100)]
            double_ci_upper_val = stat_variations_double_sorted[int(0.975 * 100)]
            
            increased_resistance_ng_list.append([mean_dox_diff_val, mean_double_diff_val])
            increased_resistance_ci_ng_list.append([
                [mean_dox_diff_val - dox_ci_lower_val, dox_ci_upper_val - mean_dox_diff_val],
                [mean_double_diff_val - double_ci_lower_val, double_ci_upper_val - mean_double_diff_val]
            ])
    
    increased_resistance_ng_np = np.array(increased_resistance_ng_list)
    increased_resistance_ci_ng_np = np.array(increased_resistance_ci_ng_list)
    
    ax2_e_ng = ax_e_ng.twinx()
    x_ng = np.arange(len(labels_with_newlines_ng))
    
    bottom_left_ng = np.zeros(len(x_ng))
    for i, var_values_item in enumerate(total_infections_ng_np.T):
        ax_e_ng.bar(x_ng - BAR_WIDTH_NG/2 - BAR_SPACING_NG/2, var_values_item, BAR_WIDTH_NG, bottom=bottom_left_ng, color=colors_ng[i], 
                    label=['Neither', 'Ceftriaxone DS only', 'HL TetR only', 'Both'][i])
        bottom_left_ng += var_values_item
    
    ax_e_ng.errorbar(x_ng - BAR_WIDTH_NG/2 - BAR_SPACING_NG/2, np.sum(total_infections_ng_np, axis=1), yerr=total_infections_ci_ng_list,
                     fmt='none', color='black', capsize=5)
    
    bottom_right_ng = np.zeros(len(x_ng))
    for i, var_values_item in enumerate(increased_resistance_ng_np.T):
        ax2_e_ng.bar(x_ng + BAR_WIDTH_NG/2 + BAR_SPACING_NG/2, var_values_item, BAR_WIDTH_NG, bottom=bottom_right_ng, color=colors_ng[i+2])
        bottom_right_ng += var_values_item
    
    for i in range(1, len(x_ng)): 
        total_diff_val = np.sum(increased_resistance_ng_np[i])
        total_ci_lower_val = np.sum([increased_resistance_ci_ng_np[i, 0, 0], increased_resistance_ci_ng_np[i, 1, 0]])
        total_ci_upper_val = np.sum([increased_resistance_ci_ng_np[i, 0, 1], increased_resistance_ci_ng_np[i, 1, 1]])
        
        ax2_e_ng.errorbar(x_ng[i] + BAR_WIDTH_NG/2 + BAR_SPACING_NG/2, total_diff_val, 
                          yerr=[[total_ci_lower_val], [total_ci_upper_val]], fmt='none', color='black', capsize=5)
    
    ax_e_ng.set_title('Gonorrhoea infections: cumulative and HL TetR increase (2025-2034)',
                      fontsize=fontsize_title-4, pad=15)
    ax_e_ng.set_xticks(x_ng)
    ax_e_ng.set_xticklabels(labels_with_newlines_ng)
    ax_e_ng.set_ylabel('Total gonorrhoea (,000)', fontsize=fontsize_label)
    ax2_e_ng.set_ylabel('HL TetR increase (,000)', fontsize=fontsize_label)
    
    ax_e_ng.tick_params(axis='both', labelsize=fontsize_ticks)
    ax2_e_ng.tick_params(axis='y', labelsize=fontsize_ticks)
    
    ax_e_ng.set_ylim(bottom=-2.5) 
    ax2_e_ng.set_ylim(bottom=-0.55) 
    
    handles1_ng, labels1_ng = ax_e_ng.get_legend_handles_labels()
    ax_e_ng.legend(handles1_ng, labels1_ng,
                   loc='upper center', bbox_to_anchor=(0.5, -0.2),
                   ncol=4, fontsize=fontsize_legend, frameon=True)
    
    ax_e_ng.grid(True, alpha=0.3)
    ax_e_ng.spines['top'].set_visible(False)
    ax2_e_ng.spines['top'].set_visible(False)
    
    fig_ng.text(0.03, 0.32, '(E)', ha='center', va='center',
                fontsize=fontsize_title)

    plt.tight_layout()
    plt.show()
    return fig_ng

def plot_NG_resistance_proportions(results, start_year=2024, end_year=2034):
    """
    Plot the proportions of NG resistance patterns.
    
    Parameters:
    -----------
    results : list
        List containing results for 6 scenarios
    start_year : int
        Start year for the analysis
    end_year : int
        End year for the analysis
    """
    fontsize_title = 30
    fontsize_label = 24
    fontsize_ticks = 20
    fontsize_legend = 18

    variable_names_prop = ['NG_new_AMS_infections', 'NG_new_Cef_infections',
                           'NG_new_Dox_infections', 'NG_new_Double_infections']
    colors_prop = ['#7f9695', '#bba59d', '#a44a76', '#9181ab']
    legend_labels_prop = ['Neither', 'Ceftriaxone DS only', 
                          'HL TetR only', 'Both']

    fig_prop = plt.figure(figsize=(18, 13))
    gs_main_prop = gridspec.GridSpec(2, 1, height_ratios=[0.9, 0.1]) 

    gs_proportion_prop = gridspec.GridSpecFromSubplotSpec(2, 3, subplot_spec=gs_main_prop[0],
                                                      hspace=0.2, wspace=0.3)
    axs_proportion_prop = [plt.subplot(gs_proportion_prop[i//3, i%3]) for i in range(6)]

    for scenario_idx, ax_item in enumerate(axs_proportion_prop):
        years_prop = list(range(start_year, end_year + 1))
        proportions_dict = {var: [] for var in variable_names_prop}
        
        for var_item in variable_names_prop:
            mean_values_item = calculate_means_for_scenario(results[scenario_idx], var_item, years_prop)
            proportions_dict[var_item] = mean_values_item

        total_infections_prop = np.zeros(len(years_prop))
        for var_item in variable_names_prop:
            total_infections_prop += proportions_dict[var_item]
        
        # Avoid division by zero if total_infections_prop contains zeros
        total_infections_prop[total_infections_prop == 0] = 1e-9 # Replace zeros with a small number

        for var_item in variable_names_prop:
            proportions_dict[var_item] = np.array(proportions_dict[var_item]) / total_infections_prop

        years_array_prop = np.array(years_prop)
        bottom_prop = np.zeros(len(years_prop))
        text_positions_prop = {}
        
        for var_item, color_item in zip(variable_names_prop, colors_prop):
            current_bottom_prop = bottom_prop.copy()
            bottom_prop += proportions_dict[var_item]
            text_positions_prop[var_item] = current_bottom_prop + 0.5 * proportions_dict[var_item]
            ax_item.fill_between(years_array_prop, current_bottom_prop, bottom_prop, color=color_item, 
                                 label=legend_labels_prop[variable_names_prop.index(var_item)])

        ax_item.set_title(scenario_names[scenario_idx], fontsize=fontsize_title, pad=15, x=0.55)
        ax_item.set_xticks(np.arange(start_year, end_year + 1, 2))
        if scenario_idx >= 3:
            ax_item.set_xticklabels(np.arange(start_year, end_year + 1, 2), rotation=45)
            ax_item.set_xlabel('Year', fontsize=fontsize_label)
        else:
            ax_item.set_xticklabels([])
        ax_item.tick_params(axis='both', labelsize=fontsize_ticks)
        ax_item.set_xlim(start_year, end_year)
        ax_item.set_ylim(0, 1)
        
        ax_item.set_yticks([])
        
        if scenario_idx % 3 == 0: 
            ax_item.set_ylabel('Proportion (%)', fontsize=fontsize_label)
            ax_item.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: f'{int(y*100)}%'))

        for var_item in variable_names_prop:
            percentage_text_2034 = f"{proportions_dict[var_item][-1] * 100:.1f}%"
            percentage_text_2024 = f"{proportions_dict[var_item][0] * 100:.1f}%"

            if var_item == 'NG_new_Cef_infections' and scenario_idx in [2, 3, 5]:
                offset_map = {2: 0.01, 3: 0.02, 5: 0.04}
                offset_val = offset_map[scenario_idx]
                ax_item.text(2034 + 0.1, text_positions_prop[var_item][-1] + offset_val, percentage_text_2034,
                             verticalalignment='center', fontsize=fontsize_ticks-2,
                             color='black', ha='left')
            else:
                ax_item.text(2034 + 0.1, text_positions_prop[var_item][-1], percentage_text_2034,
                             verticalalignment='center', fontsize=fontsize_ticks-2,
                             color='black', ha='left')

            ax_item.text(2024 + 0.1, text_positions_prop[var_item][0], percentage_text_2024,
                         verticalalignment='center', fontsize=fontsize_ticks-2,
                         color='black', ha='left')

    panel_labels_prop = ['(A)', '(B)', '(C)', '(D)', '(E)', '(F)']
    positions_prop = [(0.01, 0.973), (0.345, 0.973), (0.67, 0.973),
                      (0.01, 0.562), (0.345, 0.562), (0.67, 0.562)]

    for label_prop, pos_prop in zip(panel_labels_prop, positions_prop):
        fig_prop.text(pos_prop[0], pos_prop[1], label_prop, ha='center', va='center',
                      fontsize=fontsize_title)

    handles_prop, labels_prop = axs_proportion_prop[0].get_legend_handles_labels()
    fig_prop.legend(handles_prop, labels_prop, loc='upper center', bbox_to_anchor=(0.5, 0.1),
                    ncol=4, fontsize=fontsize_legend, frameon=True)

    plt.tight_layout()
    plt.show()
    return fig_prop

def plot_scatter_with_efficient_frontier(data, x_column, y_column, title="Scatter Plot with Efficient Frontier", 
                                         xlabel="X-axis", ylabel="Y-axis", figsize=(10, 6), pre_unit="", post_unit="", scaling_factor=1, 
                                         decimal_places=2, point_size=80, frontier_line_width=2, frontier_color='black', 
                                         marker_styles_list=None, x_label_offset=0.4, y_label_offset=0.8, Corr=True, Frontier=True, corr_text_pos=(0.02, 0.45)):
    """
    Create a scatter plot with efficient frontier and slope annotations.
    
    Args:
        data: DataFrame containing the data
        x_column: Column name for x-axis
        y_column: Column name for y-axis
        title: Plot title
        xlabel: X-axis label
        ylabel: Y-axis label
        figsize: Figure size
        pre_unit: Unit prefix for slope labels
        post_unit: Unit suffix for slope labels
        scaling_factor: Factor to scale the slope values
        decimal_places: Number of decimal places for slope labels
        point_size: Size of scatter points
        frontier_line_width: Width of frontier line
        frontier_color: Color of frontier line
        marker_styles_list: List of marker styles (if None, default is used)
        x_label_offset: Offset for x-axis labels on frontier segments
        y_label_offset: Offset for y-axis labels on frontier segments
        Corr: Whether to show correlation line and statistics
        Frontier: Whether to show efficient frontier line and slope labels
        corr_text_pos: Correlation text box coordinates (ax.transAxes), tuple
    """
    
    x_data_scatter, y_data_scatter = data[x_column].values.flatten(), data[y_column].values.flatten()
    labels_scatter = data.index
    
    _, ax_scatter = plt.subplots(figsize=figsize)
    
    # Default marker styles and colors if not provided
    if marker_styles_list is None:
        marker_styles_scatter = ['^', 's', 'D', 'p', 'h']
    else:
        marker_styles_scatter = marker_styles_list
        
    colors_scatter = ['#229FDB', '#CC522A', '#8A2C84', '#E4AE16', '#42A946']
    
    points_scatter = list(zip(x_data_scatter, y_data_scatter, labels_scatter))
    used_indices_scatter = set()
    line_points_scatter = [(0, 0)] # Start frontier from origin
    line_labels_scatter = []

    if Frontier:
        min_slope_scatter = float('inf')
        first_idx_scatter = -1
        for i, (x, y, label_item) in enumerate(points_scatter):
            if x > 0: 
                slope_val = y / x
                if slope_val < min_slope_scatter:
                    min_slope_scatter = slope_val
                    first_idx_scatter = i
        if first_idx_scatter == -1: # No points to the right of origin
             # print("Warning: No suitable points for efficient frontier.")
             pass # Or raise ValueError("No suitable points for efficient frontier.")
        else:
            line_points_scatter.append((points_scatter[first_idx_scatter][0], points_scatter[first_idx_scatter][1]))
            line_labels_scatter.append(points_scatter[first_idx_scatter][2])
            used_indices_scatter.add(first_idx_scatter)

            current_idx_scatter = first_idx_scatter
            while True:
                current_x_scatter, current_y_scatter = points_scatter[current_idx_scatter][0], points_scatter[current_idx_scatter][1]
                min_slope_iter = float('inf')
                next_idx_scatter = -1
                for i, (x, y, label_item) in enumerate(points_scatter):
                    if i in used_indices_scatter:
                        continue
                    if x > current_x_scatter: 
                        if (x - current_x_scatter) == 0: continue # Avoid division by zero
                        slope_val = (y - current_y_scatter) / (x - current_x_scatter)
                        if slope_val < min_slope_iter:
                            min_slope_iter = slope_val
                            next_idx_scatter = i
                if next_idx_scatter == -1:
                    break
                line_points_scatter.append((points_scatter[next_idx_scatter][0], points_scatter[next_idx_scatter][1]))
                line_labels_scatter.append(points_scatter[next_idx_scatter][2])
                used_indices_scatter.add(next_idx_scatter)
                current_idx_scatter = next_idx_scatter
        
        if len(line_points_scatter) > 1: # Only plot if frontier has segments
            line_x_scatter, line_y_scatter = zip(*line_points_scatter)
            ax_scatter.plot(line_x_scatter, line_y_scatter, color=frontier_color, linestyle='-', linewidth=frontier_line_width, zorder=1)
            
            for i in range(len(line_points_scatter) - 1):
                x1_s, y1_s, x2_s, y2_s = *line_points_scatter[i], *line_points_scatter[i+1]
                if (x2_s - x1_s) == 0: continue # Avoid division by zero for slope
                slope_s = (y2_s - y1_s) / (x2_s - x1_s) * scaling_factor
                formatted_slope_s = f"{slope_s:.0f}" if abs(slope_s) >= 1000 else f"{slope_s:.{decimal_places}f}"
                formatted_slope_s = formatted_slope_s.rstrip('0').rstrip('.')
                
                mid_x_s, mid_y_s = (x1_s + x2_s) / 2, (y1_s + y2_s) / 2
                text_x_s, text_y_s = x1_s + (x2_s - x1_s) * x_label_offset, y1_s + (y2_s - y1_s) * y_label_offset
                
                ax_scatter.plot([mid_x_s, text_x_s], [mid_y_s, text_y_s], linestyle='--', color='gray', linewidth=0.8, zorder=2)
                ax_scatter.text(text_x_s, text_y_s, f"{pre_unit}{formatted_slope_s}{post_unit}", rotation=0,
                                verticalalignment='bottom', horizontalalignment='center', fontsize=9,
                                color='black', bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="gray", alpha=0.8), zorder=15)
    
    ax_scatter.scatter(0, 0, s=point_size, marker='o', color='black', label='Base case', zorder=5)
    
    frontier_indices_scatter = set(line_labels_scatter) if Frontier else set()
    for i, (x, y) in enumerate(zip(x_data_scatter, y_data_scatter)):
        marker_s = marker_styles_scatter[i % len(marker_styles_scatter)]
        color_s = colors_scatter[i % len(colors_scatter)]
        label_s = labels_scatter[i]
        z_order_s = 5 if label_s in frontier_indices_scatter else 4
        ax_scatter.scatter(x, y, s=point_size, marker=marker_s, color=color_s, label=label_s, zorder=z_order_s)
    
    if Corr:
        all_x_corr = np.concatenate([[0], x_data_scatter])
        all_y_corr = np.concatenate([[0], y_data_scatter])
        
        if len(all_x_corr) > 1 and len(all_y_corr) > 1: # Need at least 2 points for correlation/regression
            spearman_corr_val, p_value_corr = stats.spearmanr(all_x_corr, all_y_corr)
            
            slope_reg, intercept_reg, r_value_reg, p_value_reg_line, std_err_reg = stats.linregress(all_x_corr, all_y_corr)
            x_reg_line = np.linspace(0, max(all_x_corr) if len(all_x_corr) > 0 else 0, 100) 
            y_reg_line = slope_reg * x_reg_line + intercept_reg
            
            mask_reg = y_reg_line >= 0
            x_reg_plot = x_reg_line[mask_reg]
            y_reg_plot = y_reg_line[mask_reg]
            
            if len(x_reg_plot) > 0: 
                ax_scatter.plot(x_reg_plot, y_reg_plot, 'k--', alpha=0.5)
            
            corr_text_str = (f"Spearman's ρ = {spearman_corr_val:.3f}\np-value = {p_value_corr:.3f}\n"
                             f"Regression line:\ny = {slope_reg:.3f}x + {intercept_reg:.3f}\nR² = {r_value_reg**2:.3f}")
            ax_scatter.text(corr_text_pos[0], corr_text_pos[1], corr_text_str, transform=ax_scatter.transAxes, 
                            bbox=dict(facecolor='white', alpha=0.8),
                            verticalalignment='bottom', fontsize=10)
    
    ax_scatter.set_ylim(0, max(y_data_scatter)*1.1 if len(y_data_scatter) > 0 else 1) # Handle empty y_data
    ax_scatter.set_title(title)
    ax_scatter.set_xlabel(xlabel)
    ax_scatter.set_ylabel(ylabel)
    
    legend_scatter = ax_scatter.legend(loc='upper left', framealpha=0.8, edgecolor='black', ncol=1)
    plt.gca().add_artist(legend_scatter) # Ensures legend does not get overwritten by other plot elements if any.
    
    ax_scatter.grid(True, linestyle='--', alpha=0.6)
    plt.tight_layout()
    plt.show()

def plot_tornado_multiple_scenarios(tables, variable_name, special_groups=None, vertical_lines=None, row_labels=None):
    """
    Plot horizontal scatter plots for multiple scenarios, with each scenario in a separate subplot.
    
    Parameters:
    -----------
    tables : list
        List containing results for all parameter groups
    variable_name : str
        Name of the variable to analyze
    special_groups : list, optional
        List of group numbers that should be placed in the same row
    vertical_lines : list, optional
        List of dictionaries containing vertical line configurations
    row_labels : list, optional
        List of labels for each row
    """
    scenarios = [
        'One syphilis diagnosis',
        'Two STI diagnoses in 6m',
        'Two STI diagnoses in 12m',
        'HIV positive attendees',
        'PrEP-using attendees'
    ]
    
    # Create a 3x2 subplot layout
    fig, axes = plt.subplots(3, 2, figsize=(15, 16))
    axes = axes.flatten()
    
    # Plot scatter for each scenario
    for i, scenario in enumerate(scenarios):
        ax = axes[i]
        
        # Get baseline values (group 1)
        base_value = tables[0].loc[scenario, (variable_name, 'Mean')]
        base_ci_lower = tables[0].loc[scenario, (variable_name, '95% CI Lower')]
        base_ci_upper = tables[0].loc[scenario, (variable_name, '95% CI Upper')]
        
        # Prepare data
        y_labels = []
        x_ranges = []  # Store min and max for each group
        x_ci_ranges = []  # Store CI range for each group
        
        # Process parameter groups
        j = 1
        label_index = 0
        while j < len(tables):
            if j == 3:  # For group 3, 4, 5, 6, plot together
                group_values = [
                    tables[3].loc[scenario, (variable_name, 'Mean')],
                    tables[4].loc[scenario, (variable_name, 'Mean')],
                    tables[5].loc[scenario, (variable_name, 'Mean')],
                    tables[6].loc[scenario, (variable_name, 'Mean')]
                ]
                group_ci_lower = [
                    tables[3].loc[scenario, (variable_name, '95% CI Lower')],
                    tables[4].loc[scenario, (variable_name, '95% CI Lower')],
                    tables[5].loc[scenario, (variable_name, '95% CI Lower')],
                    tables[6].loc[scenario, (variable_name, '95% CI Lower')]
                ]
                group_ci_upper = [
                    tables[3].loc[scenario, (variable_name, '95% CI Upper')],
                    tables[4].loc[scenario, (variable_name, '95% CI Upper')],
                    tables[5].loc[scenario, (variable_name, '95% CI Upper')],
                    tables[6].loc[scenario, (variable_name, '95% CI Upper')]
                ]
                
                min_val = min(min(group_values), base_value)
                max_val = max(max(group_values), base_value)
                min_ci = min(min(group_ci_lower), base_ci_lower)
                max_ci = max(max(group_ci_upper), base_ci_upper)
                
                if row_labels:
                    y_labels.append(row_labels[label_index])
                else:
                    y_labels.append('Parameter groups 3-6')
                x_ranges.append((min_val, max_val))
                x_ci_ranges.append((min_ci, max_ci))
                label_index += 1
                j += 4
            elif j + 1 < len(tables):
                # Other groups are paired
                group_values = [
                    tables[j].loc[scenario, (variable_name, 'Mean')],
                    tables[j+1].loc[scenario, (variable_name, 'Mean')]
                ]
                group_ci_lower = [
                    tables[j].loc[scenario, (variable_name, '95% CI Lower')],
                    tables[j+1].loc[scenario, (variable_name, '95% CI Lower')]
                ]
                group_ci_upper = [
                    tables[j].loc[scenario, (variable_name, '95% CI Upper')],
                    tables[j+1].loc[scenario, (variable_name, '95% CI Upper')]
                ]
                
                min_val = min(min(group_values), base_value)
                max_val = max(max(group_values), base_value)
                min_ci = min(min(group_ci_lower), base_ci_lower)
                max_ci = max(max(group_ci_upper), base_ci_upper)
                
                if row_labels:
                    y_labels.append(row_labels[label_index])
                else:
                    y_labels.append(f'Parameter groups {j}-{j+1}')
                x_ranges.append((min_val, max_val))
                x_ci_ranges.append((min_ci, max_ci))
                label_index += 1
                j += 2
            else:
                # If last group is unpaired, show it alone
                group_values = [tables[j].loc[scenario, (variable_name, 'Mean')]]
                group_ci_lower = [tables[j].loc[scenario, (variable_name, '95% CI Lower')]]
                group_ci_upper = [tables[j].loc[scenario, (variable_name, '95% CI Upper')]]
                
                min_val = min(group_values[0], base_value)
                max_val = max(group_values[0], base_value)
                min_ci = min(group_ci_lower[0], base_ci_lower)
                max_ci = max(group_ci_upper[0], base_ci_upper)
                
                if row_labels:
                    y_labels.append(row_labels[label_index])
                else:
                    y_labels.append(f'Parameter group {j}')
                x_ranges.append((min_val, max_val))
                x_ci_ranges.append((min_ci, max_ci))
                label_index += 1
                j += 1
        
        # Plot baseline line
        ax.axvline(x=base_value, color='gray', linestyle='--', alpha=0.5, label='Base case')
        
        # Plot range bars and error bars
        for k, (y_label, (min_val, max_val), (min_ci, max_ci)) in enumerate(zip(y_labels[::-1], x_ranges[::-1], x_ci_ranges[::-1])):
            # Plot horizontal bar for range
            ax.barh(k, max_val - min_val, left=min_val, height=0.4, 
                   color='#666666', alpha=0.6)
            
            # Modify errorbar plotting
            # Left error bar
            left_err = abs(min_ci - min_val)
            ax.errorbar(min_val, k, xerr=[[left_err], [0]], 
                       color='black', capsize=0, capthick=1, elinewidth=1)
            # Right error bar
            right_err = abs(max_ci - max_val)
            ax.errorbar(max_val, k, xerr=[[0], [right_err]], 
                       color='black', capsize=0, capthick=1, elinewidth=1)
        
        # Plot vertical dashed line (if provided)
        if vertical_lines:
            for line_config in vertical_lines:
                x = line_config['x']
                color = line_config['color']
                label = line_config.get('label', None)
                ax.axvline(x=x, color=color, linestyle='--', alpha=0.5, label=label)
        
        # Set y-axis label
        ax.set_yticks(range(len(y_labels)))
        ax.set_yticklabels(y_labels[::-1])
        
        # Set title and labels
        ax.set_title(scenario)
        if i == 3 or i == 4:  # Only show x-axis label on bottom subplots
            ax.set_xlabel(variable_name)
        
        # Add legend (only on first subplot)
        if i == 4:
            ax.legend(loc='lower right')
    
    # Remove last subplot
    fig.delaxes(axes[-1])
    
    # Adjust layout
    plt.tight_layout()
    plt.show()
    return fig

def compare_model_with_real(intermediate_outcomes, data_for_fitting, N_weeks_2, N_weeks_4, start_year=2012):
    # Define all possible variables
    all_variables = [
        'NG_Inci_Overall', 'CT_Inci_Overall', 'TP_Inci_Overall',
        'NG_Inci_NoPrEP', 'NG_Inci_PrEP', 'NG_Inci_HIV',
        'CT_Inci_NoPrEP', 'CT_Inci_PrEP', 'CT_Inci_HIV',
        'TP_Inci_NoPrEP', 'TP_Inci_PrEP', 'TP_Inci_HIV',
        'NG_Cef_prop', 'NG_Dox_prop'
    ]
    
    # Get variables from data_for_fitting and ensure all necessary variables are included
    variables = list(set(list(data_for_fitting.index) + all_variables))
    
    n_years = (N_weeks_4 - N_weeks_2) // 52
    years = [str(start_year + i) for i in range(n_years)]

    data_for_fitting.columns = data_for_fitting.columns.astype(str)

    def get_one_model_annual_indicators(outcome):
        # Use pre-calculated yearly data
        Yearly_infection = outcome[0]
        Yearly_screened_diagnosis = outcome[1]
        
        # Create result DataFrame with proper index and columns
        result = pd.DataFrame(index=variables, columns=years)
        
        # Get all the indicators directly from Yearly_infection
        indicators = [
            'NG_Inci_Overall', 'CT_Inci_Overall', 'TP_Inci_Overall',
            'NG_Inci_NoPrEP', 'NG_Inci_PrEP', 'NG_Inci_HIV',
            'CT_Inci_NoPrEP', 'CT_Inci_PrEP', 'CT_Inci_HIV',
            'TP_Inci_NoPrEP', 'TP_Inci_PrEP', 'TP_Inci_HIV'
        ]
        
        # Copy all indicators that exist in both DataFrames
        for indicator in indicators:
            if indicator in Yearly_infection.index and indicator in result.index:
                result.loc[indicator] = Yearly_infection.loc[indicator]
        
        # Add diagnosis proportions
        if 'NG_Cef_prop' in result.index:
            result.loc['NG_Cef_prop'] = Yearly_screened_diagnosis.loc['NG_Cef_prop']
        if 'NG_Dox_prop' in result.index:
            result.loc['NG_Dox_prop'] = Yearly_screened_diagnosis.loc['NG_Dox_prop']

        return result

    model_results_list = []
    for outcome in intermediate_outcomes:
        model_results_list.append(get_one_model_annual_indicators(outcome))

    arrs = {var: np.array([df.loc[var, years].astype(float).values for df in model_results_list]) for var in variables}
    mean = {var: np.nanmean(arrs[var], axis=0) for var in variables}
    se = {var: sem(arrs[var], axis=0, nan_policy='omit') for var in variables}
    ci = {var: se[var] * t.ppf((1 + 0.95) / 2., arrs[var].shape[0] - 1) for var in variables}

    # Create a single figure with 4x4 panels
    fig, axes = plt.subplots(4, 4, figsize=(20, 15))
    axes = axes.flatten()

    # Define panel titles
    panel_titles = {
        'NG_Inci_Overall': 'NG Overall Incidence',
        'NG_Inci_NoPrEP': 'NG Incidence, No PrEP',
        'NG_Inci_PrEP': 'NG Incidence, PrEP',
        'NG_Inci_HIV': 'NG Incidence, HIV',
        'CT_Inci_Overall': 'CT Overall Incidence',
        'CT_Inci_NoPrEP': 'CT Incidence, No PrEP',
        'CT_Inci_PrEP': 'CT Incidence, PrEP',
        'CT_Inci_HIV': 'CT Incidence, HIV',
        'TP_Inci_Overall': 'TP Overall Incidence',
        'TP_Inci_NoPrEP': 'TP Incidence, No PrEP',
        'TP_Inci_PrEP': 'TP Incidence, PrEP',
        'TP_Inci_HIV': 'TP Incidence, HIV',
        'NG_Cef_prop': 'NG isolates with CRO DS',
        'NG_Dox_prop': 'NG isolates with HL-TC AMR'
    }

    # Define y-axis labels
    ylabels = {
        'NG_Inci_Overall': 'per 100 PY', 'NG_Inci_NoPrEP': 'per 100 PY', 
        'NG_Inci_PrEP': 'per 100 PY', 'NG_Inci_HIV': 'per 100 PY',
        'CT_Inci_Overall': 'per 100 PY', 'CT_Inci_NoPrEP': 'per 100 PY', 
        'CT_Inci_PrEP': 'per 100 PY', 'CT_Inci_HIV': 'per 100 PY',
        'TP_Inci_Overall': 'per 100 PY', 'TP_Inci_NoPrEP': 'per 100 PY', 
        'TP_Inci_PrEP': 'per 100 PY', 'TP_Inci_HIV': 'per 100 PY',
        'NG_Cef_prop': 'Proportion (%)', 'NG_Dox_prop': 'Proportion (%)'
    }

    # Define panel order
    panel_order = [
        'NG_Inci_Overall', 'NG_Inci_NoPrEP', 'NG_Inci_PrEP', 'NG_Inci_HIV',
        'CT_Inci_Overall', 'CT_Inci_NoPrEP', 'CT_Inci_PrEP', 'CT_Inci_HIV',
        'TP_Inci_Overall', 'TP_Inci_NoPrEP', 'TP_Inci_PrEP', 'TP_Inci_HIV',
        'NG_Cef_prop', 'NG_Dox_prop'
    ]

    # Plot each panel
    for i, var in enumerate(panel_order):
        ax = axes[i]
        ax.plot(years, mean[var][:len(years)]*100, label='Model Mean')
        ax.fill_between(years, (mean[var]-ci[var])[:len(years)]*100, (mean[var]+ci[var])[:len(years)]*100, alpha=0.3, label='95% CI')
        real_years = [y for y in years if y in data_for_fitting.columns]
        real_data = data_for_fitting.loc[var, real_years].dropna()*100
        if not real_data.empty:
            ax.scatter(real_data.index, real_data.values, facecolors='none', edgecolors='black', s=50, label='Real Data')
        
        ax.set_title(panel_titles[var], fontsize=14)
        ax.grid(True)
        ax.set_ylabel(ylabels[var], fontsize=12)
        
        # Set x-axis labels for bottom row
        if i >= 12:  # Last row
            ax.set_xticks([years[j] for j in range(0, len(years), 2)])
            ax.set_xticklabels([years[j] for j in range(0, len(years), 2)], rotation=45, ha='right')
            ax.set_xlabel('Year', fontsize=12)
        else:
            ax.set_xticks([])
            ax.set_xlabel('')
        
        # Add legend only to the first panel
        if i == 0:
            ax.legend(['Model Mean', '95% CI', 'Real Data'], loc='upper left')

    # Turn off the last two panels
    for i in range(14, 16):
        axes[i].axis('off')

    plt.tight_layout()
    plt.show()
    return fig

# -----------------------------------------------------------------------------
# VARIABLE DEFINITIONS FOR CALCULATIONS
# -----------------------------------------------------------------------------
normal_discount_rate = 0.03
normal_doxy_PEP_price = 104

Var_calcu_formula = {
    'Gonorrhoea': ([('NG_new_infections', 1)], 0),
    'Chlamydia': ([('CT_new_infections', 1)], 0),
    'Syphilis': ([('TP_new_infections', 1)], 0),
    'Total new STIs': ([('NG_new_infections', 1), ('CT_new_infections', 1), ('TP_new_infections', 1)], 0),
    'New NG infections with HL TetR': ([('NG_new_Dox_infections', 1), ('NG_new_Double_infections', 1)], 0),
    'New NG infections with CRO DS only': ([('NG_new_Cef_infections', 1)], 0),
    'New NG infections with Double': ([('NG_new_Double_infections', 1)], 0),
    'QALYs lost due to STI': ([('NG_new_infections', -1.41*1e-3),
                               ('CT_new_infections', -0.93*1e-3),
                               ('TP_new_infections', -0.06)], normal_discount_rate),
    'Direct medical cost (A$ ,000)': ([('NG_symptom_diag', (121.9+110.8)*1e-3), ('NG_screened', (110.8)*1e-3),
                                       ('CT_symptom_diag', (121.9+64.4)*1e-3), ('CT_screened', (64.4)*1e-3),
                                       ('TP_early_symptom_diag', (121.9+125.8)*1e-3), ('TP_early_screened', (125.8)*1e-3),
                                       ('TP_late_symptom_diag', (121.9+346)*1e-3), ('TP_late_screened', (346)*1e-3),
                                       ('All_screened', (121.9)*1e-3), ('HIV_pos_STI_tests', (-20)*1e-3)], normal_discount_rate),
    'Cost of doxy-PEP (A$ ,000)': ([('Doxy_PEP_enter', (normal_doxy_PEP_price)*1e-3)], normal_discount_rate),
    'Total cost (A$ ,000)': ([('NG_symptom_diag', (121.9+110.8)*1e-3), ('NG_screened', (110.8)*1e-3),
                               ('CT_symptom_diag', (121.9+64.4)*1e-3), ('CT_screened', (64.4)*1e-3),
                               ('TP_early_symptom_diag', (121.9+125.8)*1e-3), ('TP_early_screened', (125.8)*1e-3),
                               ('TP_late_symptom_diag', (121.9+346)*1e-3), ('TP_late_screened', (346)*1e-3),
                               ('All_screened', (121.9)*1e-3), ('HIV_pos_STI_tests', (-20)*1e-3),
                               ('Doxy_PEP_enter', (104)*1e-3)], normal_discount_rate),
    'Doxy-PEP prescriptions': ([('Doxy_PEP_enter', 1)], 0),
    'Doxy-PEP coverage': ([('Doxy_PEP_coverage', 0.1)], 0),
}

Var_calcu_formula_differ = {
    'Reduction in new STIs': ([('NG_new_infections', -1), ('CT_new_infections', -1), ('TP_new_infections', -1)], 0),
    'Reduction in new Syphilis': ([('TP_new_infections', -1)], 0),
    'Increased new NG infections with HL TetR': ([('NG_new_Dox_infections', 1), ('NG_new_Double_infections', 1)], 0),
    'Change in new NG infections with CRO DS only': ([('NG_new_Cef_infections', 1)], 0),
    'Change in new NG infections with Double': ([('NG_new_Double_infections', 1)], 0),
    'QALYs gained': ([('NG_new_infections', -1.41*1e-3),
                      ('CT_new_infections', -0.93*1e-3),
                      ('TP_new_infections', -0.06)], normal_discount_rate),
    'Change in direct cost (A$ ,000)': ([('NG_symptom_diag', (121.9+110.8)*1e-3), ('NG_screened', (110.8)*1e-3),
                                         ('CT_symptom_diag', (121.9+64.4)*1e-3), ('CT_screened', (64.4)*1e-3),
                                         ('TP_early_symptom_diag', (121.9+125.8)*1e-3), ('TP_early_screened', (125.8)*1e-3),
                                         ('TP_late_symptom_diag', (121.9+346)*1e-3), ('TP_late_screened', (346)*1e-3),
                                         ('All_screened', (121.9)*1e-3), ('HIV_pos_STI_tests', (-20)*1e-3)], normal_discount_rate),
    'Cost of doxy-PEP (A$ ,000)': ([('Doxy_PEP_enter', (normal_doxy_PEP_price)*1e-3)], normal_discount_rate),
    'Change in total cost (A$ ,000)': ([('NG_symptom_diag', (121.9+110.8)*1e-3), ('NG_screened', (110.8)*1e-3),
                                        ('CT_symptom_diag', (121.9+64.4)*1e-3), ('CT_screened', (64.4)*1e-3),
                                        ('TP_early_symptom_diag', (121.9+125.8)*1e-3), ('TP_early_screened', (125.8)*1e-3),
                                        ('TP_late_symptom_diag', (121.9+346)*1e-3), ('TP_late_screened', (346)*1e-3),
                                        ('All_screened', (121.9)*1e-3), ('HIV_pos_STI_tests', (-20)*1e-3),
                                        ('Doxy_PEP_enter', (104)*1e-3)], normal_discount_rate),
    'Doxy-PEP prescriptions': ([('Doxy_PEP_enter', 1)], 0),
    'Doxy-PEP coverage': ([('Doxy_PEP_coverage', 0.1)], 0),
}

Var_for_save = {
    'ICER (A$ per QALYs gained)': (True, 0),
    'New IA per Doxy-PEP prescription': (True, 1),
    'Cost per new IA (A$)': (True, 1),
    'Benefit-cost ratio': (True, 1)
}

row_labels_1 = [
    'Doxy-PEP prescription\nduration (3m → 12m)',
    'Doxy-PEP uptake\n(50% → 100%)',
    'Doxy-PEP adherence\n(50% → 100%)',
    'Doxy-PEP efficacies\n(low → high)\u1D43',
    'Proportions of individuals\nalways using condom (high → low)\u1D47',
    'Condom use % of individuals not\nalways using condom (75% → 25%)',
    'Proportion of symptomatic\ngonorrhoea (45% → 15%)',
    'Probabilities of ceftriaxone\ntreatment failure (low → high)\u1D9C',
    'Background HL TetR\nincrease rate (low → high)\u1D48',
    'Probabilities of HL TetR\ndue to doxy-PEP (low → high)\u1D49',
    'Initial STI positive rates\n(low → high)\u1DA0',
    'Discount rates\n(6% → 0%)'
]

row_labels_2 = [
    'Doxy-PEP prescription\nduration (3m → 12m)',
    'Doxy-PEP uptake\n(50% → 100%)',
    'Doxy-PEP adherence\n(50% → 100%)',
    'Doxy-PEP efficacies\n(low → high)\u1D43',
    'Proportions of individuals\nalways using condom (high → low)\u1D47',
    'Condom use % of individuals not\nalways using condom (75% → 25%)',
    'Proportion of symptomatic\ngonorrhoea (45% → 15%)',
    'Probabilities of ceftriaxone\ntreatment failure (low → high)\u1D9C',
    'Background HL TetR\nincrease rate (high → low)\u1D48',
    'Probabilities of HL TetR\ndue to doxy-PEP (high → low)\u1D49',
    'Initial STI positive rates\n(low → high)\u1DA0',
    'Discount rates\n(6% → 0%)'
]

def get_calculation_formulas(doxy_PEP_price=104, discount_rate=0.03):
    """
    Returns calculation formulas based on given doxy-PEP price and discount rate.
    
    Parameters:
    -----------
    doxy_PEP_price : float
        Price of doxy-PEP, default is 104
    discount_rate : float
        Discount rate, default is 0.03
    
    Returns:
    --------
    dict
        Dictionary containing calculation formulas
    """
    Var_calcu_formula = {
        'Gonorrhoea': ([('NG_new_infections', 1)], 0),
        'Chlamydia': ([('CT_new_infections', 1)], 0),
        'Syphilis': ([('TP_new_infections', 1)], 0),
        'Total new STIs': ([('NG_new_infections', 1), ('CT_new_infections', 1), ('TP_new_infections', 1)], 0),
        'New NG infections with HL TetR': ([('NG_new_Dox_infections', 1), ('NG_new_Double_infections', 1)], 0),
        'New NG infections with CRO DS only': ([('NG_new_Cef_infections', 1)], 0),
        'New NG infections with Double': ([('NG_new_Double_infections', 1)], 0),
        'QALYs lost due to STI': ([('NG_new_infections', -1.41*1e-3),
                                   ('CT_new_infections', -0.93*1e-3),
                                   ('TP_new_infections', -0.06)], discount_rate),
        'Direct medical cost (A$ ,000)': ([('NG_symptom_diag', (121.9+110.8)*1e-3), ('NG_screened', (110.8)*1e-3),
                                           ('CT_symptom_diag', (121.9+64.4)*1e-3), ('CT_screened', (64.4)*1e-3),
                                           ('TP_early_symptom_diag', (121.9+125.8)*1e-3), ('TP_early_screened', (125.8)*1e-3),
                                           ('TP_late_symptom_diag', (121.9+346)*1e-3), ('TP_late_screened', (346)*1e-3),
                                           ('All_screened', (121.9)*1e-3), ('HIV_pos_STI_tests', (-20)*1e-3)], discount_rate),
        'Cost of doxy-PEP (A$ ,000)': ([('Doxy_PEP_enter', (doxy_PEP_price)*1e-3)], discount_rate),
        'Total cost (A$ ,000)': ([('NG_symptom_diag', (121.9+110.8)*1e-3), ('NG_screened', (110.8)*1e-3),
                                   ('CT_symptom_diag', (121.9+64.4)*1e-3), ('CT_screened', (64.4)*1e-3),
                                   ('TP_early_symptom_diag', (121.9+125.8)*1e-3), ('TP_early_screened', (125.8)*1e-3),
                                   ('TP_late_symptom_diag', (121.9+346)*1e-3), ('TP_late_screened', (346)*1e-3),
                                   ('All_screened', (121.9)*1e-3), ('HIV_pos_STI_tests', (-20)*1e-3),
                                   ('Doxy_PEP_enter', (doxy_PEP_price)*1e-3)], discount_rate),
        'Doxy-PEP prescriptions': ([('Doxy_PEP_enter', 1)], 0),
        'Doxy-PEP coverage': ([('Doxy_PEP_coverage', 0.1)], 0),
    }

    Var_calcu_formula_differ = {
        'Reduction in new STIs': ([('NG_new_infections', -1), ('CT_new_infections', -1), ('TP_new_infections', -1)], 0),
        'Reduction in new Syphilis': ([('TP_new_infections', -1)], 0),
        'Increased new NG infections with HL TetR': ([('NG_new_Dox_infections', 1), ('NG_new_Double_infections', 1)], 0),
        'Change in new NG infections with CRO DS only': ([('NG_new_Cef_infections', 1)], 0),
        'Change in new NG infections with Double': ([('NG_new_Double_infections', 1)], 0),
        'QALYs gained': ([('NG_new_infections', -1.41*1e-3),
                          ('CT_new_infections', -0.93*1e-3),
                          ('TP_new_infections', -0.06)], discount_rate),
        'Change in direct cost (A$ ,000)': ([('NG_symptom_diag', (121.9+110.8)*1e-3), ('NG_screened', (110.8)*1e-3),
                                             ('CT_symptom_diag', (121.9+64.4)*1e-3), ('CT_screened', (64.4)*1e-3),
                                             ('TP_early_symptom_diag', (121.9+125.8)*1e-3), ('TP_early_screened', (125.8)*1e-3),
                                             ('TP_late_symptom_diag', (121.9+346)*1e-3), ('TP_late_screened', (346)*1e-3),
                                             ('All_screened', (121.9)*1e-3), ('HIV_pos_STI_tests', (-20)*1e-3)], discount_rate),
        'Cost of doxy-PEP (A$ ,000)': ([('Doxy_PEP_enter', (doxy_PEP_price)*1e-3)], discount_rate),
        'Change in total cost (A$ ,000)': ([('NG_symptom_diag', (121.9+110.8)*1e-3), ('NG_screened', (110.8)*1e-3),
                                            ('CT_symptom_diag', (121.9+64.4)*1e-3), ('CT_screened', (64.4)*1e-3),
                                            ('TP_early_symptom_diag', (121.9+125.8)*1e-3), ('TP_early_screened', (125.8)*1e-3),
                                            ('TP_late_symptom_diag', (121.9+346)*1e-3), ('TP_late_screened', (346)*1e-3),
                                            ('All_screened', (121.9)*1e-3), ('HIV_pos_STI_tests', (-20)*1e-3),
                                            ('Doxy_PEP_enter', (doxy_PEP_price)*1e-3)], discount_rate),
        'Doxy-PEP prescriptions': ([('Doxy_PEP_enter', 1)], 0),
        'Doxy-PEP coverage': ([('Doxy_PEP_coverage', 0.1)], 0),
    }
    
    return Var_calcu_formula, Var_calcu_formula_differ