"""
Doxy-PEP Analysis and Visualization Main Script
=============================================

Main script for analyzing and visualizing Doxy-PEP simulation results:

1. Data Processing:
   - Load simulation results
   - Combine multiple runs
   - Prepare analysis data

2. Visualization:
   - Generate publication figures
   - Create summary statistics
   - Perform comparative analysis

3. Output:
   - Save figures
   - Generate reports
   - Export processed data

Author: HaoL
"""

import pandas as pd
import os
import pickle
from Doxy_PEP_Ana_Vis_functions_0612 import (
    combine_model_outcomes, plot_combined_STI_incidence, plot_NG_resistance_trends,
    plot_NG_resistance_proportions, Summarize_results, plot_scatter_with_efficient_frontier,
    rank_scenarios_and_transpose, Var_for_save, row_labels_1, row_labels_2, get_calculation_formulas,
    plot_tornado_multiple_scenarios, compare_model_with_real
)
import matplotlib.pyplot as plt

Surveillance_data = pd.read_excel('Data_tobe_called/Collected_data_from_ACCESS_MSHC.xlsx', index_col=0)
#%%
# Set file paths
current_folder_path = os.path.dirname(os.path.abspath(__file__))
input_dir = os.path.join(current_folder_path, 'Data_tobe_called')
output_dir = os.path.join(current_folder_path, 'Data_output')
os.makedirs(output_dir, exist_ok=True)

# Read sensitivity analysis results
results_file = os.path.join(output_dir, 'All_params_results.pkl')
with open(results_file, 'rb') as f:
    all_results = pickle.load(f)

N_weeks_2 = 52 + 52  # Time simulated for network stabilization and STI distribution stabilization (not counted in the real-word time)
N_weeks_4 = N_weeks_2 + 52 * 13 + 52 * 10  # Time simulated for STI transmission before (2012-2024) and under different doxy-PEP scenarios (2025-2034)

# Save model vs real data comparison plot
fig_compare = compare_model_with_real(all_results[0], Surveillance_data, N_weeks_2, N_weeks_4, start_year=2012)

results_groups = []

for i in range(25):
    start_idx = i * 6
    group = all_results[start_idx:start_idx+6]
    results_groups.append(group)

#%%
# Process each result group
all_table_mean_CI = []
all_table_mean_CI_differ = []

# Process original results_groups
for i, results_group in enumerate(results_groups):
    print(f"Processing group {i+1}/25...")
    
    # Adjust doxy_PEP_price based on parameter group
    if i == 1:  # Group 2
        doxy_PEP_price = 52
    elif i == 2:  # Group 3
        doxy_PEP_price = 208
    else:  # Other groups
        doxy_PEP_price = 104
    
    # Get calculation formulas for corresponding price
    Var_calcu_formula, Var_calcu_formula_differ = get_calculation_formulas(doxy_PEP_price)
    
    # Merge model outputs
    results_for_process = combine_model_outcomes(results_group)
    
    if i == 0:
        # Group 1: Perform all analysis and plotting
        # STI incidence plot
        fig_sti = plot_combined_STI_incidence(results_for_process, start_year=2024, end_year=2034)
        fig_sti.savefig(os.path.join(output_dir, 'STI_Incidence.pdf'), format='pdf', bbox_inches='tight')
        plt.close(fig_sti)
        
        # NG resistance trends plot
        fig_ng = plot_NG_resistance_trends(results_for_process, start_year=2024, end_year=2034)
        fig_ng.savefig(os.path.join(output_dir, 'NG_Resistance_Trends.pdf'), format='pdf', bbox_inches='tight')
        plt.close(fig_ng)
        
        # NG resistance proportions plot
        fig_ng_prop = plot_NG_resistance_proportions(results_for_process, start_year=2024, end_year=2034)
        fig_ng_prop.savefig(os.path.join(output_dir, 'NG_Resistance_Proportions.pdf'), format='pdf', bbox_inches='tight')
        plt.close(fig_ng_prop)
        
        table_mean_CI, table_mean_CI_differ, formatted_df = Summarize_results(
            results_for_process, 2025, 2034, Var_calcu_formula, 
            Var_calcu_formula_differ, Var_for_save
        )
        
        rank_table, transpose_table, fig_rank = rank_scenarios_and_transpose(table_mean_CI_differ, plot_marker=True)
        fig_rank.savefig(os.path.join(output_dir, 'Prioritization_ranks.pdf'), format='pdf', bbox_inches='tight')
        plt.close(fig_rank)

        if table_mean_CI_differ is not None and not table_mean_CI_differ.empty:
            
            fig_scatter1 = plot_scatter_with_efficient_frontier(table_mean_CI_differ, 
                ('Reduction in new STIs', 'Mean'), ('Cost of doxy-PEP (A$ ,000)', 'Mean'),
                'Relation of Reduced STIs and Cost of Doxy-PEP', 'Reduction in New STIs (Mean)',
                'Cost of Doxy-PEP (A$,000) (Mean)', pre_unit="A$ ", post_unit=" per IA",
                scaling_factor=1000, decimal_places=1, figsize=(8, 5), x_label_offset=0.3, y_label_offset=1,
                Corr=False, Frontier=True, corr_text_pos=(0.02, 0.45))

            fig_scatter2 = plot_scatter_with_efficient_frontier(table_mean_CI_differ, 
                ('Reduction in new Syphilis', 'Mean'), ('Cost of doxy-PEP (A$ ,000)', 'Mean'),
                'Relation of Reduced Syphilis and Cost of doxy-PEP', 'Reduction in New Syphilis (Mean)',
                'Cost of Doxy-PEP (A$,000) (Mean)', pre_unit="A$ ", post_unit=" per IA",
                scaling_factor=1000, decimal_places=1, figsize=(8, 5), x_label_offset=0.3, y_label_offset=1,
                Corr=False, Frontier=True, corr_text_pos=(0.7, 0.05))

            fig_scatter3 = plot_scatter_with_efficient_frontier(table_mean_CI_differ, 
                ('Reduction in new STIs', 'Mean'), ('Doxy-PEP prescriptions', 'Mean'),
                'Relation of Reduced STIs and Number of doxy-PEP prescriptions', 'Reduction in New STIs (Mean)', 
                'Doxy-PEP prescriptions (Mean)', pre_unit="", post_unit=" prescriptions per IA",
                scaling_factor=1, decimal_places=1, figsize=(8, 5), x_label_offset=0.2, y_label_offset=1.05,
                Corr=True, Frontier=True, corr_text_pos=(0.02, 0.45))

            fig_scatter4 = plot_scatter_with_efficient_frontier(table_mean_CI_differ, 
                ('Reduction in new Syphilis', 'Mean'), ('Doxy-PEP prescriptions', 'Mean'),
                'Relation of Reduced Syphilis and Number of doxy-PEP prescriptions', 'Reduction in new Syphilis (Mean)', 
                'Doxy-PEP prescriptions (Mean)', pre_unit="", post_unit=" prescriptions\nper syphilis averted",
                scaling_factor=1, decimal_places=1, figsize=(8, 5), x_label_offset=0.2, y_label_offset=1.0,
                Corr=True, Frontier=True, corr_text_pos=(0.02, 0.45))

            fig_scatter5 = plot_scatter_with_efficient_frontier(table_mean_CI_differ, 
                ('Doxy-PEP coverage', 'Mean'), ('Increased new NG infections with HL TetR', 'Mean'),
                'Relation of doxy-PEP coverage and increased gonorrhoea with HL TetR', 'Coverage of doxy-PEP (Mean)',
                'Increased gonorrhoea with HL TetR (,000) (Mean)', pre_unit="", post_unit=" per % coverage",
                scaling_factor=1000, decimal_places=1, figsize=(8, 5), x_label_offset=0.2, y_label_offset=1,
                Corr=True, Frontier=False, corr_text_pos=(0.7, 0.05))

    else:
        # Other groups: Calculate statistics only
        table_mean_CI, table_mean_CI_differ, formatted_df = Summarize_results(
            results_for_process, 2025, 2034, Var_calcu_formula, 
            Var_calcu_formula_differ, Var_for_save
        )

    all_table_mean_CI.append(table_mean_CI)
    all_table_mean_CI_differ.append(table_mean_CI_differ)

# Get results from group 1
first_group = results_groups[0]

# Calculate with 0.00 discount rate
Var_calcu_formula, Var_calcu_formula_differ = get_calculation_formulas(104, discount_rate=0.00)

# Calculate with 0.06 discount rate
Var_calcu_formula, Var_calcu_formula_differ = get_calculation_formulas(104, discount_rate=0.06)
table_mean_CI, table_mean_CI_differ, formatted_df = Summarize_results(
    results_for_process, 2025, 2034, Var_calcu_formula, 
    Var_calcu_formula_differ, Var_for_save
)
all_table_mean_CI.append(table_mean_CI)
all_table_mean_CI_differ.append(table_mean_CI_differ)

fig_tornado1 = plot_tornado_multiple_scenarios(
    all_table_mean_CI_differ,
    'Reduction in new STIs',
    vertical_lines=[{'x': 0, 'color': 'red', 'label': ''}],
    row_labels=row_labels_2
)

fig_tornado2 = plot_tornado_multiple_scenarios(
    all_table_mean_CI_differ,
    'Reduction in new Syphilis',
    vertical_lines=[{'x': 0, 'color': 'red', 'label': ''}],
    row_labels=row_labels_2
)

fig_tornado3 = plot_tornado_multiple_scenarios(
    all_table_mean_CI_differ,
    'Increased new NG infections with HL TetR',
    vertical_lines=[{'x': 0, 'color': 'red', 'label': ''}],    
    row_labels=row_labels_1
)

fig_tornado4 = plot_tornado_multiple_scenarios(
    all_table_mean_CI_differ,
    'Benefit-cost ratio',
    vertical_lines=[{'x': 1, 'color': 'red', 'label': ''}],
    row_labels=row_labels_2
)